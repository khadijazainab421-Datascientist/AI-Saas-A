# Cadence

A multi-tenant, AI-assisted social media operations platform built in controlled phases with Next.js App Router, TypeScript, Tailwind CSS, PostgreSQL and Drizzle ORM.

**Current phase:** 4 of 8 — Content Creation Studio. Phases 1–3 are complete. Phases 5–8 are not started.

## What is implemented

| Phase | Scope |
| --- | --- |
| 1 | Design system, landing page, responsive dashboard shell, empty/loading/error states |
| 2 | Better Auth email/password, database sessions, workspaces, membership roles, business profiles, tenant isolation |
| 3 | Provider-independent AI layer, Gemini/Groq fallback, Tavily research, website analysis, brand profiles, strategy generation, usage tracking, task pause/resume, notifications |
| 4 | Content editor with version history, caption/idea generation, carousel builder, local branded SVG graphics, keyless Openverse media sourcing, brand assets, content calendar |

**Not implemented / explicitly pending:** social OAuth and publishing (Phase 5), background workers and autonomy (Phase 6), analytics and billing (Phase 7), hardening and launch (Phase 8).

## Quick start (local)

```bash
npm install
cp .env.example .env
# fill in DATABASE_URL and BETTER_AUTH_SECRET
npx drizzle-kit push
npm run dev
```

Open `http://localhost:3000/sign-up`, create an account, complete `/onboarding`, then visit `/dashboard`.

See [`docs/LOCAL-SETUP.md`](docs/LOCAL-SETUP.md) for login and embedded-preview troubleshooting.

## Environment variables

`.env.example` is the secret-free template. `.env`, `.env.local` and `.env.*.local` are gitignored.

- `DATABASE_URL` — PostgreSQL connection
- `BETTER_AUTH_SECRET` — generate with `openssl rand -base64 32`
- `BETTER_AUTH_URL` — fallback origin (dynamic baseURL handles preview hosts)
- `GEMINI_API_KEY`, `GROQ_API_KEY`, `TAVILY_API_KEY` — Phase 3 AI/research providers (optional; tasks pause when unconfigured)
- `UNSPLASH_ACCESS_KEY`, `PEXELS_API_KEY` — optional Phase 4 media providers. **Openverse needs no key.**

All secrets are read server-side only. No key is exposed to the browser, stored in the database, printed in logs, or committed.

## Scripts

```bash
npm run dev        # local development
npm run build      # production build
npm run start      # production server
npm run lint       # ESLint
npm exec tsc -- --noEmit
npx drizzle-kit push
node scripts/verify-phase3-keys.mjs   # safe key pre-flight (prints HTTP status only)
```

## Documentation

- `docs/PHASE-1.md` — foundation report
- `docs/PHASE-2.md` — database and authentication report
- `docs/PHASE-3.md` — AI/research engine report and credential disclosure
- `docs/PHASE-4.md` — content studio report and media API disclosure
- `docs/LOCAL-SETUP.md` — local setup and troubleshooting

## Honesty notes

- Live AI provider calls are only claimed as working after a real successful task. Unconfigured providers are labelled `unconfigured`, never simulated.
- Calendar entries are `planned` only. No platform publishing is attempted.
- Video MP4 rendering is pending FFmpeg and a Phase 6 worker; only real storyboards are produced.
- No GitHub repository, commit, or push has been performed by the build process. Connect a remote yourself before committing.

## License / dependencies

See `package.json`. Key open-source dependencies: Next.js, React, Drizzle ORM, `pg`, Better Auth (MIT), `lucide-react` (ISC), Zod, Tailwind CSS.
