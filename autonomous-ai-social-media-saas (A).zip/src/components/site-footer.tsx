import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { BrandWordmark } from "@/components/brand";

const groups = [
  {
    title: "Product",
    links: [
      { label: "Platform", href: "/#platform" },
      { label: "Method", href: "/#method" },
      { label: "Roadmap", href: "/#roadmap" },
    ],
  },
  {
    title: "Preview",
    links: [
      { label: "Overview", href: "/dashboard" },
      { label: "Content", href: "/dashboard/content" },
      { label: "Integrations", href: "/dashboard/integrations" },
    ],
  },
  {
    title: "Build",
    links: [
      { label: "Analytics", href: "/dashboard/analytics" },
      { label: "Agent", href: "/dashboard/agent" },
      { label: "Settings", href: "/dashboard/settings" },
    ],
  },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-line bg-soft">
      <div className="mx-auto grid max-w-[1320px] gap-12 px-5 py-14 sm:px-8 lg:grid-cols-[1.4fr_2fr] lg:px-10 lg:py-16">
        <div>
          <BrandWordmark />
          <p className="mt-5 max-w-sm text-sm leading-6 text-muted">
            A considered operating system for autonomous social media work — built in controlled,
            reviewable phases.
          </p>
          <div className="mt-7 inline-flex items-center gap-2 rounded-full border border-line bg-canvas/70 px-3 py-2 text-[11px] font-bold uppercase tracking-[0.14em] text-forest">
            <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-[#B99555]" />
            Phase 4 of 8 · Content Creation Studio
          </div>
        </div>

        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
          {groups.map((group) => (
            <div key={group.title}>
              <h2 className="text-[10px] font-bold uppercase tracking-[0.2em] text-brand">
                {group.title}
              </h2>
              <ul className="mt-4 space-y-3">
                {group.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="inline-flex items-center gap-1 text-sm text-muted transition-colors hover:text-forest"
                    >
                      {link.label}
                      <ArrowUpRight size={12} aria-hidden="true" className="opacity-0 transition-opacity group-hover:opacity-100" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t border-line">
        <div className="mx-auto flex max-w-[1320px] flex-col gap-3 px-5 py-5 text-[11px] font-medium uppercase tracking-[0.13em] text-muted sm:flex-row sm:items-center sm:justify-between sm:px-8 lg:px-10">
          <span>© {new Date().getFullYear()} Cadence. Conceptual product build.</span>
          <span>No live social, AI, billing, or analytics connections configured.</span>
        </div>
      </div>
    </footer>
  );
}
