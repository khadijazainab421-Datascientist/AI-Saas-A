import { cn } from "@/lib/cn";

export function BrandMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 40 40"
      fill="none"
      className={cn("h-9 w-9", className)}
      role="img"
      aria-label="Cadence mark"
    >
      <rect x="0.75" y="0.75" width="38.5" height="38.5" rx="12" fill="#155E59" />
      <path
        d="M28.2 13.2a10 10 0 1 0 1.2 10.2"
        stroke="#DCEBE4"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      <path
        d="M13.5 21.2c2.2-4.1 4.2-4.1 6.4 0s4.2 4.1 6.4 0"
        stroke="#FAFCFB"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      <circle cx="29.4" cy="12.5" r="2.2" fill="#A7BDB1" />
    </svg>
  );
}

export function BrandWordmark({
  compact = false,
  inverse = false,
  className,
}: {
  compact?: boolean;
  inverse?: boolean;
  className?: string;
}) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <BrandMark className={compact ? "h-8 w-8" : "h-9 w-9"} />
      <span className="flex items-baseline gap-1.5">
        <span
          className={cn(
            "font-editorial text-[25px] leading-none tracking-[-0.02em]",
            inverse ? "text-white" : "text-ink",
          )}
        >
          Cadence
        </span>
        {!compact && (
          <span
            className={cn(
              "text-[9px] font-bold uppercase tracking-[0.26em]",
              inverse ? "text-mint" : "text-muted",
            )}
          >
            AI
          </span>
        )}
      </span>
    </span>
  );
}
