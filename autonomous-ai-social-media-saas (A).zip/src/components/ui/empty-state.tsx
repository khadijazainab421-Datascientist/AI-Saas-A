import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export function EmptyState({
  icon: Icon,
  eyebrow,
  title,
  description,
  action,
  compact = false,
  className,
}: {
  icon?: LucideIcon;
  eyebrow?: string;
  title: string;
  description: string;
  action?: ReactNode;
  compact?: boolean;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-start justify-center border border-dashed border-sage/70 bg-canvas/35 text-left",
        compact ? "rounded-[20px] p-6" : "rounded-[24px] p-8 sm:p-10",
        className,
      )}
    >
      {Icon && (
        <span className="mb-5 inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-line bg-white text-brand">
          <Icon size={19} strokeWidth={1.7} aria-hidden="true" />
        </span>
      )}
      {eyebrow && (
        <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.18em] text-brand">
          {eyebrow}
        </p>
      )}
      <h3 className="font-editorial text-2xl leading-tight text-ink sm:text-[28px]">{title}</h3>
      <p className="mt-3 max-w-lg text-sm leading-6 text-muted">{description}</p>
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

export function LoadingState({ label = "Preparing workspace" }: { label?: string }) {
  return (
    <div role="status" aria-live="polite" className="mx-auto w-full max-w-[1400px] px-5 py-10 sm:px-8">
      <div className="mb-8 flex items-center gap-3 text-sm text-muted">
        <span aria-hidden="true" className="h-2 w-2 animate-pulse rounded-full bg-brand" />
        {label}
      </div>
      <div className="h-8 w-64 rounded-lg bg-mint/70 skeleton-shimmer" />
      <div className="mt-3 h-4 w-full max-w-xl rounded-lg bg-mint/50 skeleton-shimmer" />
      <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[0, 1, 2, 3].map((item) => (
          <div key={item} className="h-36 rounded-[24px] border border-line bg-white p-5">
            <div className="h-3 w-24 rounded bg-mint/70 skeleton-shimmer" />
            <div className="mt-6 h-7 w-32 rounded bg-mint/70 skeleton-shimmer" />
            <div className="mt-5 h-2 w-full rounded bg-mint/40 skeleton-shimmer" />
          </div>
        ))}
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <div className="h-80 rounded-[24px] border border-line bg-white p-6 lg:col-span-2">
          <div className="h-4 w-48 rounded bg-mint/70 skeleton-shimmer" />
          <div className="mt-8 h-48 rounded-xl bg-canvas/70 skeleton-shimmer" />
        </div>
        <div className="h-80 rounded-[24px] border border-line bg-white p-6">
          <div className="h-4 w-32 rounded bg-mint/70 skeleton-shimmer" />
          <div className="mt-8 h-48 rounded-xl bg-canvas/70 skeleton-shimmer" />
        </div>
      </div>
    </div>
  );
}
