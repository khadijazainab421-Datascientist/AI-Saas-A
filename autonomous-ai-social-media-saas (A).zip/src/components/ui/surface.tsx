import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/cn";

type PanelProps = HTMLAttributes<HTMLDivElement> & {
  glass?: boolean;
  children: ReactNode;
};

export function Panel({ glass = false, className, children, ...props }: PanelProps) {
  return (
    <div
      className={cn(
        "rounded-[24px] border border-line bg-white",
        glass && "glass-surface",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}

type BadgeTone = "neutral" | "brand" | "pending" | "outline";

const badgeTones: Record<BadgeTone, string> = {
  neutral: "bg-canvas text-forest",
  brand: "bg-brand text-white",
  pending: "bg-[#F4F0E5] text-[#746444]",
  outline: "border border-line bg-white/70 text-muted",
};

export function Badge({
  tone = "neutral",
  className,
  children,
}: {
  tone?: BadgeTone;
  className?: string;
  children: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.13em]",
        badgeTones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function Eyebrow({
  children,
  className,
  marker = true,
}: {
  children: ReactNode;
  className?: string;
  marker?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-2.5 text-[11px] font-bold uppercase tracking-[0.19em] text-brand",
        className,
      )}
    >
      {marker && <span aria-hidden="true" className="text-[15px] leading-none text-sage">✳</span>}
      <span>{children}</span>
    </div>
  );
}

export function StatusDot({ tone = "pending" }: { tone?: "pending" | "inactive" | "brand" }) {
  const color =
    tone === "brand" ? "bg-brand" : tone === "inactive" ? "bg-sage" : "bg-[#B99555]";
  return <span aria-hidden="true" className={cn("h-1.5 w-1.5 rounded-full", color)} />;
}

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      aria-hidden="true"
      className={cn("skeleton-shimmer rounded-lg bg-mint/70", className)}
    />
  );
}
