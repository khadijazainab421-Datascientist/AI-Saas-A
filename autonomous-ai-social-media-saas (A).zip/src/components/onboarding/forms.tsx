"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useActionState } from "react";
import { ArrowRight, Building2, Check, Loader2 } from "lucide-react";
import { createWorkspace } from "@/app/actions/workspace";
import { createBusiness } from "@/app/actions/business";
import type { ActionState } from "@/app/actions/workspace";
import { AuthForm, FormAlert, FormField, SubmitButton } from "@/components/auth/form-field";
import { cn } from "@/lib/cn";

const idle: ActionState = { status: "idle" };

export function WorkspaceOnboardingForm() {
  const router = useRouter();
  const [state, formAction, pending] = useActionState(createWorkspace, idle);
  const [name, setName] = useState("");

  return (
    <AuthForm
      onSubmit={(event) => {
        event.preventDefault();
        const formData = new FormData(event.currentTarget);
        formAction(formData);
      }}
    >
      {state.status === "error" && state.message && <FormAlert tone="error">{state.message}</FormAlert>}

      <FormField
        label="Workspace name"
        name="name"
        value={name}
        onChange={setName}
        error={state.fieldErrors?.name}
        hint="Usually your company or agency name."
        placeholder="Northwind Studio"
      />

      <SubmitButton pending={pending}>
        {pending ? "Creating workspace…" : "Create workspace"}
        {!pending && <ArrowRight size={16} aria-hidden="true" />}
      </SubmitButton>

      {state.status === "success" && (
        <button
          type="button"
          onClick={() => {
            router.refresh();
          }}
          className="inline-flex items-center gap-2 text-xs font-bold text-brand"
        >
          <Check size={14} aria-hidden="true" /> Continue
        </button>
      )}
    </AuthForm>
  );
}

export function BusinessOnboardingForm({ workspaceId }: { workspaceId: string }) {
  const [state, formAction, pending] = useActionState(
    createBusiness.bind(null, workspaceId),
    idle,
  );
  const router = useRouter();

  const [fields, setFields] = useState({
    name: "",
    website: "",
    industry: "",
    description: "",
    brandVoice: "",
    targetAudience: "",
    goals: "",
    timezone: "UTC",
  });

  const update = (key: keyof typeof fields) => (value: string) =>
    setFields((current) => ({ ...current, [key]: value }));

  return (
    <AuthForm
      onSubmit={(event) => {
        event.preventDefault();
        const formData = new FormData(event.currentTarget);
        formAction(formData);
        if (state.status !== "error") {
          router.refresh();
        }
      }}
    >
      {state.status === "error" && state.message && <FormAlert tone="error">{state.message}</FormAlert>}
      {state.status === "success" && <FormAlert tone="success">{state.message}</FormAlert>}

      <FormField
        label="Business name"
        name="name"
        value={fields.name}
        onChange={update("name")}
        error={state.fieldErrors?.name}
        placeholder="Northwind Studio"
      />

      <div className="grid gap-5 sm:grid-cols-2">
        <FormField
          label="Website"
          name="website"
          type="url"
          value={fields.website}
          onChange={update("website")}
          error={state.fieldErrors?.website}
          required={false}
          placeholder="https://northwind.studio"
        />
        <FormField
          label="Industry"
          name="industry"
          value={fields.industry}
          onChange={update("industry")}
          required={false}
          placeholder="Interior design"
        />
      </div>

      <div>
        <label
          htmlFor="business-description"
          className="block text-[11px] font-bold uppercase tracking-[0.13em] text-forest"
        >
          What does this business do?
        </label>
        <textarea
          id="business-description"
          name="description"
          rows={3}
          value={fields.description}
          onChange={(event) => update("description")(event.target.value)}
          placeholder="A short description of products, services, and what makes it different."
          className="mt-2 w-full rounded-2xl border border-line bg-white px-4 py-3 text-sm text-ink transition-colors placeholder:text-muted/60 focus:border-brand"
        />
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label
            htmlFor="brand-voice"
            className="block text-[11px] font-bold uppercase tracking-[0.13em] text-forest"
          >
            Brand voice
          </label>
          <textarea
            id="brand-voice"
            name="brandVoice"
            rows={3}
            value={fields.brandVoice}
            onChange={(event) => update("brandVoice")(event.target.value)}
            placeholder="Warm, precise, understated."
            className="mt-2 w-full rounded-2xl border border-line bg-white px-4 py-3 text-sm text-ink transition-colors placeholder:text-muted/60 focus:border-brand"
          />
        </div>
        <div>
          <label
            htmlFor="target-audience"
            className="block text-[11px] font-bold uppercase tracking-[0.13em] text-forest"
          >
            Target audience
          </label>
          <textarea
            id="target-audience"
            name="targetAudience"
            rows={3}
            value={fields.targetAudience}
            onChange={(event) => update("targetAudience")(event.target.value)}
            placeholder="Design-led homeowners aged 30–55."
            className="mt-2 w-full rounded-2xl border border-line bg-white px-4 py-3 text-sm text-ink transition-colors placeholder:text-muted/60 focus:border-brand"
          />
        </div>
      </div>

      <div>
        <label
          htmlFor="business-goals"
          className="block text-[11px] font-bold uppercase tracking-[0.13em] text-forest"
        >
          Primary goals
        </label>
        <textarea
          id="business-goals"
          name="goals"
          rows={2}
          value={fields.goals}
          onChange={(event) => update("goals")(event.target.value)}
          placeholder="Grow qualified enquiries and establish category authority."
          className="mt-2 w-full rounded-2xl border border-line bg-white px-4 py-3 text-sm text-ink transition-colors placeholder:text-muted/60 focus:border-brand"
        />
      </div>

      <FormField
        label="Timezone"
        name="timezone"
        value={fields.timezone}
        onChange={update("timezone")}
        required={false}
        hint="Used for scheduling and calendar views."
      />

      <SubmitButton pending={pending}>
        {pending ? (
          <>
            <Loader2 size={16} className="animate-spin" aria-hidden="true" /> Saving…
          </>
        ) : (
          <>
            <Building2 size={16} aria-hidden="true" /> Add business
          </>
        )}
      </SubmitButton>

      <p className={cn("text-[11px] leading-5 text-muted")}>
        You can add more businesses later from the Businesses area.
      </p>
    </AuthForm>
  );
}
