import { ArrowUpRight, Check, LockKeyhole } from "lucide-react";
import { Badge, StatusDot } from "@/components/ui/surface";

const railItems = ["Overview", "Businesses", "Strategy", "Content", "Calendar", "Integrations"];

const pipeline = [
  { label: "Understand business", status: "Phase 3", active: true },
  { label: "Research & strategy", status: "Phase 3", active: false },
  { label: "Create & review", status: "Phase 4", active: false },
  { label: "Publish & learn", status: "Phases 5–7", active: false },
];

export function ProductPreview() {
  return (
    <div className="relative" aria-label="Cadence dashboard interface preview" role="img">
      <div
        aria-hidden="true"
        className="absolute -left-8 -top-8 hidden h-48 w-48 rounded-full bg-mint/60 blur-[70px] lg:block"
      />
      <div className="absolute -right-3 -top-6 z-20 hidden w-48 rounded-2xl border border-white/80 bg-white/80 p-3.5 shadow-[0_18px_40px_rgba(23,43,41,0.1)] backdrop-blur-xl sm:block">
        <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-[0.14em] text-muted">
          <span>Agent posture</span>
          <StatusDot tone="pending" />
        </div>
        <p className="mt-2 text-sm font-bold text-forest">Review mode</p>
        <p className="mt-1 text-[11px] leading-4 text-muted">Autonomy controls arrive in Phase 6.</p>
      </div>

      <div className="relative overflow-hidden rounded-[28px] border border-line bg-white shadow-[0_30px_80px_rgba(23,43,41,0.11)]">
        <div className="flex h-10 items-center gap-2 border-b border-line bg-soft px-4">
          <span className="h-2 w-2 rounded-full bg-sage/70" />
          <span className="h-2 w-2 rounded-full bg-sage/50" />
          <span className="h-2 w-2 rounded-full bg-sage/30" />
          <div className="ml-3 flex h-5 flex-1 items-center rounded-md border border-line bg-white px-3 text-[9px] font-semibold tracking-wide text-muted">
            cadence.app / workspace / overview
          </div>
        </div>

        <div className="grid min-h-[400px] grid-cols-1 sm:grid-cols-[132px_1fr]">
          <aside className="hidden flex-col bg-forest p-4 sm:flex">
            <div className="flex items-center gap-2 border-b border-white/12 pb-4">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-mint/15 text-[10px] font-bold text-mint">
                C
              </span>
              <span className="font-editorial text-lg text-white">Cadence</span>
            </div>
            <div className="mt-5 space-y-1">
              {railItems.map((item, index) => (
                <div
                  key={item}
                  className={`flex items-center gap-2 rounded-lg px-2.5 py-2 text-[10px] font-semibold ${
                    index === 0 ? "bg-white/14 text-white" : "text-mint/65"
                  }`}
                >
                  <span className={`h-1.5 w-1.5 rounded-full ${index === 0 ? "bg-mint" : "bg-mint/30"}`} />
                  {item}
                </div>
              ))}
            </div>
            <div className="mt-auto rounded-xl border border-white/12 bg-white/6 p-3">
              <p className="text-[9px] font-bold uppercase tracking-[0.14em] text-mint/70">Workspace</p>
              <p className="mt-1.5 text-[11px] font-semibold text-white">Not created yet</p>
            </div>
          </aside>

          <div className="p-4 sm:p-5">
            <div className="flex items-start justify-between gap-3 border-b border-line pb-4">
              <div>
                <p className="text-[9px] font-bold uppercase tracking-[0.18em] text-brand">
                  Phase 1 interface
                </p>
                <h3 className="mt-1 font-editorial text-[24px] leading-none text-ink">
                  Workspace overview
                </h3>
              </div>
              <Badge tone="outline">Preview</Badge>
            </div>

            <div className="mt-4 grid grid-cols-3 gap-2">
              {[
                { label: "Businesses", value: "—", note: "Awaiting setup" },
                { label: "Accounts", value: "—", note: "None connected" },
                { label: "Queue", value: "—", note: "No live jobs" },
              ].map((item) => (
                <div key={item.label} className="rounded-xl border border-line bg-soft p-2.5">
                  <p className="text-[8px] font-bold uppercase tracking-[0.12em] text-muted">{item.label}</p>
                  <p className="mt-2 font-editorial text-xl text-forest">{item.value}</p>
                  <p className="mt-1 text-[8px] leading-3 text-muted">{item.note}</p>
                </div>
              ))}
            </div>

            <div className="mt-4 grid gap-3 lg:grid-cols-[1.1fr_0.9fr]">
              <div className="rounded-xl border border-line p-3">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-forest">Autonomous pipeline</p>
                  <span className="text-[8px] font-bold uppercase tracking-[0.12em] text-muted">
                    Planned
                  </span>
                </div>
                <div className="mt-3 space-y-1.5">
                  {pipeline.map((step) => (
                    <div
                      key={step.label}
                      className="flex items-center justify-between rounded-lg bg-canvas/55 px-2.5 py-2 text-[9px]"
                    >
                      <span className="flex items-center gap-2 font-semibold text-forest">
                        <span className={`flex h-3.5 w-3.5 items-center justify-center rounded-full ${step.active ? "bg-brand text-white" : "border border-sage bg-white"}`}>
                          {step.active && <Check size={8} strokeWidth={2.4} />}
                        </span>
                        {step.label}
                      </span>
                      <span className="text-muted">{step.status}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-xl border border-line bg-soft p-3">
                <p className="text-[10px] font-bold text-forest">Performance</p>
                <div className="relative mt-3 h-[108px] overflow-hidden rounded-lg border border-line bg-white">
                  <div className="absolute inset-0 dot-grid opacity-50" />
                  {[20, 44, 68, 92].map((top) => (
                    <span key={top} className="absolute left-0 right-0 border-t border-line" style={{ top }} />
                  ))}
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 bg-white/70">
                    <LockKeyhole size={13} className="text-sage" aria-hidden="true" />
                    <p className="text-[9px] font-bold text-forest">No analytics connected</p>
                    <p className="text-[8px] text-muted">Phase 7</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute -bottom-5 left-5 z-20 hidden items-center gap-3 rounded-2xl border border-white/80 bg-white/85 px-4 py-3 shadow-[0_16px_36px_rgba(23,43,41,0.09)] backdrop-blur-xl md:flex">
        <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-mint text-brand">
          <LockKeyhole size={14} aria-hidden="true" />
        </span>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-brand">No passwords</p>
          <p className="mt-0.5 text-xs font-semibold text-forest">Official OAuth only, when configured</p>
        </div>
        <ArrowUpRight size={14} className="ml-2 text-sage" aria-hidden="true" />
      </div>
    </div>
  );
}
