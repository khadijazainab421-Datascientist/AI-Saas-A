"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { BrandWordmark } from "@/components/brand";
import { ButtonLink } from "@/components/ui/button";

const links = [
  { label: "Platform", href: "/#platform" },
  { label: "Method", href: "/#method" },
  { label: "Coverage", href: "/#coverage" },
  { label: "Roadmap", href: "/#roadmap" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-line/90 bg-soft/88 backdrop-blur-xl">
      <div className="mx-auto flex h-[72px] max-w-[1320px] items-center justify-between px-5 sm:px-8 lg:px-10">
        <Link href="/" aria-label="Cadence home" className="transition-opacity hover:opacity-80">
          <BrandWordmark />
        </Link>

        <nav aria-label="Main navigation" className="hidden items-center gap-8 lg:flex">
          {links.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className="text-[12px] font-bold uppercase tracking-[0.16em] text-muted transition-colors hover:text-brand"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Link
            href="/dashboard"
            className="px-2 text-[12px] font-bold uppercase tracking-[0.16em] text-forest transition-colors hover:text-brand"
          >
            Sign in
          </Link>
          <ButtonLink href="/dashboard" size="sm">
            Open dashboard <ArrowUpRight size={15} aria-hidden="true" />
          </ButtonLink>
        </div>

        <button
          type="button"
          className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-line bg-white text-forest lg:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          aria-controls="mobile-navigation"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>

      {open && (
        <div
          id="mobile-navigation"
          className="border-t border-line bg-soft px-5 pb-6 pt-4 lg:hidden"
        >
          <nav aria-label="Mobile navigation" className="flex flex-col">
            {links.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                onClick={() => setOpen(false)}
                className="border-b border-line py-3.5 text-sm font-semibold text-forest"
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <ButtonLink href="/sign-up" className="mt-5 w-full" onClick={() => setOpen(false)}>
            Create account <ArrowUpRight size={15} aria-hidden="true" />
          </ButtonLink>
        </div>
      )}
    </header>
  );
}
