import Link from "next/link";
import {
  ArrowUpRight,
  BarChart3,
  Building2,
  CircleDashed,
  Clock3,
  Compass,
  FileText,
  Globe,
  PlugZap,
  Radio,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";
import { Badge, Eyebrow, Panel, StatusDot } from "@/components/ui/surface";
import { EmptyState } from "@/components/ui/empty-state";
import type { Business } from "@/db/schema";
import type { WorkspaceSummary } from "@/lib/tenancy";
import type { SessionUser } from "@/lib/session";

export function DashboardOverview({
  user,
  activeWorkspace,
  businesses,
}: {
  user: SessionUser;
  activeWorkspace: WorkspaceSummary;
  businesses: Business[];
}) {
  const firstName = user.name.split(" ")[0];

  return (
    <div className="space-y-5">
      <div className="flex flex-col justify-between gap-5 pb-2 lg:flex-row lg:items-end">
        <div>
          <Eyebrow marker={false}>{activeWorkspace.workspace.name}</Eyebrow>
          <h1 className="mt-3 font-editorial text-[clamp(2.2rem,3.4vw,3.5rem)] leading-tight tracking-[-0.025em] text-ink">
            Welcome back, {firstName}.
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
            Your role in this workspace is{" "}
            <span className="font-bold text-forest">{activeWorkspace.role}</span>. Businesses,
            connected accounts, content, and analytics below reflect only what has actually been
            built and configured.
          </p>
        </div>
        <Link
          href="/#roadmap"
          className="inline-flex w-fit items-center gap-2 text-xs font-bold uppercase tracking-[0.14em] text-brand hover:text-forest"
        >
          Delivery roadmap <ArrowUpRight size={14} aria-hidden="true" />
        </Link>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.65fr_0.85fr]">
        <Panel className="overflow-hidden">
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-line px-6 py-5">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.17em] text-brand">
                Workspace readiness
              </p>
              <h2 className="mt-1.5 font-editorial text-2xl text-ink">
                Foundation in place. Integrations pending.
              </h2>
            </div>
            <Badge tone="brand">
              <StatusDot tone="brand" /> Live data
            </Badge>
          </div>
          <div className="grid sm:grid-cols-2 xl:grid-cols-4">
            <div className="border-line px-5 py-5 sm:border-r xl:border-b-0 xl:border-r">
              <div className="flex items-center justify-between">
                <Building2 size={17} className="text-brand" strokeWidth={1.8} aria-hidden="true" />
                <span className="text-[9px] font-bold uppercase tracking-[0.12em] text-muted">
                  Phase 2
                </span>
              </div>
              <p className="mt-5 text-[10px] font-bold uppercase tracking-[0.13em] text-muted">
                Businesses
              </p>
              <p className="mt-1.5 font-editorial text-2xl text-forest">{businesses.length}</p>
              <p className="mt-2 text-[11px] leading-4 text-muted">
                {businesses.length === 0 ? "None added yet" : "Stored in this workspace"}
              </p>
            </div>

            <div className="border-line border-b px-5 py-5 sm:border-r xl:border-b-0 xl:border-r">
              <div className="flex items-center justify-between">
                <Users size={17} className="text-brand" strokeWidth={1.8} aria-hidden="true" />
                <span className="text-[9px] font-bold uppercase tracking-[0.12em] text-muted">
                  Phase 2
                </span>
              </div>
              <p className="mt-5 text-[10px] font-bold uppercase tracking-[0.13em] text-muted">
                Membership
              </p>
              <p className="mt-1.5 font-editorial text-2xl text-forest">{activeWorkspace.role}</p>
              <p className="mt-2 text-[11px] leading-4 text-muted">Your verified access level</p>
            </div>

            <div className="border-line border-b px-5 py-5 xl:border-b-0 xl:border-r">
              <div className="flex items-center justify-between">
                <PlugZap size={17} className="text-brand" strokeWidth={1.8} aria-hidden="true" />
                <span className="text-[9px] font-bold uppercase tracking-[0.12em] text-muted">
                  Phase 5
                </span>
              </div>
              <p className="mt-5 text-[10px] font-bold uppercase tracking-[0.13em] text-muted">
                Connected accounts
              </p>
              <p className="mt-1.5 font-editorial text-2xl text-forest">0</p>
              <p className="mt-2 text-[11px] leading-4 text-muted">Official OAuth not configured</p>
            </div>

            <div className="px-5 py-5">
              <div className="flex items-center justify-between">
                <Sparkles size={17} className="text-brand" strokeWidth={1.8} aria-hidden="true" />
                <span className="text-[9px] font-bold uppercase tracking-[0.12em] text-muted">
                  Phase 6
                </span>
              </div>
              <p className="mt-5 text-[10px] font-bold uppercase tracking-[0.13em] text-muted">
                Content queue
              </p>
              <p className="mt-1.5 font-editorial text-2xl text-forest">Idle</p>
              <p className="mt-2 text-[11px] leading-4 text-muted">No publishing worker</p>
            </div>
          </div>
        </Panel>

        <Panel className="flex flex-col bg-forest p-6 text-white">
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-bold uppercase tracking-[0.17em] text-mint">Agent posture</p>
            <StatusDot tone="pending" />
          </div>
          <h2 className="mt-5 font-editorial text-3xl leading-tight">Paused by design.</h2>
          <p className="mt-3 text-xs leading-6 text-mint/75">
            Autonomous work still requires configured providers, permissioned publishing, and a
            reliable background worker.
          </p>
          <div className="mt-auto pt-8">
            <div className="flex items-center justify-between rounded-2xl border border-white/15 bg-white/6 px-4 py-3">
              <div className="flex items-center gap-2.5">
                <ShieldCheck size={17} className="text-mint" aria-hidden="true" />
                <span className="text-xs font-bold text-white">Review every post</span>
              </div>
              <button
                type="button"
                disabled
                aria-label="Autonomy toggle disabled until Phase 6"
                aria-pressed={false}
                className="relative h-6 w-11 cursor-not-allowed rounded-full bg-white/20"
              >
                <span className="absolute left-1 top-1 h-4 w-4 rounded-full bg-mint" />
              </button>
            </div>
            <p className="mt-3 text-[10px] leading-4 text-mint/65">
              Control remains disabled until Phase 6.
            </p>
          </div>
        </Panel>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.65fr_0.85fr]">
        <Panel className="p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="text-sm font-bold text-forest">Business profiles</h2>
              <p className="mt-1.5 text-xs leading-5 text-muted">
                Real records stored in this workspace.
              </p>
            </div>
            <Link
              href="/dashboard/businesses"
              className="text-[11px] font-bold text-brand hover:text-forest"
            >
              Manage
            </Link>
          </div>

          {businesses.length === 0 ? (
            <EmptyState
              icon={Building2}
              compact
              title="No businesses yet"
              description="Add a business profile to give the future agent real context about what you do, who you serve, and how you speak."
              action={
                <Link
                  href="/onboarding"
                  className="inline-flex items-center gap-2 text-xs font-bold text-brand hover:text-forest"
                >
                  Add a business <ArrowUpRight size={13} aria-hidden="true" />
                </Link>
              }
              className="mt-5 bg-canvas/40"
            />
          ) : (
            <div className="mt-5 border-t border-line">
              {businesses.map((business) => (
                <div
                  key={business.id}
                  className="flex flex-wrap items-center gap-4 border-b border-line py-4"
                >
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-canvas font-editorial text-lg text-brand">
                    {business.name.charAt(0).toUpperCase()}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-forest">{business.name}</p>
                    <p className="mt-0.5 truncate text-[11px] text-muted">
                      {business.industry || "Industry not set"}
                      {business.website ? ` · ${business.website}` : ""}
                    </p>
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-[0.12em] text-muted">
                    {business.timezone}
                  </span>
                </div>
              ))}
            </div>
          )}
        </Panel>

        <div className="space-y-5">
          <Panel className="p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-forest">Platform readiness</h2>
              <PlugZap size={16} className="text-brand" aria-hidden="true" />
            </div>
            <div className="mt-4 border-t border-line">
              {[
                { mark: "IG", name: "Instagram", phase: "Phase 5" },
                { mark: "f", name: "Facebook", phase: "Phase 5" },
                { mark: "in", name: "LinkedIn", phase: "Phase 5" },
              ].map((platform) => (
                <div key={platform.name} className="flex items-center gap-3 border-b border-line py-3.5">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-canvas font-editorial text-lg text-brand">
                    {platform.mark}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-forest">{platform.name}</p>
                    <p className="text-[10px] text-muted">{platform.phase}</p>
                  </div>
                  <span className="inline-flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-[0.11em] text-[#746444]">
                    <StatusDot tone="pending" /> Pending
                  </span>
                </div>
              ))}
            </div>
            <Link
              href="/dashboard/integrations"
              className="mt-4 inline-flex items-center gap-1.5 text-[11px] font-bold text-brand hover:text-forest"
            >
              Open Integration Center <ArrowUpRight size={13} aria-hidden="true" />
            </Link>
          </Panel>

          <Panel className="p-5">
            <div className="flex items-center gap-2.5 rounded-xl bg-canvas/70 px-3.5 py-3">
              <Radio size={15} className="text-brand" aria-hidden="true" />
              <p className="text-[11px] leading-4 text-muted">
                <span className="font-bold text-forest">No publishing logs.</span> Retry and duplicate
                safeguards arrive with the worker in Phase 6.
              </p>
            </div>
          </Panel>
        </div>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.65fr_0.85fr]">
        <Panel className="p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="text-sm font-bold text-forest">Planned autonomous pipeline</h2>
              <p className="mt-1.5 text-xs leading-5 text-muted">
                Sequence from business context to measured learning.
              </p>
            </div>
            <Badge tone="outline">Not started</Badge>
          </div>

          <ol className="mt-6 border-t border-line">
            {[
              { label: "Business understanding", detail: "Website, audiences, brand voice, objectives", phase: "Phase 3" },
              { label: "Industry research", detail: "Public sources, trends, seasonal opportunities", phase: "Phase 3" },
              { label: "Strategy and content", detail: "Pillars, formats, captions, brand assets", phase: "Phases 3–4" },
              { label: "Approval and scheduling", detail: "Review gates, calendar, publishing limits", phase: "Phases 4–6" },
              { label: "Publishing and learning", detail: "Official APIs, logs, retries, real analytics", phase: "Phases 5–7" },
            ].map((step, index) => (
              <li
                key={step.label}
                className="grid gap-2 border-b border-line py-3.5 sm:grid-cols-[32px_1fr_auto] sm:items-center sm:gap-4"
              >
                <span className="font-editorial text-lg text-sage">0{index + 1}</span>
                <div>
                  <p className="text-[13px] font-bold text-forest">{step.label}</p>
                  <p className="mt-0.5 text-[11px] leading-4 text-muted">{step.detail}</p>
                </div>
                <span className="inline-flex w-fit items-center gap-2 text-[10px] font-bold uppercase tracking-[0.12em] text-muted">
                  <CircleDashed size={13} aria-hidden="true" /> {step.phase}
                </span>
              </li>
            ))}
          </ol>
        </Panel>

        <div className="space-y-5">
          <Panel className="p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-forest">Performance</h2>
              <BarChart3 size={16} className="text-brand" aria-hidden="true" />
            </div>
            <p className="mt-1.5 text-xs leading-5 text-muted">
              Reserved for real, platform-sourced measurements.
            </p>
            <div className="relative mt-5 h-[150px] overflow-hidden rounded-2xl border border-line bg-soft">
              <svg aria-hidden="true" className="absolute inset-0 h-full w-full" preserveAspectRatio="none">
                <defs>
                  <pattern id="chart-grid" width="48" height="38" patternUnits="userSpaceOnUse">
                    <path d="M 48 0 L 0 0 0 38" fill="none" stroke="#E3EBE6" strokeWidth="1" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#chart-grid)" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/55 px-5 text-center">
                <Globe size={16} className="text-sage" aria-hidden="true" />
                <p className="mt-2.5 font-editorial text-xl text-ink">No analytics connected</p>
                <p className="mt-1.5 text-[10px] leading-4 text-muted">
                  No placeholder figures are shown.
                </p>
              </div>
            </div>
          </Panel>

          <EmptyState
            icon={FileText}
            eyebrow="Activity"
            title="No recent activity"
            description="Workspace events, approvals, provider interruptions, and publishing outcomes will appear here once the underlying systems exist."
            compact
          />
        </div>
      </div>
    </div>
  );
}
