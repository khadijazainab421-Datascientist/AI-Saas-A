"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { CalendarPlus, Trash2 } from "lucide-react";
import { scheduleContentAction, unscheduleAction } from "@/app/actions/content";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";

export type ScheduleItemView = {
  id: string;
  title: string;
};

export type ScheduleEntryView = {
  id: string;
  contentTitle: string;
  platform: string;
  scheduledFor: string;
  timezone: string;
  status: string;
};

export function CalendarControls({
  workspaceId,
  items,
}: {
  workspaceId: string;
  items: ScheduleItemView[];
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [contentId, setContentId] = useState(items[0]?.id ?? "");
  const [platform, setPlatform] = useState("instagram");
  const [when, setWhen] = useState("");
  const [message, setMessage] = useState("");

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block text-[10px] font-bold uppercase tracking-[0.13em] text-forest">
          Content
          <select
            value={contentId}
            onChange={(event) => setContentId(event.target.value)}
            disabled={items.length === 0}
            className="mt-2 h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink focus:border-brand"
          >
            {items.length === 0 && <option value="">No content</option>}
            {items.map((item) => (
              <option key={item.id} value={item.id}>
                {item.title}
              </option>
            ))}
          </select>
        </label>
        <label className="block text-[10px] font-bold uppercase tracking-[0.13em] text-forest">
          Platform
          <select
            value={platform}
            onChange={(event) => setPlatform(event.target.value)}
            className="mt-2 h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink focus:border-brand"
          >
            <option value="instagram">Instagram</option>
            <option value="facebook">Facebook</option>
            <option value="linkedin">LinkedIn</option>
          </select>
        </label>
      </div>

      <label className="block text-[10px] font-bold uppercase tracking-[0.13em] text-forest">
        Date and time
        <input
          type="datetime-local"
          value={when}
          onChange={(event) => setWhen(event.target.value)}
          className="mt-2 h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink focus:border-brand"
        />
      </label>

      <Button
        disabled={pending || !contentId || !when}
        onClick={() =>
          startTransition(async () => {
            const response = await scheduleContentAction(
              workspaceId,
              contentId,
              platform,
              when,
              Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
            );
            setMessage(response.message);
            if (response.ok) setWhen("");
            router.refresh();
          })
        }
      >
        <CalendarPlus size={15} aria-hidden="true" /> {pending ? "Saving…" : "Add to calendar"}
      </Button>

      {message && (
        <p
          className={cn(
            "rounded-2xl border px-4 py-3 text-xs leading-5",
            message.startsWith("Scheduled")
              ? "border-line bg-canvas text-forest"
              : "border-[#E6CFC2] bg-[#FBF3EE] text-[#A9664B]",
          )}
        >
          {message}
        </p>
      )}
    </div>
  );
}

export function UnscheduleButton({
  workspaceId,
  entryId,
}: {
  workspaceId: string;
  entryId: string;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();

  return (
    <button
      type="button"
      aria-label="Remove schedule entry"
      disabled={pending}
      onClick={() =>
        startTransition(async () => {
          await unscheduleAction(workspaceId, entryId);
          router.refresh();
        })
      }
      className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-muted transition-colors hover:bg-canvas hover:text-forest disabled:opacity-50"
    >
      <Trash2 size={12} aria-hidden="true" />
    </button>
  );
}
