"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  Image as ImageIcon,
  Layers3,
  Loader2,
  Pencil,
  Plus,
  Search,
  Sparkles,
  Trash2,
  Wand2,
} from "lucide-react";
import {
  addBrandAssetAction,
  createCarouselAction,
  createDraftAction,
  createGraphicAction,
  createStoryboardAction,
  deleteContentAction,
  generateCaptionAction,
  generateIdeasAction,
  sourceMediaAction,
  updateContentAction,
  type ContentActionResult,
} from "@/app/actions/content";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";
import { svgToDataUrl } from "@/lib/media/graphics";

export type ContentItemView = {
  id: string;
  title: string;
  type: string;
  status: string;
  platform: string;
  caption: string;
  body: string;
  hashtags: string[];
  createdAt: string;
};

export type MediaAssetView = {
  id: string;
  kind: string;
  providerKey: string;
  title: string;
  url: string | null;
  thumbnailUrl: string | null;
  svgData: string | null;
  creator: string | null;
  license: string | null;
  attribution: string | null;
};

export type ProviderView = {
  key: string;
  label: string;
  requiresKey: boolean;
  configured: boolean;
  available: boolean;
  freeTier: string;
  note: string;
  envVar: string | null;
};

export function ContentStudio({
  workspaceId,
  businesses,
  items,
  assets,
  providers,
  videoNote,
}: {
  workspaceId: string;
  businesses: { id: string; name: string }[];
  items: ContentItemView[];
  assets: MediaAssetView[];
  providers: ProviderView[];
  videoNote: string;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [result, setResult] = useState<ContentActionResult | null>(null);
  const [businessId, setBusinessId] = useState(businesses[0]?.id ?? "");
  const [topic, setTopic] = useState("");
  const [mediaQuery, setMediaQuery] = useState("");
  const [headline, setHeadline] = useState("");
  const [draftTitle, setDraftTitle] = useState("");
  const [editing, setEditing] = useState<ContentItemView | null>(null);
  const [storyboard, setStoryboard] = useState<string | null>(null);

  const selectedBusiness = businesses.find((item) => item.id === businessId);

  function run(action: () => Promise<ContentActionResult>) {
    setResult(null);
    startTransition(async () => {
      const response = await action();
      setResult(response);
      if (response.storyboard) {
        setStoryboard(
          response.storyboard.scenes
            .map((scene) => `${scene.position}. ${scene.onScreenText} (${scene.durationSeconds}s)`)
            .join("\n"),
        );
      }
      router.refresh();
    });
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <label htmlFor="cs-business" className="text-[10px] font-bold uppercase tracking-[0.14em] text-forest">
          Business
        </label>
        <select
          id="cs-business"
          value={businessId}
          onChange={(event) => setBusinessId(event.target.value)}
          className="h-10 min-w-[200px] rounded-xl border border-line bg-white px-3 text-sm text-ink focus:border-brand"
        >
          {businesses.length === 0 && <option value="">No businesses</option>}
          {businesses.map((item) => (
            <option key={item.id} value={item.id}>
              {item.name}
            </option>
          ))}
        </select>
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        <StudioCard icon={Sparkles} title="AI copy" subtitle="Uses the Phase 3 hybrid fallback engine">
          <input
            value={topic}
            onChange={(event) => setTopic(event.target.value)}
            placeholder="Caption topic"
            maxLength={300}
            className="h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink placeholder:text-muted/60 focus:border-brand"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <Button
              size="sm"
              disabled={pending || !businessId || topic.trim().length < 3}
              onClick={() => run(() => generateCaptionAction(workspaceId, businessId, topic, "multi"))}
            >
              <Wand2 size={14} aria-hidden="true" /> Generate caption
            </Button>
            <Button
              size="sm"
              variant="secondary"
              disabled={pending || !businessId}
              onClick={() => run(() => generateIdeasAction(workspaceId, businessId))}
            >
              <Sparkles size={14} aria-hidden="true" /> Generate ideas
            </Button>
          </div>
        </StudioCard>

        <StudioCard icon={ImageIcon} title="Media sourcing" subtitle="Openverse is keyless and live">
          <input
            value={mediaQuery}
            onChange={(event) => setMediaQuery(event.target.value)}
            placeholder="Search openly licensed images"
            maxLength={200}
            className="h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink placeholder:text-muted/60 focus:border-brand"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="secondary"
              disabled={pending || mediaQuery.trim().length < 3}
              onClick={() => run(() => sourceMediaAction(workspaceId, businessId, mediaQuery))}
            >
              <Search size={14} aria-hidden="true" /> Source media
            </Button>
            <Button
              size="sm"
              variant="secondary"
              disabled={pending || !headline.trim()}
              onClick={() =>
                run(() => createGraphicAction(workspaceId, businessId, headline, selectedBusiness?.name ?? "Cadence"))
              }
            >
              <Wand2 size={14} aria-hidden="true" /> Local SVG graphic
            </Button>
          </div>
          <input
            value={headline}
            onChange={(event) => setHeadline(event.target.value)}
            placeholder="Graphic headline"
            maxLength={160}
            className="mt-3 h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink placeholder:text-muted/60 focus:border-brand"
          />
        </StudioCard>

        <StudioCard icon={Plus} title="Manual draft" subtitle="Create and edit content directly">
          <input
            value={draftTitle}
            onChange={(event) => setDraftTitle(event.target.value)}
            placeholder="Draft title"
            maxLength={200}
            className="h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink placeholder:text-muted/60 focus:border-brand"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="secondary"
              disabled={pending || draftTitle.trim().length < 2}
              onClick={() => {
                run(() => createDraftAction(workspaceId, businessId, draftTitle));
                setDraftTitle("");
              }}
            >
              <Plus size={14} aria-hidden="true" /> New draft
            </Button>
            <Button
              size="sm"
              variant="quiet"
              disabled={pending || items.length === 0}
              onClick={() => run(() => createStoryboardAction(workspaceId, "Brand story", items.slice(0, 4).map((item) => item.title)))}
            >
              <Layers3 size={14} aria-hidden="true" /> Video storyboard
            </Button>
          </div>
          <p className="mt-3 text-[11px] leading-5 text-muted">{videoNote}</p>
          {storyboard && (
            <pre className="mt-2 whitespace-pre-wrap rounded-xl bg-canvas/70 p-3 text-[10px] leading-5 text-forest">
              {storyboard}
            </pre>
          )}
        </StudioCard>

        <StudioCard icon={ImageIcon} title="Media providers" subtitle="Honest readiness, no simulated assets">
          <div className="space-y-2">
            {providers.map((provider) => (
              <div key={provider.key} className="rounded-xl border border-line bg-canvas/40 px-3 py-2.5">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs font-bold text-forest">{provider.label}</p>
                  <span
                    className={cn(
                      "text-[9px] font-bold uppercase tracking-[0.11em]",
                      provider.configured ? "text-brand" : "text-[#746444]",
                    )}
                  >
                    {provider.configured ? "ready" : provider.available ? "unconfigured" : "unavailable"}
                  </span>
                </div>
                <p className="mt-1 text-[10px] leading-4 text-muted">{provider.freeTier}</p>
                <p className="mt-1 text-[10px] leading-4 text-muted">{provider.note}</p>
              </div>
            ))}
          </div>
        </StudioCard>
      </div>

      {result && (
        <div
          role={result.ok ? "status" : "alert"}
          className={cn(
            "rounded-2xl border px-4 py-3 text-xs leading-5",
            result.ok
              ? result.taskStatus === "paused"
                ? "border-[#E6D8BD] bg-[#FBF6EB] text-[#746444]"
                : "border-line bg-canvas text-forest"
              : "border-[#E6CFC2] bg-[#FBF3EE] text-[#A9664B]",
          )}
        >
          {result.message}
        </div>
      )}

      <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-[24px] border border-line bg-white p-6">
          <h2 className="text-sm font-bold text-forest">Content ({items.length})</h2>
          {items.length === 0 ? (
            <p className="mt-4 text-sm leading-6 text-muted">
              No content yet. Generate a caption, create ideas, or add a manual draft.
            </p>
          ) : (
            <div className="mt-4 border-t border-line">
              {items.map((item) => (
                <div key={item.id} className="border-b border-line py-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-forest">{item.title}</p>
                      <p className="mt-1 line-clamp-2 text-[11px] leading-5 text-muted">
                        {item.caption || "No caption yet."}
                      </p>
                      <p className="mt-1.5 text-[10px] uppercase tracking-[0.1em] text-muted">
                        {item.type} · {item.status} · {item.platform}
                      </p>
                    </div>
                    <div className="flex shrink-0 gap-1">
                      <Button size="sm" variant="quiet" onClick={() => setEditing(item)}>
                        <Pencil size={13} aria-hidden="true" /> Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="quiet"
                        onClick={() => run(() => createCarouselAction(workspaceId, item.id))}
                      >
                        <Layers3 size={13} aria-hidden="true" /> Carousel
                      </Button>
                      <Button
                        size="sm"
                        variant="quiet"
                        onClick={() => run(() => deleteContentAction(workspaceId, item.id))}
                      >
                        <Trash2 size={13} aria-hidden="true" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-[24px] border border-line bg-white p-6">
          <h2 className="text-sm font-bold text-forest">Brand assets</h2>
          <p className="mt-1.5 text-[11px] leading-5 text-muted">
            Store real brand references locally. No external asset API required.
          </p>
          <BrandAssetForm workspaceId={workspaceId} businessId={businessId} />
        </div>
      </div>

      <div className="rounded-[24px] border border-line bg-white p-6">
        <h2 className="text-sm font-bold text-forest">Media library ({assets.length})</h2>
        {assets.length === 0 ? (
          <p className="mt-4 text-sm leading-6 text-muted">
            No media assets yet. Sourced images include creator, license, and attribution.
          </p>
        ) : (
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {assets.map((asset) => (
              <div key={asset.id} className="overflow-hidden rounded-2xl border border-line bg-canvas/40">
                <div className="aspect-square overflow-hidden bg-white">
                  {asset.svgData ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={svgToDataUrl(asset.svgData)}
                      alt={asset.title}
                      className="h-full w-full object-cover"
                    />
                  ) : asset.thumbnailUrl || asset.url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={asset.thumbnailUrl ?? asset.url ?? ""}
                      alt={asset.title}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="grid h-full place-items-center text-xs text-muted">No preview</div>
                  )}
                </div>
                <div className="p-3">
                  <p className="line-clamp-2 text-[11px] font-bold text-forest">{asset.title}</p>
                  <p className="mt-1 text-[9px] uppercase tracking-[0.1em] text-muted">
                    {asset.providerKey} · {asset.kind}
                  </p>
                  {asset.attribution && (
                    <p className="mt-1.5 line-clamp-2 text-[9px] leading-3 text-muted">
                      {asset.attribution}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {editing && (
        <EditorDialog
          workspaceId={workspaceId}
          item={editing}
          onClose={() => setEditing(null)}
          onSaved={() => router.refresh()}
        />
      )}

      {pending && (
        <div className="flex items-center gap-2 text-xs text-muted">
          <Loader2 size={14} className="animate-spin" aria-hidden="true" /> Working…
        </div>
      )}
    </div>
  );
}

function StudioCard({
  icon: Icon,
  title,
  subtitle,
  children,
}: {
  icon: typeof Sparkles;
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-[24px] border border-line bg-white p-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-forest">{title}</h2>
          <p className="mt-1 text-[11px] leading-4 text-muted">{subtitle}</p>
        </div>
        <Icon size={16} className="text-brand" aria-hidden="true" />
      </div>
      <div className="mt-5 border-t border-line pt-5">{children}</div>
    </div>
  );
}

function BrandAssetForm({ workspaceId, businessId }: { workspaceId: string; businessId: string }) {
  const [name, setName] = useState("");
  const [kind, setKind] = useState("color");
  const [value, setValue] = useState("");
  const [pending, startTransition] = useTransition();
  const [message, setMessage] = useState("");

  return (
    <div className="mt-5 space-y-3 border-t border-line pt-5">
      <input
        value={name}
        onChange={(event) => setName(event.target.value)}
        placeholder="Asset name (e.g. Primary teal)"
        className="h-10 w-full rounded-xl border border-line bg-white px-3 text-xs text-ink focus:border-brand"
      />
      <select
        value={kind}
        onChange={(event) => setKind(event.target.value)}
        className="h-10 w-full rounded-xl border border-line bg-white px-3 text-xs text-ink focus:border-brand"
      >
        <option value="color">Colour</option>
        <option value="font">Font</option>
        <option value="guideline">Guideline</option>
        <option value="logo">Logo reference</option>
      </select>
      <input
        value={value}
        onChange={(event) => setValue(event.target.value)}
        placeholder="Value (e.g. #155E59)"
        className="h-10 w-full rounded-xl border border-line bg-white px-3 text-xs text-ink focus:border-brand"
      />
      <Button
        size="sm"
        variant="secondary"
        disabled={pending || !name.trim() || !value.trim()}
        onClick={() =>
          startTransition(async () => {
            const response = await addBrandAssetAction(workspaceId, businessId, name, kind, value);
            setMessage(response.message);
            setName("");
            setValue("");
          })
        }
      >
        Save brand asset
      </Button>
      {message && <p className="text-[11px] text-muted">{message}</p>}
    </div>
  );
}

function EditorDialog({
  workspaceId,
  item,
  onClose,
  onSaved,
}: {
  workspaceId: string;
  item: ContentItemView;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [title, setTitle] = useState(item.title);
  const [caption, setCaption] = useState(item.caption);
  const [body, setBody] = useState(item.body);
  const [hashtags, setHashtags] = useState((item.hashtags ?? []).join(", "));
  const [platform, setPlatform] = useState(item.platform);
  const [status, setStatus] = useState(item.status);
  const [pending, startTransition] = useTransition();
  const [message, setMessage] = useState("");

  return (
    <div className="fixed inset-0 z-[60] grid place-items-center overflow-y-auto bg-forest/25 p-4 backdrop-blur-sm">
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Content editor"
        className="my-auto w-full max-w-[620px] rounded-[28px] border border-line bg-soft p-6 shadow-[0_30px_80px_rgba(23,43,41,0.18)] sm:p-8"
      >
        <div className="flex items-start justify-between border-b border-line pb-5">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.17em] text-brand">Editor</p>
            <h2 className="mt-2 font-editorial text-2xl text-ink">Edit content</h2>
          </div>
          <Button size="sm" variant="quiet" onClick={onClose}>
            Close
          </Button>
        </div>

        <div className="mt-6 space-y-4">
          <label className="block text-[10px] font-bold uppercase tracking-[0.13em] text-forest">
            Title
            <input
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              className="mt-2 h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink focus:border-brand"
            />
          </label>
          <label className="block text-[10px] font-bold uppercase tracking-[0.13em] text-forest">
            Caption
            <textarea
              value={caption}
              onChange={(event) => setCaption(event.target.value)}
              rows={5}
              className="mt-2 w-full rounded-2xl border border-line bg-white px-4 py-3 text-sm text-ink focus:border-brand"
            />
          </label>
          <label className="block text-[10px] font-bold uppercase tracking-[0.13em] text-forest">
            Notes / rationale
            <textarea
              value={body}
              onChange={(event) => setBody(event.target.value)}
              rows={3}
              className="mt-2 w-full rounded-2xl border border-line bg-white px-4 py-3 text-sm text-ink focus:border-brand"
            />
          </label>
          <label className="block text-[10px] font-bold uppercase tracking-[0.13em] text-forest">
            Hashtags (comma separated)
            <input
              value={hashtags}
              onChange={(event) => setHashtags(event.target.value)}
              className="mt-2 h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink focus:border-brand"
            />
          </label>
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block text-[10px] font-bold uppercase tracking-[0.13em] text-forest">
              Platform
              <select
                value={platform}
                onChange={(event) => setPlatform(event.target.value)}
                className="mt-2 h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink focus:border-brand"
              >
                <option value="multi">Multi-platform</option>
                <option value="instagram">Instagram</option>
                <option value="facebook">Facebook</option>
                <option value="linkedin">LinkedIn</option>
              </select>
            </label>
            <label className="block text-[10px] font-bold uppercase tracking-[0.13em] text-forest">
              Status
              <select
                value={status}
                onChange={(event) => setStatus(event.target.value)}
                className="mt-2 h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink focus:border-brand"
              >
                <option value="draft">Draft</option>
                <option value="needs_review">Needs review</option>
                <option value="approved">Approved</option>
              </select>
            </label>
          </div>

          <Button
            disabled={pending || !title.trim()}
            onClick={() =>
              startTransition(async () => {
                const response = await updateContentAction(workspaceId, item.id, {
                  title,
                  caption,
                  body,
                  hashtags: hashtags.split(",").map((tag) => tag.trim()).filter(Boolean),
                  platform,
                  status,
                });
                setMessage(response.message);
                if (response.ok) {
                  onSaved();
                  onClose();
                }
              })
            }
          >
            {pending ? "Saving…" : "Save version"}
          </Button>
          {message && <p className="text-[11px] text-muted">{message}</p>}
        </div>
      </div>
    </div>
  );
}
