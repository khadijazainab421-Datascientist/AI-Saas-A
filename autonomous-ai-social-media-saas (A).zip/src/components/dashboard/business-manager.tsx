"use client";

import { useState } from "react";
import { useActionState } from "react";
import { Building2, Pencil, Plus, Trash2, X } from "lucide-react";
import { createBusiness, deleteBusiness, updateBusiness } from "@/app/actions/business";
import type { ActionState } from "@/app/actions/workspace";
import type { Business } from "@/db/schema";
import { AuthForm, FormAlert, FormField, SubmitButton } from "@/components/auth/form-field";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";

const idle: ActionState = { status: "idle" };

type Draft = {
  id: string | null;
  name: string;
  website: string;
  industry: string;
  description: string;
  brandVoice: string;
  targetAudience: string;
  goals: string;
  timezone: string;
};

const emptyDraft: Draft = {
  id: null,
  name: "",
  website: "",
  industry: "",
  description: "",
  brandVoice: "",
  targetAudience: "",
  goals: "",
  timezone: "UTC",
};

function draftFrom(business: Business): Draft {
  return {
    id: business.id,
    name: business.name,
    website: business.website ?? "",
    industry: business.industry ?? "",
    description: business.description ?? "",
    brandVoice: business.brandVoice ?? "",
    targetAudience: business.targetAudience ?? "",
    goals: business.goals ?? "",
    timezone: business.timezone,
  };
}

export function BusinessManager({
  workspaceId,
  businesses,
}: {
  workspaceId: string;
  businesses: Business[];
}) {
  const [draft, setDraft] = useState<Draft | null>(null);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-line pb-6">
        <div>
          <h1 className="font-editorial text-[clamp(2rem,3.2vw,3rem)] leading-tight tracking-[-0.025em] text-ink">
            Businesses
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
            Separate brand profiles inside this workspace. Each one will later carry its own
            strategy, content, accounts, and analytics.
          </p>
        </div>
        <Button onClick={() => setDraft(emptyDraft)}>
          <Plus size={16} aria-hidden="true" /> Add business
        </Button>
      </div>

      {businesses.length === 0 ? (
        <div className="rounded-[24px] border border-dashed border-sage/70 bg-canvas/35 p-8 sm:p-10">
          <span className="mb-5 inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-line bg-white text-brand">
            <Building2 size={19} strokeWidth={1.7} aria-hidden="true" />
          </span>
          <h2 className="font-editorial text-2xl text-ink sm:text-[28px]">No businesses yet</h2>
          <p className="mt-3 max-w-lg text-sm leading-6 text-muted">
            Add your first business profile. This context will drive research, strategy, and content
            generation once those engines are connected.
          </p>
          <div className="mt-6">
            <Button onClick={() => setDraft(emptyDraft)}>
              <Plus size={16} aria-hidden="true" /> Add your first business
            </Button>
          </div>
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {businesses.map((business) => (
            <article
              key={business.id}
              className="flex flex-col rounded-[24px] border border-line bg-white p-6"
            >
              <div className="flex items-start gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-canvas font-editorial text-xl text-brand">
                  {business.name.charAt(0).toUpperCase()}
                </span>
                <div className="min-w-0 flex-1">
                  <h2 className="font-editorial text-2xl leading-tight text-ink">{business.name}</h2>
                  <p className="mt-1 text-[11px] font-bold uppercase tracking-[0.13em] text-muted">
                    {business.industry || "Industry not set"}
                  </p>
                </div>
              </div>

              <p className="mt-5 line-clamp-3 text-sm leading-6 text-muted">
                {business.description || "No description provided yet."}
              </p>

              <dl className="mt-5 grid gap-3 border-t border-line pt-5 sm:grid-cols-2">
                <div>
                  <dt className="text-[9px] font-bold uppercase tracking-[0.14em] text-muted">
                    Website
                  </dt>
                  <dd className="mt-1 truncate text-xs font-semibold text-forest">
                    {business.website || "—"}
                  </dd>
                </div>
                <div>
                  <dt className="text-[9px] font-bold uppercase tracking-[0.14em] text-muted">
                    Timezone
                  </dt>
                  <dd className="mt-1 text-xs font-semibold text-forest">{business.timezone}</dd>
                </div>
                <div>
                  <dt className="text-[9px] font-bold uppercase tracking-[0.14em] text-muted">
                    Brand voice
                  </dt>
                  <dd className="mt-1 truncate text-xs font-semibold text-forest">
                    {business.brandVoice || "—"}
                  </dd>
                </div>
                <div>
                  <dt className="text-[9px] font-bold uppercase tracking-[0.14em] text-muted">
                    Audience
                  </dt>
                  <dd className="mt-1 truncate text-xs font-semibold text-forest">
                    {business.targetAudience || "—"}
                  </dd>
                </div>
              </dl>

              <div className="mt-6 flex items-center gap-2 border-t border-line pt-5">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setDraft(draftFrom(business))}
                >
                  <Pencil size={14} aria-hidden="true" /> Edit
                </Button>
                <DeleteBusinessButton workspaceId={workspaceId} business={business} />
              </div>
            </article>
          ))}
        </div>
      )}

      {draft && (
        <BusinessDialog
          workspaceId={workspaceId}
          draft={draft}
          onClose={() => setDraft(null)}
        />
      )}
    </div>
  );
}

function DeleteBusinessButton({
  workspaceId,
  business,
}: {
  workspaceId: string;
  business: Business;
}) {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onDelete() {
    const confirmed = window.confirm(
      `Remove “${business.name}” from this workspace? This cannot be undone.`,
    );
    if (!confirmed) return;

    setPending(true);
    setError(null);
    const result = await deleteBusiness(workspaceId, business.id);
    setPending(false);

    if (result.status === "error") {
      setError(result.message ?? "Unable to remove this business.");
    }
  }

  return (
    <div className="flex items-center gap-3">
      {error && (
        <span role="alert" className="text-[11px] font-semibold text-[#A9664B]">
          {error}
        </span>
      )}
      <Button variant="quiet" size="sm" onClick={onDelete} disabled={pending}>
        <Trash2 size={14} aria-hidden="true" /> {pending ? "Removing…" : "Remove"}
      </Button>
    </div>
  );
}

function BusinessDialog({
  workspaceId,
  draft,
  onClose,
}: {
  workspaceId: string;
  draft: Draft;
  onClose: () => void;
}) {
  const isEdit = Boolean(draft.id);
  const [state, formAction, pending] = useActionState(
    isEdit
      ? updateBusiness.bind(null, workspaceId, draft.id!)
      : createBusiness.bind(null, workspaceId),
    idle,
  );

  const [values, setValues] = useState({
    name: draft.name,
    website: draft.website,
    industry: draft.industry,
    description: draft.description,
    brandVoice: draft.brandVoice,
    targetAudience: draft.targetAudience,
    goals: draft.goals,
    timezone: draft.timezone,
  });

  const update = (key: keyof typeof values) => (value: string) =>
    setValues((current) => ({ ...current, [key]: value }));

  return (
    <div
      className="fixed inset-0 z-[60] flex items-start justify-center overflow-y-auto bg-forest/25 p-4 backdrop-blur-sm sm:p-8"
      role="dialog"
      aria-modal="true"
      aria-labelledby="business-dialog-title"
    >
      <div className="my-auto w-full max-w-[640px] rounded-[28px] border border-line bg-soft p-6 shadow-[0_30px_80px_rgba(23,43,41,0.18)] sm:p-8">
        <div className="flex items-start justify-between gap-4 border-b border-line pb-5">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.17em] text-brand">
              {isEdit ? "Edit business" : "New business"}
            </p>
            <h2
              id="business-dialog-title"
              className="mt-2 font-editorial text-2xl text-ink sm:text-3xl"
            >
              {isEdit ? "Update business profile" : "Add a business profile"}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-line bg-white text-forest transition-colors hover:border-sage"
          >
            <X size={17} aria-hidden="true" />
          </button>
        </div>

        <div className="mt-6">
          <AuthForm
            onSubmit={(event) => {
              event.preventDefault();
              formAction(new FormData(event.currentTarget));
            }}
          >
            {state.status === "error" && state.message && (
              <FormAlert tone="error">{state.message}</FormAlert>
            )}
            {state.status === "success" && <FormAlert tone="success">{state.message}</FormAlert>}

            <FormField
              label="Business name"
              name="name"
              value={values.name}
              onChange={update("name")}
              error={state.fieldErrors?.name}
              placeholder="Northwind Studio"
            />

            <div className="grid gap-5 sm:grid-cols-2">
              <FormField
                label="Website"
                name="website"
                type="url"
                value={values.website}
                onChange={update("website")}
                error={state.fieldErrors?.website}
                required={false}
                placeholder="https://northwind.studio"
              />
              <FormField
                label="Industry"
                name="industry"
                value={values.industry}
                onChange={update("industry")}
                required={false}
                placeholder="Interior design"
              />
            </div>

            <div>
              <label
                htmlFor="dialog-description"
                className="block text-[11px] font-bold uppercase tracking-[0.13em] text-forest"
              >
                What does this business do?
              </label>
              <textarea
                id="dialog-description"
                name="description"
                rows={3}
                value={values.description}
                onChange={(event) => update("description")(event.target.value)}
                placeholder="Products, services, and what makes it different."
                className="mt-2 w-full rounded-2xl border border-line bg-white px-4 py-3 text-sm text-ink transition-colors placeholder:text-muted/60 focus:border-brand"
              />
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="dialog-voice"
                  className="block text-[11px] font-bold uppercase tracking-[0.13em] text-forest"
                >
                  Brand voice
                </label>
                <textarea
                  id="dialog-voice"
                  name="brandVoice"
                  rows={3}
                  value={values.brandVoice}
                  onChange={(event) => update("brandVoice")(event.target.value)}
                  placeholder="Warm, precise, understated."
                  className="mt-2 w-full rounded-2xl border border-line bg-white px-4 py-3 text-sm text-ink transition-colors placeholder:text-muted/60 focus:border-brand"
                />
              </div>
              <div>
                <label
                  htmlFor="dialog-audience"
                  className="block text-[11px] font-bold uppercase tracking-[0.13em] text-forest"
                >
                  Target audience
                </label>
                <textarea
                  id="dialog-audience"
                  name="targetAudience"
                  rows={3}
                  value={values.targetAudience}
                  onChange={(event) => update("targetAudience")(event.target.value)}
                  placeholder="Design-led homeowners aged 30–55."
                  className="mt-2 w-full rounded-2xl border border-line bg-white px-4 py-3 text-sm text-ink transition-colors placeholder:text-muted/60 focus:border-brand"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="dialog-goals"
                className="block text-[11px] font-bold uppercase tracking-[0.13em] text-forest"
              >
                Primary goals
              </label>
              <textarea
                id="dialog-goals"
                name="goals"
                rows={2}
                value={values.goals}
                onChange={(event) => update("goals")(event.target.value)}
                placeholder="Grow qualified enquiries and establish category authority."
                className="mt-2 w-full rounded-2xl border border-line bg-white px-4 py-3 text-sm text-ink transition-colors placeholder:text-muted/60 focus:border-brand"
              />
            </div>

            <FormField
              label="Timezone"
              name="timezone"
              value={values.timezone}
              onChange={update("timezone")}
              required={false}
            />

            <div className="flex flex-wrap gap-3 pt-2">
              <SubmitButton pending={pending}>
                {pending ? "Saving…" : isEdit ? "Save changes" : "Add business"}
              </SubmitButton>
              <Button
                variant="secondary"
                onClick={onClose}
                className={cn("h-12 px-6")}
                type="button"
              >
                {state.status === "success" ? "Done" : "Cancel"}
              </Button>
            </div>
          </AuthForm>
        </div>
      </div>
    </div>
  );
}
