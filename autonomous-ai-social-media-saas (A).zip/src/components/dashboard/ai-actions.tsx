"use client";

import { useState, useTransition } from "react";
import {
  BarChart3,
  Globe2,
  Loader2,
  PlayCircle,
  Search,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import {
  analyzeWebsiteAction,
  generateStrategyAction,
  resumeTasksAction,
  runResearchAction,
  setPaidProvidersAction,
  type AiActionResult,
} from "@/app/actions/ai";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/cn";

type BusinessOption = { id: string; name: string; website: string | null };

export function AiActions({
  workspaceId,
  businesses,
  mode,
  allowPaidProviders,
  pausedCount,
}: {
  workspaceId: string;
  businesses: BusinessOption[];
  mode: "strategy" | "agent";
  allowPaidProviders: boolean;
  pausedCount: number;
}) {
  const [pending, startTransition] = useTransition();
  const [result, setResult] = useState<AiActionResult | null>(null);
  const [businessId, setBusinessId] = useState(businesses[0]?.id ?? "");
  const [query, setQuery] = useState("");
  const [paidAllowed, setPaidAllowed] = useState(allowPaidProviders);

  const selected = businesses.find((item) => item.id === businessId);

  function run(action: () => Promise<AiActionResult>) {
    setResult(null);
    startTransition(async () => {
      setResult(await action());
    });
  }

  if (mode === "agent") {
    return (
      <div className="space-y-4">
        <div className="flex flex-wrap gap-3">
          <Button
            onClick={() => run(() => resumeTasksAction(workspaceId))}
            disabled={pending || pausedCount === 0}
          >
            {pending ? (
              <Loader2 size={16} className="animate-spin" aria-hidden="true" />
            ) : (
              <PlayCircle size={16} aria-hidden="true" />
            )}
            Resume paused tasks ({pausedCount})
          </Button>
          <Button
            variant={paidAllowed ? "primary" : "secondary"}
            onClick={() =>
              run(async () => {
                const next = !paidAllowed;
                const response = await setPaidProvidersAction(workspaceId, next);
                if (response.ok) setPaidAllowed(next);
                return response;
              })
            }
            disabled={pending}
          >
            <ShieldCheck size={16} aria-hidden="true" />
            {paidAllowed ? "Paid providers: allowed" : "Paid providers: blocked"}
          </Button>
        </div>

        <p className="text-[11px] leading-5 text-muted">
          All currently registered providers are free tier. This switch is a safety control: the
          orchestrator will never use a paid provider unless this is explicitly enabled.
        </p>

        {result && <ResultBanner result={result} />}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <label
          htmlFor="ai-business"
          className="block text-[10px] font-bold uppercase tracking-[0.14em] text-forest"
        >
          Business
        </label>
        <select
          id="ai-business"
          value={businessId}
          onChange={(event) => setBusinessId(event.target.value)}
          disabled={businesses.length === 0 || pending}
          className="mt-2 h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink focus:border-brand"
        >
          {businesses.length === 0 && <option value="">No businesses yet</option>}
          {businesses.map((business) => (
            <option key={business.id} value={business.id}>
              {business.name}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label
          htmlFor="ai-query"
          className="block text-[10px] font-bold uppercase tracking-[0.14em] text-forest"
        >
          Research query
        </label>
        <input
          id="ai-query"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="e.g. sustainable interior design trends 2026"
          maxLength={300}
          disabled={pending}
          className="mt-2 h-11 w-full rounded-2xl border border-line bg-white px-4 text-sm text-ink placeholder:text-muted/60 focus:border-brand"
        />
      </div>

      <div className="flex flex-wrap gap-3">
        <Button
          variant="secondary"
          onClick={() =>
            run(() => analyzeWebsiteAction(workspaceId, businessId))
          }
          disabled={pending || !businessId || !selected?.website}
          title={!selected?.website ? "Add a website to this business first" : undefined}
        >
          <Globe2 size={16} aria-hidden="true" /> Analyze website
        </Button>

        <Button
          variant="secondary"
          onClick={() => run(() => runResearchAction(workspaceId, businessId, query))}
          disabled={pending || !businessId || query.trim().length < 3}
        >
          <Search size={16} aria-hidden="true" /> Run research
        </Button>

        <Button
          onClick={() => run(() => generateStrategyAction(workspaceId, businessId))}
          disabled={pending || !businessId}
        >
          <Sparkles size={16} aria-hidden="true" /> Generate strategy
        </Button>
      </div>

      {!selected?.website && businessId && (
        <p className="text-[11px] leading-5 text-[#A9664B]">
          This business has no website URL. Add one in Businesses to enable website analysis.
        </p>
      )}

      {result && <ResultBanner result={result} />}

      <div className="flex items-start gap-2.5 rounded-2xl bg-canvas/70 px-4 py-3">
        <BarChart3 size={15} className="mt-0.5 shrink-0 text-brand" aria-hidden="true" />
        <p className="text-[11px] leading-5 text-muted">
          No results are simulated. If a provider is missing or exhausted, the task is paused and
          its input is preserved for resume.
        </p>
      </div>
    </div>
  );
}

function ResultBanner({ result }: { result: AiActionResult }) {
  return (
    <div
      role={result.ok ? "status" : "alert"}
      className={cn(
        "rounded-2xl border px-4 py-3 text-xs leading-5",
        result.ok
          ? result.taskStatus === "paused"
            ? "border-[#E6D8BD] bg-[#FBF6EB] text-[#746444]"
            : "border-line bg-canvas text-forest"
          : "border-[#E6CFC2] bg-[#FBF3EE] text-[#A9664B]",
      )}
    >
      {result.message}
    </div>
  );
}
