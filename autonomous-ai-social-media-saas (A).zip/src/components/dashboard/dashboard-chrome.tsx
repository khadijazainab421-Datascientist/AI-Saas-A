"use client";

import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bell,
  ChevronDown,
  ChevronRight,
  Info,
  LogOut,
  Menu,
  Search,
  UserRound,
  X,
} from "lucide-react";
import { BrandWordmark } from "@/components/brand";
import { Badge, StatusDot } from "@/components/ui/surface";
import { cn } from "@/lib/cn";
import { dashboardNav, flatDashboardNav, isDashboardPathActive } from "@/lib/navigation";
import { setActiveWorkspace } from "@/app/actions/workspace";
import { signOutAction } from "@/app/actions/auth";
import type { WorkspaceSummary } from "@/lib/tenancy";
import type { Business, Notification } from "@/db/schema";
import type { SessionUser } from "@/lib/session";

type MenuName = "workspace" | "search" | "notifications" | null;

export function DashboardChrome({
  children,
  user,
  activeWorkspace,
  businesses,
  notifications: initialNotifications,
}: {
  children: ReactNode;
  user: SessionUser;
  activeWorkspace: WorkspaceSummary;
  businesses: Business[];
  notifications: Notification[];
}) {
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [menu, setMenu] = useState<MenuName>(null);
  const [workspaces, setWorkspaces] = useState<WorkspaceSummary[]>([activeWorkspace]);
  const [switching, setSwitching] = useState(false);

  const currentItem = flatDashboardNav.find((item) =>
    isDashboardPathActive(item.href, pathname),
  );

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setMenu("search");
      }
      if (event.key === "Escape") {
        setMenu(null);
        setSidebarOpen(false);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  async function openWorkspaceMenu() {
    const nextMenu = menu === "workspace" ? null : "workspace";
    setMenu(nextMenu);

    if (nextMenu === "workspace") {
      // Load the full membership list only when the switcher is opened.
      const { getWorkspaceOptions } = await import("@/app/actions/workspace");
      const options = await getWorkspaceOptions();
      setWorkspaces(options);
    }
  }

  async function switchWorkspace(workspaceId: string) {
    setSwitching(true);
    await setActiveWorkspace(workspaceId);
    setSwitching(false);
    setMenu(null);
  }

  const toggleMenu = (name: Exclude<MenuName, null>) =>
    setMenu((value) => (value === name ? null : name));

  const initials = user.name
    .split(" ")
    .map((part) => part.charAt(0))
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="min-h-screen bg-canvas">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[70] focus:rounded-full focus:bg-brand focus:px-4 focus:py-2 focus:text-sm focus:font-bold focus:text-white"
      >
        Skip to content
      </a>

      {sidebarOpen && (
        <button
          type="button"
          aria-label="Close navigation"
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 z-40 bg-forest/20 backdrop-blur-[2px] lg:hidden"
        />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex w-[272px] flex-col border-r border-line bg-soft transition-transform duration-300 lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex h-[76px] shrink-0 items-center justify-between border-b border-line px-5">
          <Link href="/" aria-label="Cadence home">
            <BrandWordmark compact />
          </Link>
          <button
            type="button"
            aria-label="Close navigation"
            onClick={() => setSidebarOpen(false)}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-line bg-white text-forest lg:hidden"
          >
            <X size={17} aria-hidden="true" />
          </button>
        </div>

        <div className="relative border-b border-line px-4 py-4">
          <button
            type="button"
            onClick={openWorkspaceMenu}
            aria-expanded={menu === "workspace"}
            aria-haspopup="menu"
            className="flex w-full items-center gap-3 rounded-2xl border border-line bg-white px-3 py-2.5 text-left transition-colors hover:border-sage"
          >
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-mint font-editorial text-lg text-brand">
              {activeWorkspace.workspace.name.charAt(0).toUpperCase()}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-[10px] font-bold uppercase tracking-[0.14em] text-muted">
                Workspace · {activeWorkspace.role}
              </span>
              <span className="block truncate text-sm font-bold text-forest">
                {activeWorkspace.workspace.name}
              </span>
            </span>
            <ChevronDown size={15} className="text-muted" aria-hidden="true" />
          </button>

          {menu === "workspace" && (
            <div
              role="menu"
              className="absolute left-4 right-4 top-[74px] z-30 rounded-2xl border border-line bg-white p-3 shadow-[0_18px_44px_rgba(23,43,41,0.1)]"
            >
              <p className="px-1 pb-2 text-[10px] font-bold uppercase tracking-[0.14em] text-muted">
                Your workspaces
              </p>
              <div className="space-y-1">
                {workspaces.map((membership) => {
                  const isActive = membership.workspace.id === activeWorkspace.workspace.id;
                  return (
                    <button
                      key={membership.workspace.id}
                      type="button"
                      role="menuitem"
                      disabled={isActive || switching}
                      onClick={() => switchWorkspace(membership.workspace.id)}
                      className={cn(
                        "flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left text-xs font-semibold transition-colors",
                        isActive
                          ? "bg-brand text-white"
                          : "text-forest hover:bg-canvas disabled:opacity-50",
                      )}
                    >
                      <span
                        className={cn(
                          "h-1.5 w-1.5 rounded-full",
                          isActive ? "bg-mint" : "bg-sage",
                        )}
                      />
                      <span className="min-w-0 flex-1 truncate">{membership.workspace.name}</span>
                      <span className="text-[9px] uppercase tracking-[0.1em] opacity-70">
                        {membership.role}
                      </span>
                    </button>
                  );
                })}
              </div>
              <Link
                href="/onboarding"
                onClick={() => setMenu(null)}
                className="mt-2 flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-[11px] font-bold text-brand hover:bg-canvas"
              >
                <ChevronRight size={12} aria-hidden="true" /> Create a workspace
              </Link>
            </div>
          )}
        </div>

        <nav aria-label="Dashboard navigation" className="flex-1 overflow-y-auto px-3 py-5">
          {dashboardNav.map((group) => (
            <div key={group.label} className="mb-6">
              <p className="px-3 pb-2 text-[9px] font-bold uppercase tracking-[0.2em] text-muted/80">
                {group.label}
              </p>
              <ul className="space-y-0.5">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const active = isDashboardPathActive(item.href, pathname);
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        aria-current={active ? "page" : undefined}
                        onClick={() => {
                          setSidebarOpen(false);
                          setMenu(null);
                        }}
                        className={cn(
                          "flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold transition-all duration-200",
                          active
                            ? "bg-brand text-white"
                            : "text-muted hover:bg-mint/55 hover:text-forest",
                        )}
                      >
                        <Icon size={17} strokeWidth={1.8} aria-hidden="true" />
                        {item.label}
                        {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-mint" />}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>

        <div className="border-t border-line p-4">
          <div className="rounded-2xl border border-line bg-canvas/70 p-3.5">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-brand">
                Phase 4 of 8
              </p>
              <StatusDot tone="brand" />
            </div>
            <div className="mt-3 flex gap-1" aria-label="Four of eight phases complete">
              {Array.from({ length: 8 }, (_, index) => (
                <span
                  key={index}
                  className={cn(
                    "h-1 flex-1 rounded-full",
                    index < 4 ? "bg-brand" : "bg-sage/45",
                  )}
                />
              ))}
            </div>
            <p className="mt-3 text-[11px] leading-4 text-muted">
              {businesses.length} business{businesses.length === 1 ? "" : "es"} in this workspace.
            </p>
          </div>
        </div>
      </aside>

      <div className="lg:pl-[272px]">
        <header className="sticky top-0 z-30 border-b border-line bg-soft/90 backdrop-blur-xl">
          <div className="mx-auto flex h-[76px] max-w-[1500px] items-center gap-3 px-5 sm:px-8">
            <button
              type="button"
              aria-label="Open navigation"
              aria-expanded={sidebarOpen}
              onClick={() => setSidebarOpen(true)}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-line bg-white text-forest lg:hidden"
            >
              <Menu size={18} aria-hidden="true" />
            </button>

            <div className="hidden min-w-0 items-center gap-2 text-xs font-semibold text-muted sm:flex">
              <span>Cadence</span>
              <ChevronRight size={13} aria-hidden="true" />
              <span className="truncate">{activeWorkspace.workspace.name}</span>
              <ChevronRight size={13} aria-hidden="true" />
              <span className="truncate font-bold text-forest">
                {currentItem?.label ?? "Workspace"}
              </span>
            </div>
            <span className="truncate text-sm font-bold text-forest sm:hidden">
              {currentItem?.label ?? "Workspace"}
            </span>

            <div className="ml-auto flex items-center gap-2">
              <Badge tone="outline" className="hidden md:inline-flex">
                <StatusDot tone="brand" /> Signed in
              </Badge>

              <div className="relative hidden sm:block">
                <button
                  type="button"
                  onClick={() => toggleMenu("search")}
                  aria-expanded={menu === "search"}
                  aria-label="Search workspace"
                  className="flex h-10 items-center gap-2 rounded-full border border-line bg-white px-3.5 text-xs font-semibold text-muted transition-colors hover:border-sage hover:text-forest"
                >
                  <Search size={15} aria-hidden="true" />
                  <span className="hidden xl:inline">Search workspace</span>
                  <kbd className="ml-1 hidden rounded border border-line bg-canvas px-1.5 py-0.5 text-[10px] xl:inline">
                    ⌘K
                  </kbd>
                </button>
                {menu === "search" && (
                  <div className="absolute right-0 top-12 z-40 w-[320px] rounded-2xl border border-line bg-white p-4 shadow-[0_18px_44px_rgba(23,43,41,0.1)]">
                    <label
                      htmlFor="workspace-search"
                      className="text-[10px] font-bold uppercase tracking-[0.14em] text-brand"
                    >
                      Workspace search
                    </label>
                    <input
                      id="workspace-search"
                      disabled
                      placeholder="Nothing to index yet"
                      className="mt-3 h-10 w-full rounded-xl border border-line bg-canvas/60 px-3 text-sm text-muted placeholder:text-muted/70"
                    />
                    <p className="mt-3 text-[11px] leading-5 text-muted">
                      Search will index businesses, content, and strategies once those features are
                      built.
                    </p>
                  </div>
                )}
              </div>

              <div className="relative">
                <button
                  type="button"
                  onClick={() => toggleMenu("notifications")}
                  aria-expanded={menu === "notifications"}
                  aria-label="Notifications"
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-line bg-white text-forest transition-colors hover:border-sage"
                >
                  <Bell size={16} aria-hidden="true" />
                </button>
                {menu === "notifications" && (
                  <div className="absolute right-0 top-12 z-40 max-h-[360px] w-[320px] overflow-y-auto rounded-2xl border border-line bg-white p-4 shadow-[0_18px_44px_rgba(23,43,41,0.1)]">
                    <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-brand">
                      Workspace notifications
                    </p>
                    {initialNotifications.length === 0 ? (
                      <>
                        <p className="mt-3 text-xs font-bold text-forest">No notifications</p>
                        <p className="mt-1.5 text-[11px] leading-5 text-muted">
                          Provider outages, quota pauses, and resume attempts appear here.
                        </p>
                      </>
                    ) : (
                      <div className="mt-3 border-t border-line">
                        {initialNotifications.map((note) => (
                          <div key={note.id} className="border-b border-line py-3">
                            <p className="text-xs font-bold text-forest">{note.title}</p>
                            <p className="mt-1 line-clamp-3 text-[10px] leading-4 text-muted">
                              {note.body}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="flex h-10 items-center gap-2 rounded-full border border-line bg-white pl-1.5 pr-1">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-mint text-[10px] font-bold text-brand">
                  {initials || <UserRound size={14} aria-hidden="true" />}
                </span>
                <span className="hidden max-w-[130px] truncate text-xs font-bold text-forest md:inline">
                  {user.name}
                </span>
                <form action={signOutAction}>
                  <button
                    type="submit"
                    aria-label="Sign out"
                    title="Sign out"
                    className="flex h-8 w-8 items-center justify-center rounded-full text-muted transition-colors hover:bg-canvas hover:text-forest"
                  >
                    <LogOut size={15} aria-hidden="true" />
                  </button>
                </form>
              </div>
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-[1500px] px-5 pb-16 pt-6 sm:px-8">
          <div className="mb-7 flex items-start gap-3 rounded-2xl border border-line bg-white/75 px-4 py-3.5">
            <Info size={17} className="mt-0.5 shrink-0 text-brand" aria-hidden="true" />
            <p className="text-xs leading-5 text-muted">
              <span className="font-bold text-forest">Phase 4 of 8.</span> Content Studio and Calendar
              are live with keyless Openverse media sourcing. Social OAuth, publishing workers,
              analytics, and billing remain disconnected. No platform integration is claimed as live.
            </p>
            <Link
              href="/#roadmap"
              className="ml-auto hidden shrink-0 text-[11px] font-bold uppercase tracking-[0.13em] text-brand hover:text-forest lg:inline"
            >
              Roadmap
            </Link>
          </div>
          <main id="main-content">{children}</main>
        </div>
      </div>
    </div>
  );
}
