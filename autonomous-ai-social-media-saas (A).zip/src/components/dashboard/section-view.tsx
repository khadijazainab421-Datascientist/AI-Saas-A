import Link from "next/link";
import { ArrowLeft, ArrowUpRight, CircleDashed, LockKeyhole } from "lucide-react";
import { Badge, Eyebrow, Panel } from "@/components/ui/surface";
import { EmptyState } from "@/components/ui/empty-state";
import type { DashboardSectionConfig } from "@/lib/dashboard-sections";

export function SectionView({ config }: { config: DashboardSectionConfig }) {
  const Icon = config.icon;

  return (
    <div className="space-y-5">
      <div className="flex flex-col justify-between gap-5 pb-2 lg:flex-row lg:items-end">
        <div>
          <Eyebrow marker={false}>{config.eyebrow}</Eyebrow>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <h1 className="font-editorial text-[clamp(2.2rem,3.4vw,3.5rem)] leading-tight tracking-[-0.025em] text-ink">
              {config.title}
            </h1>
            <Badge tone="pending">
              <CircleDashed size={11} aria-hidden="true" /> Phase {config.phase} preview
            </Badge>
          </div>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">{config.description}</p>
        </div>
        <Link
          href="/dashboard"
          className="inline-flex w-fit items-center gap-2 text-xs font-bold uppercase tracking-[0.14em] text-brand hover:text-forest"
        >
          <ArrowLeft size={14} aria-hidden="true" /> Back to overview
        </Link>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.35fr_0.65fr]">
        <EmptyState
          icon={Icon}
          eyebrow="Empty state"
          title={config.emptyTitle}
          description={config.emptyDescription}
          className="min-h-[360px] bg-white"
          action={
            <Link
              href="/#roadmap"
              className="inline-flex items-center gap-2 text-xs font-bold text-brand hover:text-forest"
            >
              See when this arrives <ArrowUpRight size={14} aria-hidden="true" />
            </Link>
          }
        />

        <div className="space-y-5">
          <Panel className="p-6">
            <p className="text-[10px] font-bold uppercase tracking-[0.17em] text-brand">
              Planned surface
            </p>
            <h2 className="mt-2 font-editorial text-2xl text-ink">What belongs here</h2>
            <ul className="mt-5 space-y-0 border-t border-line">
              {config.capabilities.map((item) => (
                <li key={item} className="flex gap-3 border-b border-line py-3.5">
                  <span aria-hidden="true" className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-sage" />
                  <p className="text-xs leading-5 text-forest">{item}</p>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel className="p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-forest">Before this can go live</h2>
              <LockKeyhole size={16} className="text-brand" aria-hidden="true" />
            </div>
            <ul className="mt-4 space-y-0 border-t border-line">
              {config.dependencies.map((item) => (
                <li key={item} className="flex gap-3 border-b border-line py-3.5">
                  <CircleDashed size={14} className="mt-0.5 shrink-0 text-brand/70" aria-hidden="true" />
                  <p className="text-xs leading-5 text-muted">{item}</p>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>

      <div className="flex items-start gap-3 rounded-2xl border border-line bg-white/70 px-4 py-3.5">
        <LockKeyhole size={16} className="mt-0.5 shrink-0 text-brand" aria-hidden="true" />
        <p className="text-xs leading-5 text-muted">
          <span className="font-bold text-forest">Honesty note.</span> {config.note}
        </p>
      </div>
    </div>
  );
}
