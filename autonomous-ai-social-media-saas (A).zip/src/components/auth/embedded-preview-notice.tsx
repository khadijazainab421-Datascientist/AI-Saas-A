"use client";

import { useSyncExternalStore, useState } from "react";
import { Copy, ExternalLink, Info } from "lucide-react";

const subscribe = () => () => {};

function getEmbeddedSnapshot() {
  if (typeof window === "undefined") return false;
  try {
    return window.self !== window.top;
  } catch {
    // Cross-origin access to window.top can throw; that itself means iframe.
    return true;
  }
}

function getOriginSnapshot() {
  if (typeof window === "undefined") return "";
  return window.location.origin;
}

/**
 * Detects a cross-site iframe preview and shows the app's OWN direct URL.
 * It never opens a different product's tab — it only copies / displays the
 * current origin so the user can paste it into a normal browser tab.
 */
export function EmbeddedPreviewNotice() {
  const embedded = useSyncExternalStore(subscribe, getEmbeddedSnapshot, () => false);
  const origin = useSyncExternalStore(subscribe, getOriginSnapshot, () => "");
  const [copied, setCopied] = useState(false);

  if (!embedded) return null;

  const directUrl = `${origin}/sign-in`;

  async function copyUrl() {
    try {
      await navigator.clipboard.writeText(directUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div
      role="status"
      className="mb-6 rounded-2xl border border-[#E6D8BD] bg-[#FBF6EB] px-4 py-4"
    >
      <div className="flex items-start gap-2.5">
        <Info size={16} className="mt-0.5 shrink-0 text-[#746444]" aria-hidden="true" />
        <div className="min-w-0">
          <p className="text-xs font-bold text-[#5C5236]">Embedded preview detected</p>
          <p className="mt-1.5 text-[11px] leading-5 text-[#746444]">
            Session cookies can be restricted inside an iframe. This app now uses
            `SameSite=None; Secure; Partitioned` cookies, but the most reliable option is to open
            the direct address below in a normal browser tab and sign in there.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <code className="min-w-0 flex-1 truncate rounded-lg border border-[#E6D8BD] bg-white/70 px-2.5 py-2 text-[10px] text-[#5C5236]">
              {directUrl}
            </code>
            <button
              type="button"
              onClick={copyUrl}
              className="inline-flex h-8 shrink-0 items-center gap-1.5 rounded-lg border border-[#E6D8BD] bg-white px-2.5 text-[10px] font-bold text-[#5C5236] transition-colors hover:bg-[#F5EEDF]"
            >
              {copied ? <Copy size={12} aria-hidden="true" /> : <ExternalLink size={12} aria-hidden="true" />}
              {copied ? "Copied" : "Copy URL"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
