import type {
  AIProviderAdapter,
  GenerationRequest,
  GenerationResult,
  ProviderDefinition,
} from "@/lib/ai/types";

const definition: ProviderDefinition = {
  key: "groq",
  label: "Groq",
  envVar: "GROQ_API_KEY",
  role: "ai",
  isFree: true,
  priority: 2,
  docsUrl: "https://console.groq.com/docs/quickstart",
};

const MODEL = process.env.GROQ_MODEL || "llama-3.1-8b-instant";
const ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";

function readKey() {
  return process.env.GROQ_API_KEY;
}

export const groqProvider: AIProviderAdapter = {
  definition,

  isConfigured() {
    return Boolean(readKey());
  },

  async generate(request: GenerationRequest): Promise<GenerationResult> {
    const key = readKey();
    const started = Date.now();

    if (!key) {
      return {
        ok: false,
        kind: "unconfigured",
        message: "GROQ_API_KEY is not configured.",
        latencyMs: 0,
      };
    }

    try {
      const response = await fetch(ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model: MODEL,
          messages: [
            ...(request.system ? [{ role: "system", content: request.system }] : []),
            { role: "user", content: request.prompt },
          ],
          temperature: 0.4,
          max_tokens: request.maxTokens ?? 1200,
        }),
        signal: AbortSignal.timeout(30_000),
      });

      const latencyMs = Date.now() - started;

      if (response.status === 429) {
        const retryAfter = Number(response.headers.get("retry-after") || 60);
        return {
          ok: false,
          kind: "rate_limited",
          message: "Groq free-tier quota or rate limit reached.",
          retryAfterSeconds: Number.isFinite(retryAfter) ? retryAfter : 60,
          latencyMs,
        };
      }

      if (!response.ok) {
        return {
          ok: false,
          kind: response.status >= 500 ? "provider_error" : "invalid_response",
          message: `Groq returned HTTP ${response.status}.`,
          latencyMs,
        };
      }

      const data = (await response.json()) as {
        choices?: { message?: { content?: string } }[];
        usage?: { prompt_tokens?: number; completion_tokens?: number };
      };

      const text = data.choices?.[0]?.message?.content?.trim();

      if (!text) {
        return {
          ok: false,
          kind: "invalid_response",
          message: "Groq returned no text content.",
          latencyMs,
        };
      }

      return {
        ok: true,
        text,
        tokensIn: data.usage?.prompt_tokens ?? 0,
        tokensOut: data.usage?.completion_tokens ?? 0,
        latencyMs,
      };
    } catch (error) {
      return {
        ok: false,
        kind: "provider_error",
        message: error instanceof Error ? error.message : "Groq request failed.",
        latencyMs: Date.now() - started,
      };
    }
  },
};
