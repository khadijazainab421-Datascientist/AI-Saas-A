import type {
  ProviderDefinition,
  ResearchRequest,
  ResearchResult,
} from "@/lib/ai/types";

export const tavilyDefinition: ProviderDefinition = {
  key: "tavily",
  label: "Tavily Search",
  envVar: "TAVILY_API_KEY",
  role: "research",
  isFree: true,
  priority: 1,
  docsUrl: "https://docs.tavily.com/documentation/api-reference/endpoint/search",
};

const ENDPOINT = "https://api.tavily.com/search";

function readKey() {
  return process.env.TAVILY_API_KEY;
}

export function tavilyConfigured() {
  return Boolean(readKey());
}

/** Real, official Tavily Search call. Never fabricates results. */
export async function tavilySearch(request: ResearchRequest): Promise<ResearchResult> {
  const key = readKey();
  const started = Date.now();

  if (!key) {
    return {
      ok: false,
      kind: "unconfigured",
      message: "TAVILY_API_KEY is not configured.",
      latencyMs: 0,
    };
  }

  try {
    const response = await fetch(ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        query: request.query,
        search_depth: "basic",
        max_results: Math.min(Math.max(request.maxResults ?? 5, 1), 10),
        include_answer: false,
      }),
      signal: AbortSignal.timeout(30_000),
    });

    const latencyMs = Date.now() - started;

    if (response.status === 429) {
      const retryAfter = Number(response.headers.get("retry-after") || 60);
      return {
        ok: false,
        kind: "rate_limited",
        message: "Tavily free credits or rate limit exhausted.",
        retryAfterSeconds: Number.isFinite(retryAfter) ? retryAfter : 60,
        latencyMs,
      };
    }

    if (!response.ok) {
      return {
        ok: false,
        kind: response.status >= 500 ? "provider_error" : "invalid_response",
        message: `Tavily returned HTTP ${response.status}.`,
        latencyMs,
      };
    }

    const data = (await response.json()) as {
      results?: { title?: string; url?: string; content?: string }[];
    };

    const sources = (data.results ?? [])
      .filter((item) => item.url)
      .map((item) => ({
        title: item.title ?? "Untitled source",
        url: item.url as string,
        snippet: (item.content ?? "").slice(0, 500),
      }));

    return {
      ok: true,
      sources,
      // Tavily basic search costs exactly 1 credit per request.
      credits: 1,
      latencyMs,
    };
  } catch (error) {
    return {
      ok: false,
      kind: "provider_error",
      message: error instanceof Error ? error.message : "Tavily request failed.",
      latencyMs: Date.now() - started,
    };
  }
}
