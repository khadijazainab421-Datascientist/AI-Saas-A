import type {
  AIProviderAdapter,
  GenerationRequest,
  GenerationResult,
  ProviderDefinition,
} from "@/lib/ai/types";

const definition: ProviderDefinition = {
  key: "gemini",
  label: "Google Gemini",
  envVar: "GEMINI_API_KEY",
  role: "ai",
  isFree: true,
  priority: 1,
  docsUrl: "https://ai.google.dev/gemini-api/docs",
};

const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;

function readKey() {
  return process.env.GEMINI_API_KEY;
}

export const geminiProvider: AIProviderAdapter = {
  definition,

  isConfigured() {
    return Boolean(readKey());
  },

  async generate(request: GenerationRequest): Promise<GenerationResult> {
    const key = readKey();
    const started = Date.now();

    if (!key) {
      return {
        ok: false,
        kind: "unconfigured",
        message: "GEMINI_API_KEY is not configured.",
        latencyMs: 0,
      };
    }

    try {
      const response = await fetch(ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": key,
        },
        body: JSON.stringify({
          systemInstruction: request.system
            ? { parts: [{ text: request.system }] }
            : undefined,
          contents: [{ parts: [{ text: request.prompt }] }],
          generationConfig: {
            temperature: 0.4,
            maxOutputTokens: request.maxTokens ?? 1200,
          },
        }),
        signal: AbortSignal.timeout(30_000),
      });

      const latencyMs = Date.now() - started;

      if (response.status === 429) {
        const retryAfter = Number(response.headers.get("retry-after") || 60);
        return {
          ok: false,
          kind: "rate_limited",
          message: "Gemini free-tier quota or rate limit reached.",
          retryAfterSeconds: Number.isFinite(retryAfter) ? retryAfter : 60,
          latencyMs,
        };
      }

      if (!response.ok) {
        return {
          ok: false,
          kind: response.status >= 500 ? "provider_error" : "invalid_response",
          message: `Gemini returned HTTP ${response.status}.`,
          latencyMs,
        };
      }

      const data = (await response.json()) as {
        candidates?: { content?: { parts?: { text?: string }[] } }[];
        usageMetadata?: { promptTokenCount?: number; candidatesTokenCount?: number };
      };

      const text = data.candidates?.[0]?.content?.parts
        ?.map((part) => part.text ?? "")
        .join("")
        .trim();

      if (!text) {
        return {
          ok: false,
          kind: "invalid_response",
          message: "Gemini returned no text content.",
          latencyMs,
        };
      }

      return {
        ok: true,
        text,
        tokensIn: data.usageMetadata?.promptTokenCount ?? 0,
        tokensOut: data.usageMetadata?.candidatesTokenCount ?? 0,
        latencyMs,
      };
    } catch (error) {
      return {
        ok: false,
        kind: "provider_error",
        message: error instanceof Error ? error.message : "Gemini request failed.",
        latencyMs: Date.now() - started,
      };
    }
  },
};
