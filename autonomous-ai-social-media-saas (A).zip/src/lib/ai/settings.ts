import { eq } from "drizzle-orm";
import { db } from "@/db";
import { workspaceAiSettings } from "@/db/schema";

/** Returns tenant AI settings, creating the safe defaults on first use. */
export async function getWorkspaceAiSettings(workspaceId: string) {
  const existing = await db
    .select()
    .from(workspaceAiSettings)
    .where(eq(workspaceAiSettings.workspaceId, workspaceId))
    .limit(1);

  if (existing[0]) return existing[0];

  await db
    .insert(workspaceAiSettings)
    .values({ workspaceId })
    .onConflictDoNothing();

  const created = await db
    .select()
    .from(workspaceAiSettings)
    .where(eq(workspaceAiSettings.workspaceId, workspaceId))
    .limit(1);

  return created[0];
}

export async function setAllowPaidProviders(workspaceId: string, allowed: boolean) {
  await getWorkspaceAiSettings(workspaceId);

  await db
    .update(workspaceAiSettings)
    .set({ allowPaidProviders: allowed, updatedAt: new Date() })
    .where(eq(workspaceAiSettings.workspaceId, workspaceId));
}
