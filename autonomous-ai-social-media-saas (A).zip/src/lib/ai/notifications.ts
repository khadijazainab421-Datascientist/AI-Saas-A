import { db } from "@/db";
import { notifications } from "@/db/schema";

/** Persists an in-app notification. Never includes credentials or secrets. */
export async function notifyWorkspace(
  workspaceId: string,
  type: string,
  title: string,
  body: string,
  userId?: string | null,
) {
  await db.insert(notifications).values({
    workspaceId,
    userId: userId ?? null,
    type,
    title,
    body,
  });
}
