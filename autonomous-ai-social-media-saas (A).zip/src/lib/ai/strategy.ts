import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { brandProfiles, contentStrategies, researchRuns } from "@/db/schema";
import type { Business } from "@/db/schema";
import { getBusinessInWorkspace } from "@/lib/tenancy";
import { runAITask } from "@/lib/ai/orchestrator";

function extractJson(text: string): Record<string, unknown> | null {
  const cleaned = text.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end <= start) return null;

  try {
    return JSON.parse(cleaned.slice(start, end + 1)) as Record<string, unknown>;
  } catch {
    return null;
  }
}

function toStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is string => typeof item === "string")
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 12);
}

function buildPrompt(
  business: Business,
  brand: typeof brandProfiles.$inferSelect | undefined,
  research: (typeof researchRuns.$inferSelect)[],
) {
  const sources = research
    .filter((run) => run.status === "completed")
    .flatMap((run) => run.results ?? [])
    .slice(0, 10)
    .map((source) => `- ${source.title}: ${source.url}\n  ${source.snippet.slice(0, 200)}`)
    .join("\n");

  return [
    "Create a content strategy for the business below.",
    "Use only the supplied business profile, real website extraction, and real research sources.",
    "Do not fabricate audience data, performance metrics, competitors, or claims.",
    "",
    `Business: ${business.name}`,
    `Industry: ${business.industry ?? "not provided"}`,
    `Website: ${business.website ?? "not provided"}`,
    `Description: ${business.description ?? "not provided"}`,
    `Brand voice: ${business.brandVoice ?? "not provided"}`,
    `Target audience: ${business.targetAudience ?? "not provided"}`,
    `Goals: ${business.goals ?? "not provided"}`,
    "",
    "Brand profile:",
    brand
      ? [
          `Tone: ${(brand.toneAttributes ?? []).join(", ") || "not analyzed"}`,
          `Audience segments: ${(brand.audienceSegments ?? []).join(", ") || "not analyzed"}`,
          `Value propositions: ${(brand.valuePropositions ?? []).join(", ") || "not analyzed"}`,
          `Sensitive topics requiring review: ${(brand.sensitiveTopics ?? []).join(", ") || "none identified"}`,
          `Website excerpt: ${(brand.rawExcerpt ?? "").slice(0, 1200)}`,
        ].join("\n")
      : "No website analysis has been performed yet.",
    "",
    "Research sources:",
    sources || "No verified research sources are available yet.",
    "",
    "Return ONLY valid JSON with keys: title (string), content_pillars (string array),",
    "formats (string array), cadence (string), rationale (string),",
    "requires_review (boolean). Set requires_review true when evidence is thin",
    "or when any claim could be sensitive, medical, financial, or unverified.",
  ].join("\n");
}

/** Generates a strategy only from real context, via the fallback orchestrator. */
export async function generateStrategy(
  workspaceId: string,
  businessId: string,
  userId?: string,
) {
  const business = await getBusinessInWorkspace(workspaceId, businessId);
  if (!business) throw new Error("Business not found in this workspace.");

  const brandRows = await db
    .select()
    .from(brandProfiles)
    .where(
      and(
        eq(brandProfiles.workspaceId, workspaceId),
        eq(brandProfiles.businessId, businessId),
      ),
    )
    .limit(1);

  const research = await db
    .select()
    .from(researchRuns)
    .where(eq(researchRuns.workspaceId, workspaceId))
    .orderBy(desc(researchRuns.createdAt))
    .limit(5);

  const prompt = buildPrompt(business, brandRows[0], research);

  const outcome = await runAITask({
    workspaceId,
    businessId,
    kind: "strategy",
    prompt,
    system:
      "You are a rigorous content strategist. Ground recommendations in supplied evidence. Flag unsupported or sensitive claims for human review. Never invent performance data.",
    meta: {
      businessName: business.name,
      researchRunCount: research.filter((run) => run.status === "completed").length,
    },
    userId,
  });

  if (outcome.status !== "completed" || !outcome.text) {
    return { outcome, strategyId: null as string | null };
  }

  const parsed = extractJson(outcome.text);

  if (!parsed) {
    // Preserve the real generated work instead of discarding it.
    const saved = await db
      .insert(contentStrategies)
      .values({
        workspaceId,
        businessId,
        sourceTaskId: outcome.taskId,
        title: `${business.name} — strategy draft (needs review)`,
        status: "needs_review",
        pillars: [],
        formats: [],
        rationale: outcome.text.slice(0, 4_000),
      })
      .returning();

    return { outcome, strategyId: saved[0].id };
  }

  const requiresReview = parsed.requires_review === true;

  const saved = await db
    .insert(contentStrategies)
    .values({
      workspaceId,
      businessId,
      sourceTaskId: outcome.taskId,
      title:
        typeof parsed.title === "string" && parsed.title.trim()
          ? parsed.title.trim().slice(0, 200)
          : `${business.name} content strategy`,
      status: requiresReview ? "needs_review" : "generated",
      pillars: toStringArray(parsed.content_pillars),
      formats: toStringArray(parsed.formats),
      cadence:
        typeof parsed.cadence === "string" ? parsed.cadence.slice(0, 500) : null,
      rationale:
        typeof parsed.rationale === "string" ? parsed.rationale.slice(0, 4_000) : null,
    })
    .returning();

  return { outcome, strategyId: saved[0].id };
}
