import { geminiProvider } from "@/lib/ai/providers/gemini";
import { groqProvider } from "@/lib/ai/providers/groq";
import { tavilyDefinition, tavilyConfigured } from "@/lib/ai/providers/tavily";
import type { AIProviderAdapter, ProviderDefinition } from "@/lib/ai/types";

/**
 * Modular provider registry. Adding or replacing a provider means adding one
 * adapter here — the orchestrator, usage tracking and UI do not change.
 */
export const aiAdapters: AIProviderAdapter[] = [geminiProvider, groqProvider].sort(
  (a, b) => a.definition.priority - b.definition.priority,
);

export const researchDefinitions: ProviderDefinition[] = [tavilyDefinition];

export function allProviderDefinitions(): ProviderDefinition[] {
  return [
    ...aiAdapters.map((adapter) => adapter.definition),
    ...researchDefinitions,
  ];
}

export function configuredResearchProviders() {
  return researchDefinitions.filter((definition) =>
    definition.key === "tavily" ? tavilyConfigured() : false,
  );
}

/**
 * Eligible AI providers, in priority order.
 * A paid provider is only eligible when the workspace explicitly allows it.
 */
export function eligibleAiProviders(allowPaidProviders: boolean): AIProviderAdapter[] {
  return aiAdapters.filter((adapter) => {
    if (!adapter.isConfigured()) return false;
    if (!adapter.definition.isFree && !allowPaidProviders) return false;
    return true;
  });
}
