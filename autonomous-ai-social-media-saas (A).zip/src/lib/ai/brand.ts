import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { brandProfiles } from "@/db/schema";
import { getBusinessInWorkspace } from "@/lib/tenancy";
import { extractWebsite } from "@/lib/ai/website";
import { runAITask } from "@/lib/ai/orchestrator";

function extractJson(text: string): Record<string, unknown> | null {
  const cleaned = text
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/, "")
    .trim();

  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end <= start) return null;

  try {
    return JSON.parse(cleaned.slice(start, end + 1)) as Record<string, unknown>;
  } catch {
    return null;
  }
}

function toStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is string => typeof item === "string")
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 12);
}

/**
 * Analyzes a real public website and, when an AI provider is available,
 * structures the findings into a brand profile. The raw extraction is always
 * saved first so no work is lost when the AI step is paused.
 */
export async function analyzeBusinessWebsite(
  workspaceId: string,
  businessId: string,
  userId?: string,
) {
  const business = await getBusinessInWorkspace(workspaceId, businessId);

  if (!business) throw new Error("Business not found in this workspace.");
  if (!business.website) {
    throw new Error("Add a website URL to this business profile first.");
  }

  const extraction = await extractWebsite(business.website);

  const existing = await db
    .select()
    .from(brandProfiles)
    .where(
      and(
        eq(brandProfiles.workspaceId, workspaceId),
        eq(brandProfiles.businessId, businessId),
      ),
    )
    .limit(1);

  const rawExcerpt = [extraction.title, extraction.description, extraction.excerpt]
    .filter(Boolean)
    .join("\n\n")
    .slice(0, 4_000);

  const base = {
    workspaceId,
    businessId,
    sourceUrl: extraction.url,
    status: "extracted",
    rawExcerpt,
    analyzedAt: new Date(),
    updatedAt: new Date(),
  };

  if (existing[0]) {
    await db.update(brandProfiles).set(base).where(eq(brandProfiles.id, existing[0].id));
  } else {
    await db.insert(brandProfiles).values(base);
  }

  const prompt = [
    "Analyze the following real website extraction for a business brand profile.",
    `Business: ${business.name}`,
    `Industry: ${business.industry ?? "not provided"}`,
    `Website: ${extraction.url}`,
    "",
    "Website content:",
    rawExcerpt,
    "",
    "Return ONLY valid JSON with these keys: tone_attributes (string array),",
    "audience_segments (string array), value_propositions (string array),",
    "sensitive_topics (string array), summary (string).",
    "Do not invent facts that are not supported by the provided content.",
    "If information is unavailable, return an empty array or an explicit note.",
  ].join("\n");

  const outcome = await runAITask({
    workspaceId,
    businessId,
    kind: "website_analysis",
    prompt,
    system:
      "You are a careful brand analyst. Ground every claim in supplied evidence. Never fabricate products, customers, metrics, or certifications.",
    meta: { sourceUrl: extraction.url, businessName: business.name },
    userId,
  });

  if (outcome.status === "completed" && outcome.text) {
    const parsed = extractJson(outcome.text);

    if (parsed) {
      await db
        .update(brandProfiles)
        .set({
          status: "analyzed",
          toneAttributes: toStringArray(parsed.tone_attributes),
          audienceSegments: toStringArray(parsed.audience_segments),
          valuePropositions: toStringArray(parsed.value_propositions),
          sensitiveTopics: toStringArray(parsed.sensitive_topics),
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(brandProfiles.workspaceId, workspaceId),
            eq(brandProfiles.businessId, businessId),
          ),
        );
    }
  }

  return {
    extraction: {
      url: extraction.url,
      title: extraction.title,
      excerptLength: rawExcerpt.length,
    },
    task: outcome,
  };
}
