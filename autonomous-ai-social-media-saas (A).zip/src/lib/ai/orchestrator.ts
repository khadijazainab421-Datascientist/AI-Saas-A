import { and, eq, gte, desc } from "drizzle-orm";
import { db } from "@/db";
import { aiTasks, aiUsage, providerHealth } from "@/db/schema";
import type { AiTask } from "@/db/schema";
import { eligibleAiProviders, aiAdapters } from "@/lib/ai/registry";
import { getWorkspaceAiSettings } from "@/lib/ai/settings";
import { notifyWorkspace } from "@/lib/ai/notifications";
import type { HealthState } from "@/lib/ai/types";

const TASK_KINDS = [
  "website_analysis",
  "research",
  "strategy",
  "caption",
  "content_ideas",
] as const;
export type TaskKind = (typeof TASK_KINDS)[number];

type RunTaskInput = {
  workspaceId: string;
  businessId?: string | null;
  kind: TaskKind;
  prompt: string;
  system?: string;
  meta?: Record<string, unknown>;
  taskId?: string;
  userId?: string;
};

export type RunTaskOutcome = {
  taskId: string;
  status: "completed" | "paused";
  text?: string;
  pausedReason?: string;
  providerKey?: string;
};

async function setHealth(
  providerKey: string,
  status: HealthState,
  message?: string,
  retryAfterSeconds?: number,
) {
  const quotaResetAt = retryAfterSeconds
    ? new Date(Date.now() + retryAfterSeconds * 1000)
    : null;

  await db
    .insert(providerHealth)
    .values({
      providerKey,
      status,
      lastCheckedAt: new Date(),
      lastError: message ?? null,
      quotaResetAt,
      consecutiveFailures: status === "healthy" ? 0 : 1,
    })
    .onConflictDoUpdate({
      target: providerHealth.providerKey,
      set: {
        status,
        lastCheckedAt: new Date(),
        lastError: message ?? null,
        quotaResetAt,
        consecutiveFailures: status === "healthy" ? 0 : 1,
      },
    });
}

/** Marks providers whose environment variable is missing, without any network call. */
export async function refreshConfigurationState() {
  for (const adapter of aiAdapters) {
    if (!adapter.isConfigured()) {
      const existing = await db
        .select()
        .from(providerHealth)
        .where(eq(providerHealth.providerKey, adapter.definition.key))
        .limit(1);

      if (!existing[0]) {
        await setHealth(adapter.definition.key, "unconfigured", "API key not configured.");
      }
    }
  }
}

async function pauseTask(
  taskId: string,
  workspaceId: string,
  reason: string,
  userId?: string,
): Promise<RunTaskOutcome> {
  await db
    .update(aiTasks)
    .set({ status: "paused", pausedReason: reason, updatedAt: new Date() })
    .where(eq(aiTasks.id, taskId));

  await notifyWorkspace(
    workspaceId,
    "ai_task_paused",
    "AI task paused",
    reason,
    userId,
  );

  return { taskId, status: "paused", pausedReason: reason };
}

/**
 * Executes an AI task with automatic fallback.
 *
 * 1. Try the primary eligible provider.
 * 2. On quota/availability failure, try the next eligible provider.
 * 3. If all eligible free providers are unavailable, PAUSE the task.
 * 4. Never discard generated work; never switch to a paid provider unless the
 *    workspace has explicitly authorised it.
 */
export async function runAITask(params: RunTaskInput): Promise<RunTaskOutcome> {
  const {
    workspaceId,
    businessId = null,
    kind,
    prompt,
    system,
    meta = {},
    taskId,
    userId,
  } = params;

  const settings = await getWorkspaceAiSettings(workspaceId);

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const usedToday = await db
    .select({ id: aiTasks.id })
    .from(aiTasks)
    .where(
      and(eq(aiTasks.workspaceId, workspaceId), gte(aiTasks.createdAt, startOfDay)),
    );

  let task: AiTask;

  if (taskId) {
    const rows = await db.select().from(aiTasks).where(eq(aiTasks.id, taskId)).limit(1);
    if (!rows[0]) throw new Error("Task not found.");
    task = rows[0];
  } else {
    if (usedToday.length >= settings.maxAiTasksPerDay) {
      const created = await db
        .insert(aiTasks)
        .values({
          workspaceId,
          businessId,
          kind,
          status: "queued",
          input: { prompt, system: system ?? null, ...meta },
        })
        .returning();

      return pauseTask(
        created[0].id,
        workspaceId,
        `Daily AI task limit (${settings.maxAiTasksPerDay}) reached. Task preserved for resume.`,
        userId,
      );
    }

    const created = await db
      .insert(aiTasks)
      .values({
        workspaceId,
        businessId,
        kind,
        status: "queued",
        input: { prompt, system: system ?? null, ...meta },
      })
      .returning();
    task = created[0];
  }

  await refreshConfigurationState();

  const providers = eligibleAiProviders(settings.allowPaidProviders);

  if (providers.length === 0) {
    return pauseTask(
      task.id,
      workspaceId,
      "No eligible AI provider is configured. Configure GEMINI_API_KEY or GROQ_API_KEY, then resume this task.",
      userId,
    );
  }

  const errors: string[] = [];

  for (const adapter of providers) {
    await db
      .update(aiTasks)
      .set({
        status: "running",
        providerKey: adapter.definition.key,
        attemptCount: task.attemptCount + 1,
        pausedReason: null,
        updatedAt: new Date(),
      })
      .where(eq(aiTasks.id, task.id));

    const result = await adapter.generate({ prompt, system, maxTokens: 1400 });

    await db.insert(aiUsage).values({
      workspaceId,
      taskId: task.id,
      providerKey: adapter.definition.key,
      tokensIn: result.ok ? result.tokensIn : 0,
      tokensOut: result.ok ? result.tokensOut : 0,
      credits: 0,
      latencyMs: result.latencyMs,
      status: result.ok ? "success" : result.kind,
    });

    if (result.ok) {
      await db
        .update(aiTasks)
        .set({
          status: "completed",
          output: { text: result.text },
          error: null,
          pausedReason: null,
          updatedAt: new Date(),
        })
        .where(eq(aiTasks.id, task.id));

      await setHealth(adapter.definition.key, "healthy");

      return {
        taskId: task.id,
        status: "completed",
        text: result.text,
        providerKey: adapter.definition.key,
      };
    }

    errors.push(`${adapter.definition.label}: ${result.message}`);

    if (result.kind === "rate_limited") {
      await setHealth(
        adapter.definition.key,
        "rate_limited",
        result.message,
        result.retryAfterSeconds,
      );
    } else {
      await setHealth(
        adapter.definition.key,
        result.kind === "provider_error" ? "down" : "degraded",
        result.message,
      );
    }
  }

  const reason = `All eligible AI providers were unavailable. ${errors.join(" | ")}`;

  await db
    .update(aiTasks)
    .set({ error: reason.slice(0, 2000), updatedAt: new Date() })
    .where(eq(aiTasks.id, task.id));

  return pauseTask(task.id, workspaceId, reason, userId);
}

/** Resumes paused tasks whose input was preserved. */
export async function resumePausedTasks(workspaceId: string, userId?: string) {
  const paused = await db
    .select()
    .from(aiTasks)
    .where(and(eq(aiTasks.workspaceId, workspaceId), eq(aiTasks.status, "paused")))
    .orderBy(desc(aiTasks.createdAt))
    .limit(20);

  const outcomes: RunTaskOutcome[] = [];

  for (const task of paused) {
    const input = task.input as { prompt?: string; system?: string | null };
    if (!input.prompt) continue;

    outcomes.push(
      await runAITask({
        workspaceId,
        businessId: task.businessId,
        kind: task.kind,
        prompt: input.prompt,
        system: input.system ?? undefined,
        taskId: task.id,
        userId,
      }),
    );
  }

  return outcomes;
}
