export type ProviderRole = "ai" | "research";

export type ProviderDefinition = {
  key: string;
  label: string;
  envVar: string;
  role: ProviderRole;
  isFree: boolean;
  priority: number;
  docsUrl: string;
};

export type GenerationRequest = {
  prompt: string;
  system?: string;
  maxTokens?: number;
};

export type GenerationSuccess = {
  ok: true;
  text: string;
  tokensIn: number;
  tokensOut: number;
  latencyMs: number;
};

export type GenerationFailure = {
  ok: false;
  kind: "unconfigured" | "rate_limited" | "provider_error" | "invalid_response";
  message: string;
  retryAfterSeconds?: number;
  latencyMs: number;
};

export type GenerationResult = GenerationSuccess | GenerationFailure;

export type HealthState =
  | "unconfigured"
  | "configured"
  | "healthy"
  | "degraded"
  | "rate_limited"
  | "down";

/** Every adapter is replaceable without touching the orchestrator. */
export interface AIProviderAdapter {
  definition: ProviderDefinition;
  isConfigured(): boolean;
  generate(request: GenerationRequest): Promise<GenerationResult>;
}

export type ResearchRequest = {
  query: string;
  maxResults?: number;
};

export type ResearchSuccess = {
  ok: true;
  sources: { title: string; url: string; snippet: string }[];
  credits: number;
  latencyMs: number;
};

export type ResearchFailure = {
  ok: false;
  kind: "unconfigured" | "rate_limited" | "provider_error" | "invalid_response";
  message: string;
  retryAfterSeconds?: number;
  latencyMs: number;
};

export type ResearchResult = ResearchSuccess | ResearchFailure;
