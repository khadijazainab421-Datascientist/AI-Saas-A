import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  aiTasks,
  aiUsage,
  brandProfiles,
  contentStrategies,
  notifications,
  providerHealth,
  researchRuns,
  workspaceAiSettings,
} from "@/db/schema";
import { allProviderDefinitions } from "@/lib/ai/registry";
import { getWorkspaceAiSettings } from "@/lib/ai/settings";

export async function getProviderStatus(workspaceId: string) {
  await getWorkspaceAiSettings(workspaceId);

  const healthRows = await db.select().from(providerHealth);
  const healthByKey = new Map(healthRows.map((row) => [row.providerKey, row]));

  return allProviderDefinitions().map((definition) => {
    const keyPresent = Boolean(process.env[definition.envVar]);
    const health = healthByKey.get(definition.key);

    return {
      key: definition.key,
      label: definition.label,
      role: definition.role,
      isFree: definition.isFree,
      priority: definition.priority,
      docsUrl: definition.docsUrl,
      envVar: definition.envVar,
      configured: keyPresent,
      status: keyPresent ? health?.status ?? "configured" : "unconfigured",
      lastCheckedAt: health?.lastCheckedAt ?? null,
      lastError: health?.lastError ?? null,
      quotaResetAt: health?.quotaResetAt ?? null,
    };
  });
}

export async function getAiDashboardData(workspaceId: string) {
  const [tasks, usage, brands, research, strategies, notes, settings] = await Promise.all([
    db
      .select()
      .from(aiTasks)
      .where(eq(aiTasks.workspaceId, workspaceId))
      .orderBy(desc(aiTasks.createdAt))
      .limit(20),
    db
      .select()
      .from(aiUsage)
      .where(eq(aiUsage.workspaceId, workspaceId))
      .orderBy(desc(aiUsage.createdAt))
      .limit(100),
    db.select().from(brandProfiles).where(eq(brandProfiles.workspaceId, workspaceId)),
    db
      .select()
      .from(researchRuns)
      .where(eq(researchRuns.workspaceId, workspaceId))
      .orderBy(desc(researchRuns.createdAt))
      .limit(10),
    db
      .select()
      .from(contentStrategies)
      .where(eq(contentStrategies.workspaceId, workspaceId))
      .orderBy(desc(contentStrategies.createdAt))
      .limit(10),
    db
      .select()
      .from(notifications)
      .where(eq(notifications.workspaceId, workspaceId))
      .orderBy(desc(notifications.createdAt))
      .limit(10),
    db
      .select()
      .from(workspaceAiSettings)
      .where(eq(workspaceAiSettings.workspaceId, workspaceId))
      .limit(1),
  ]);

  return { tasks, usage, brands, research, strategies, notifications: notes, settings: settings[0] ?? null };
}

export async function getUnreadNotifications(workspaceId: string) {
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.workspaceId, workspaceId))
    .orderBy(desc(notifications.createdAt))
    .limit(8);
}
