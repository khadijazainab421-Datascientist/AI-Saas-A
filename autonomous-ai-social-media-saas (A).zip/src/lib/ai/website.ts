export type WebsiteExtraction = {
  url: string;
  title: string;
  description: string;
  excerpt: string;
};

const BLOCKED_HOSTS = [
  "localhost",
  "127.0.0.1",
  "0.0.0.0",
  "::1",
  "169.254.169.254",
  "metadata.google.internal",
];

function isPrivateHost(hostname: string) {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, "");

  if (BLOCKED_HOSTS.includes(host)) return true;
  if (host.endsWith(".localhost") || host.endsWith(".internal")) return true;
  if (/^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host)) return true;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(host)) return true;
  if (/^169\.254\./.test(host)) return true;

  return false;
}

function decodeEntities(value: string) {
  return value
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">");
}

/**
 * Reads a public business website. Real extraction only — no AI, no invented
 * content. Redirects are not followed and private network targets are blocked
 * to reduce SSRF risk. DNS-rebinding protection requires a production-grade
 * egress proxy and is documented as a Phase 8 hardening item.
 */
export async function extractWebsite(urlString: string): Promise<WebsiteExtraction> {
  let url: URL;

  try {
    url = new URL(urlString);
  } catch {
    throw new Error("Please enter a valid website URL, including https://");
  }

  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error("Only http and https websites can be analyzed.");
  }

  if (isPrivateHost(url.hostname)) {
    throw new Error("Private or local network addresses cannot be analyzed.");
  }

  const response = await fetch(url.toString(), {
    redirect: "manual",
    signal: AbortSignal.timeout(8_000),
    headers: {
      "User-Agent": "Cadence/0.1 (public business website analysis)",
      Accept: "text/html,text/plain;q=0.9",
    },
  });

  if (response.status >= 300 && response.status < 400) {
    throw new Error("Website redirects are not followed for security reasons.");
  }

  if (!response.ok) {
    throw new Error(`Website returned HTTP ${response.status}.`);
  }

  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("text/html") && !contentType.includes("text/plain")) {
    throw new Error("Website did not return readable HTML or text.");
  }

  const declaredLength = Number(response.headers.get("content-length") ?? 0);
  if (declaredLength > 1_000_000) {
    throw new Error("Website response is too large to analyze safely.");
  }

  const html = (await response.text()).slice(0, 200_000);

  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const descriptionMatch =
    html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']*)["']/i) ??
    html.match(/<meta[^>]+content=["']([^"']*)["'][^>]+name=["']description["']/i) ??
    html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']*)["']/i);

  const withoutScripts = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ");

  const excerpt = decodeEntities(
    withoutScripts
      .replace(/<[^>]+>/g, " ")
      .replace(/\s+/g, " ")
      .trim(),
  ).slice(0, 3_000);

  return {
    url: url.toString(),
    title: decodeEntities(titleMatch?.[1]?.trim() ?? "").slice(0, 200),
    description: decodeEntities(descriptionMatch?.[1]?.trim() ?? "").slice(0, 500),
    excerpt,
  };
}
