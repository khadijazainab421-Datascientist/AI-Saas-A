import { eq } from "drizzle-orm";
import { db } from "@/db";
import { aiUsage, providerHealth, researchRuns } from "@/db/schema";
import type { ResearchRun } from "@/db/schema";
import { configuredResearchProviders } from "@/lib/ai/registry";
import { tavilySearch, tavilyDefinition } from "@/lib/ai/providers/tavily";
import { notifyWorkspace } from "@/lib/ai/notifications";

async function setHealth(
  status: "unconfigured" | "healthy" | "degraded" | "rate_limited" | "down" | "configured",
  message?: string,
  retryAfterSeconds?: number,
) {
  await db
    .insert(providerHealth)
    .values({
      providerKey: tavilyDefinition.key,
      status,
      lastCheckedAt: new Date(),
      lastError: message ?? null,
      quotaResetAt: retryAfterSeconds
        ? new Date(Date.now() + retryAfterSeconds * 1000)
        : null,
      consecutiveFailures: status === "healthy" ? 0 : 1,
    })
    .onConflictDoUpdate({
      target: providerHealth.providerKey,
      set: {
        status,
        lastCheckedAt: new Date(),
        lastError: message ?? null,
        consecutiveFailures: status === "healthy" ? 0 : 1,
      },
    });
}

/** Real research run. Unconfigured or failed runs are recorded honestly. */
export async function runResearch(
  workspaceId: string,
  businessId: string | null,
  query: string,
  userId?: string,
): Promise<ResearchRun> {
  const created = await db
    .insert(researchRuns)
    .values({ workspaceId, businessId, query, status: "pending" })
    .returning();

  const run = created[0];
  const providers = configuredResearchProviders();

  if (providers.length === 0) {
    await db
      .update(researchRuns)
      .set({
        status: "unconfigured",
        error: "TAVILY_API_KEY is not configured. No sources were invented.",
      })
      .where(eq(researchRuns.id, run.id));

    await setHealth("unconfigured", "TAVILY_API_KEY is not configured.");
    await notifyWorkspace(
      workspaceId,
      "research_unconfigured",
      "Research not started",
      "No research provider is configured, so no sources were generated. Configure TAVILY_API_KEY and run again.",
      userId,
    );

    return { ...run, status: "unconfigured" };
  }

  const result = await tavilySearch({ query, maxResults: 5 });

  await db.insert(aiUsage).values({
    workspaceId,
    providerKey: tavilyDefinition.key,
    credits: result.ok ? result.credits : 0,
    tokensIn: 0,
    tokensOut: 0,
    latencyMs: result.latencyMs,
    status: result.ok ? "success" : result.kind,
  });

  if (!result.ok) {
    await db
      .update(researchRuns)
      .set({ status: result.kind === "rate_limited" ? "rate_limited" : "failed", error: result.message })
      .where(eq(researchRuns.id, run.id));

    await setHealth(
      result.kind === "rate_limited" ? "rate_limited" : "down",
      result.message,
      result.retryAfterSeconds,
    );

    await notifyWorkspace(
      workspaceId,
      "research_interrupted",
      "Research interrupted",
      result.message,
      userId,
    );

    return {
      ...run,
      status: result.kind === "rate_limited" ? "rate_limited" : "failed",
      error: result.message,
    };
  }

  await db
    .update(researchRuns)
    .set({
      status: "completed",
      sourceCount: result.sources.length,
      results: result.sources,
    })
    .where(eq(researchRuns.id, run.id));

  await setHealth("healthy");

  return {
    ...run,
    status: "completed",
    sourceCount: result.sources.length,
    results: result.sources,
  };
}
