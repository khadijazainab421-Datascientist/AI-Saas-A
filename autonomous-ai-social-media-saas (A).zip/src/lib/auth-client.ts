import { createAuthClient } from "better-auth/react";

/**
 * No baseURL is set on purpose.
 *
 * The browser client must always call the origin it was loaded from. A static
 * baseURL (for example http://localhost:3000) gets baked into the client bundle
 * and breaks sign-in inside hosted/embedded previews.
 */
export const authClient = createAuthClient();

export const { signIn, signUp, signOut, useSession } = authClient;
