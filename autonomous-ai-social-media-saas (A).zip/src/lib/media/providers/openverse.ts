import type { MediaProviderAdapter, MediaSearchResult, SourcedAsset } from "@/lib/media/types";

const ENDPOINT = "https://api.openverse.org/v1/images/";

/**
 * Openverse (WordPress) — openly licensed image search.
 * No API key, no account, no credit card. Anonymous rate limits apply.
 * Every result carries creator/license/attribution so CC obligations can be met.
 */
export const openverseProvider: MediaProviderAdapter = {
  definition: {
    key: "openverse",
    label: "Openverse",
    envVar: null,
    requiresKey: false,
    available: true,
    freeTier: "Keyless anonymous access; low anonymous rate limits (documented ~100/day, 5/hour). No card.",
    docsUrl: "https://docs.openverse.org/",
    note: "Primary keyless media source. Attribution is stored with every asset.",
  },

  isConfigured() {
    return true;
  },

  async search(query: string, limit: number): Promise<MediaSearchResult> {
    const started = Date.now();

    try {
      const url = new URL(ENDPOINT);
      url.searchParams.set("q", query);
      url.searchParams.set("page_size", String(Math.min(Math.max(limit, 1), 20)));
      url.searchParams.set("license_type", "commercial");

      const response = await fetch(url.toString(), {
        headers: { Accept: "application/json", "User-Agent": "Cadence/0.1 (content studio)" },
        signal: AbortSignal.timeout(15_000),
      });

      const latencyMs = Date.now() - started;

      if (response.status === 429) {
        return {
          ok: false,
          providerKey: "openverse",
          kind: "rate_limited",
          message: "Openverse anonymous rate limit reached. Try again later or register for higher limits.",
          latencyMs,
        };
      }

      if (!response.ok) {
        return {
          ok: false,
          providerKey: "openverse",
          kind: "provider_error",
          message: `Openverse returned HTTP ${response.status}.`,
          latencyMs,
        };
      }

      const data = (await response.json()) as {
        results?: {
          id?: string;
          title?: string;
          url?: string;
          thumbnail?: string;
          creator?: string;
          license?: string;
          license_url?: string;
          attribution?: string;
          foreign_landing_url?: string;
          width?: number;
          height?: number;
        }[];
      };

      const assets: SourcedAsset[] = (data.results ?? [])
        .filter((item) => Boolean(item.url))
        .map((item) => ({
          providerId: item.id ?? item.url ?? "",
          title: item.title ?? "Untitled image",
          url: item.url as string,
          thumbnailUrl: item.thumbnail ?? null,
          creator: item.creator ?? null,
          license: item.license ?? null,
          licenseUrl: item.license_url ?? null,
          attribution: item.attribution ?? null,
          sourceUrl: item.foreign_landing_url ?? null,
          width: item.width ?? null,
          height: item.height ?? null,
        }));

      return { ok: true, providerKey: "openverse", assets, latencyMs };
    } catch (error) {
      return {
        ok: false,
        providerKey: "openverse",
        kind: "provider_error",
        message: error instanceof Error ? error.message : "Openverse request failed.",
        latencyMs: Date.now() - started,
      };
    }
  },
};
