import type { MediaProviderAdapter, MediaSearchResult, SourcedAsset } from "@/lib/media/types";

const ENDPOINT = "https://api.pexels.com/v1/search";

/**
 * Optional legacy provider. Pexels paused new API key issuance in late
 * September 2026, so this is documented but NOT recommended for new builds.
 */
export const pexelsProvider: MediaProviderAdapter = {
  definition: {
    key: "pexels",
    label: "Pexels",
    envVar: "PEXELS_API_KEY",
    requiresKey: true,
    available: false,
    freeTier: "200 requests/hour and 20,000/month; free, no card.",
    docsUrl: "https://www.pexels.com/api/documentation/",
    note: "NEW API KEY ISSUANCE IS CURRENTLY PAUSED (since Sept 2026). Existing keys still work. Not recommended for new integrations.",
  },

  isConfigured() {
    return Boolean(process.env.PEXELS_API_KEY);
  },

  async search(query: string, limit: number): Promise<MediaSearchResult> {
    const key = process.env.PEXELS_API_KEY;
    const started = Date.now();

    if (!key) {
      return {
        ok: false,
        providerKey: "pexels",
        kind: "unconfigured",
        message: "PEXELS_API_KEY is not configured (and new key issuance is currently paused).",
        latencyMs: 0,
      };
    }

    try {
      const url = new URL(ENDPOINT);
      url.searchParams.set("query", query);
      url.searchParams.set("per_page", String(Math.min(Math.max(limit, 1), 20)));

      const response = await fetch(url.toString(), {
        headers: { Authorization: key, Accept: "application/json" },
        signal: AbortSignal.timeout(15_000),
      });

      const latencyMs = Date.now() - started;

      if (response.status === 429) {
        return {
          ok: false,
          providerKey: "pexels",
          kind: "rate_limited",
          message: "Pexels rate limit reached.",
          latencyMs,
        };
      }

      if (!response.ok) {
        return {
          ok: false,
          providerKey: "pexels",
          kind: "provider_error",
          message: `Pexels returned HTTP ${response.status}.`,
          latencyMs,
        };
      }

      const data = (await response.json()) as {
        photos?: {
          id?: number;
          alt?: string;
          src?: { medium?: string; large?: string };
          photographer?: string;
          url?: string;
          width?: number;
          height?: number;
        }[];
      };

      const assets: SourcedAsset[] = (data.photos ?? [])
        .filter((item) => Boolean(item.src?.large))
        .map((item) => ({
          providerId: String(item.id ?? ""),
          title: item.alt ?? "Pexels photo",
          url: item.src?.large as string,
          thumbnailUrl: item.src?.medium ?? null,
          creator: item.photographer ?? null,
          license: "Pexels License",
          licenseUrl: "https://www.pexels.com/license/",
          attribution: item.photographer
            ? `Photo by ${item.photographer} on Pexels`
            : "Photo on Pexels",
          sourceUrl: item.url ?? null,
          width: item.width ?? null,
          height: item.height ?? null,
        }));

      return { ok: true, providerKey: "pexels", assets, latencyMs };
    } catch (error) {
      return {
        ok: false,
        providerKey: "pexels",
        kind: "provider_error",
        message: error instanceof Error ? error.message : "Pexels request failed.",
        latencyMs: Date.now() - started,
      };
    }
  },
};
