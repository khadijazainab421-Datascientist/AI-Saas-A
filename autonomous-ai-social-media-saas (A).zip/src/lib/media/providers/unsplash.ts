import type { MediaProviderAdapter, MediaSearchResult, SourcedAsset } from "@/lib/media/types";

const ENDPOINT = "https://api.unsplash.com/search/photos";

/** Optional higher-quality source. Requires a free Unsplash Access Key. */
export const unsplashProvider: MediaProviderAdapter = {
  definition: {
    key: "unsplash",
    label: "Unsplash",
    envVar: "UNSPLASH_ACCESS_KEY",
    requiresKey: true,
    available: true,
    freeTier: "Demo 50 requests/hour; production approval raises it. No credit card. Image loads do not count.",
    docsUrl: "https://unsplash.com/documentation",
    note: "Optional. Requires UNSPLASH_ACCESS_KEY. Unconfigured state is reported, never simulated.",
  },

  isConfigured() {
    return Boolean(process.env.UNSPLASH_ACCESS_KEY);
  },

  async search(query: string, limit: number): Promise<MediaSearchResult> {
    const key = process.env.UNSPLASH_ACCESS_KEY;
    const started = Date.now();

    if (!key) {
      return {
        ok: false,
        providerKey: "unsplash",
        kind: "unconfigured",
        message: "UNSPLASH_ACCESS_KEY is not configured.",
        latencyMs: 0,
      };
    }

    try {
      const url = new URL(ENDPOINT);
      url.searchParams.set("query", query);
      url.searchParams.set("per_page", String(Math.min(Math.max(limit, 1), 20)));

      const response = await fetch(url.toString(), {
        headers: { Authorization: `Client-ID ${key}`, Accept: "application/json" },
        signal: AbortSignal.timeout(15_000),
      });

      const latencyMs = Date.now() - started;

      if (response.status === 429 || response.status === 403) {
        return {
          ok: false,
          providerKey: "unsplash",
          kind: "rate_limited",
          message: "Unsplash demo rate limit reached.",
          latencyMs,
        };
      }

      if (!response.ok) {
        return {
          ok: false,
          providerKey: "unsplash",
          kind: "provider_error",
          message: `Unsplash returned HTTP ${response.status}.`,
          latencyMs,
        };
      }

      const data = (await response.json()) as {
        results?: {
          id?: string;
          description?: string;
          alt_description?: string;
          urls?: { small?: string; regular?: string };
          user?: { name?: string; links?: { html?: string } };
          links?: { html?: string };
          width?: number;
          height?: number;
        }[];
      };

      const assets: SourcedAsset[] = (data.results ?? [])
        .filter((item) => Boolean(item.urls?.regular))
        .map((item) => ({
          providerId: item.id ?? "",
          title: item.description ?? item.alt_description ?? "Unsplash photo",
          url: item.urls?.regular as string,
          thumbnailUrl: item.urls?.small ?? null,
          creator: item.user?.name ?? null,
          license: "Unsplash License",
          licenseUrl: "https://unsplash.com/license",
          attribution: item.user?.name
            ? `Photo by ${item.user.name} on Unsplash`
            : "Photo on Unsplash",
          sourceUrl: item.links?.html ?? item.user?.links?.html ?? null,
          width: item.width ?? null,
          height: item.height ?? null,
        }));

      return { ok: true, providerKey: "unsplash", assets, latencyMs };
    } catch (error) {
      return {
        ok: false,
        providerKey: "unsplash",
        kind: "provider_error",
        message: error instanceof Error ? error.message : "Unsplash request failed.",
        latencyMs: Date.now() - started,
      };
    }
  },
};
