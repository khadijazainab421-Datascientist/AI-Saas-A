export type SourcedAsset = {
  providerId: string;
  title: string;
  url: string;
  thumbnailUrl: string | null;
  creator: string | null;
  license: string | null;
  licenseUrl: string | null;
  attribution: string | null;
  sourceUrl: string | null;
  width: number | null;
  height: number | null;
};

export type MediaSearchResult =
  | { ok: true; providerKey: string; assets: SourcedAsset[]; latencyMs: number }
  | {
      ok: false;
      providerKey: string;
      kind: "unconfigured" | "rate_limited" | "provider_error" | "invalid_response";
      message: string;
      latencyMs: number;
    };

export type MediaProviderDefinition = {
  key: string;
  label: string;
  envVar: string | null;
  requiresKey: boolean;
  available: boolean;
  freeTier: string;
  docsUrl: string;
  note: string;
};

export interface MediaProviderAdapter {
  definition: MediaProviderDefinition;
  isConfigured(): boolean;
  search(query: string, limit: number): Promise<MediaSearchResult>;
}
