/**
 * Video capability is intentionally honest: MP4 rendering requires FFmpeg and
 * a background worker. Neither is available in Phase 4. We provide a real
 * storyboard structure (scenes, durations, captions) that Phase 6 can render.
 */

export type VideoScene = {
  position: number;
  durationSeconds: number;
  visual: string;
  onScreenText: string;
  narration?: string;
};

export type VideoStoryboard = {
  format: "short_form_vertical";
  totalSeconds: number;
  scenes: VideoScene[];
  renderingAvailable: false;
  renderingNote: string;
};

export function videoCapability() {
  return {
    ffmpegAvailable: false,
    workerAvailable: false,
    supported: false,
    reason:
      "FFmpeg is not available in this environment and no background publishing worker exists until Phase 6. Storyboards are real and persisted; MP4 rendering is pending.",
  };
}

export function buildStoryboard(headline: string, points: string[]): VideoStoryboard {
  const scenes: VideoScene[] = [
    {
      position: 1,
      durationSeconds: 3,
      visual: "Branded title card generated locally",
      onScreenText: headline.slice(0, 80),
    },
    ...points.slice(0, 5).map((point, index) => ({
      position: index + 2,
      durationSeconds: 4,
      visual: `Slide ${index + 2} from approved brand assets`,
      onScreenText: point.slice(0, 100),
    })),
  ];

  return {
    format: "short_form_vertical",
    totalSeconds: scenes.reduce((sum, scene) => sum + scene.durationSeconds, 0),
    scenes,
    renderingAvailable: false,
    renderingNote: videoCapability().reason,
  };
}
