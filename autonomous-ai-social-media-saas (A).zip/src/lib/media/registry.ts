import { openverseProvider } from "@/lib/media/providers/openverse";
import { unsplashProvider } from "@/lib/media/providers/unsplash";
import { pexelsProvider } from "@/lib/media/providers/pexels";
import type { MediaProviderAdapter, MediaProviderDefinition } from "@/lib/media/types";

/**
 * Modular media registry. Openverse is keyless and always available, so it is
 * the default. Key-based providers are optional enhancements and are never
 * simulated when unconfigured.
 */
export const mediaAdapters: MediaProviderAdapter[] = [
  openverseProvider,
  unsplashProvider,
  pexelsProvider,
];

export function mediaProviderStatus(): (MediaProviderDefinition & { configured: boolean })[] {
  return mediaAdapters.map((adapter) => ({
    ...adapter.definition,
    configured: adapter.isConfigured(),
  }));
}

/** Returns the first configured adapter in registry order. */
export function primaryMediaAdapter(): MediaProviderAdapter {
  return mediaAdapters.find((adapter) => adapter.isConfigured()) ?? openverseProvider;
}
