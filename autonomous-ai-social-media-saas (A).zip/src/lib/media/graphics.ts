/**
 * Local branded SVG graphic generator.
 *
 * This is a real, deterministic, dependency-free capability — NOT a fake
 * integration. It uses only the workspace's own brand text and the requested
 * headline, and requires no external image-generation API.
 */

function escapeXml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function wrapText(value: string, maxChars: number, maxLines: number): string[] {
  const words = value.trim().split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (candidate.length > maxChars && current) {
      lines.push(current);
      current = word;
      if (lines.length >= maxLines) break;
    } else {
      current = candidate;
    }
  }

  if (current && lines.length < maxLines) lines.push(current);
  return lines.slice(0, maxLines);
}

export function createBrandedGraphic({
  brandName,
  headline,
  accent = "#155E59",
}: {
  brandName: string;
  headline: string;
  accent?: string;
}): string {
  const safeBrand = escapeXml(brandName.trim().slice(0, 60) || "Cadence");
  const lines = wrapText(headline.trim().slice(0, 160) || "Your story, clearly told.", 28, 3);

  const textElements = lines
    .map(
      (line, index) =>
        `<text x="72" y="${300 + index * 62}" font-family="Georgia, serif" font-size="46" fill="#172B29">${escapeXml(line)}</text>`,
    )
    .join("");

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1080" width="1080" height="1080" role="img" aria-label="${safeBrand} branded graphic">
  <rect width="1080" height="1080" fill="#F0F6F2"/>
  <circle cx="880" cy="220" r="260" fill="#DCEBE4" opacity="0.7"/>
  <path d="M0 820 Q 270 700 540 820 T 1080 820 L 1080 1080 L 0 1080 Z" fill="${accent}" opacity="0.10"/>
  <rect x="72" y="88" width="56" height="56" rx="16" fill="${accent}"/>
  <path d="M88 116 q12 -16 24 0 t24 0" fill="none" stroke="#FAFCFB" stroke-width="3" stroke-linecap="round"/>
  <text x="148" y="127" font-family="Georgia, serif" font-size="38" fill="#164E4A">${safeBrand}</text>
  <line x1="72" y1="196" x2="1008" y2="196" stroke="#A7BDB1" stroke-width="1"/>
  <text x="72" y="252" font-family="Manrope, Arial, sans-serif" font-size="17" letter-spacing="4" fill="#697A75">CADENCE · BRAND GRAPHIC</text>
  ${textElements}
  <line x1="72" y1="940" x2="1008" y2="940" stroke="#A7BDB1" stroke-width="1"/>
  <text x="72" y="990" font-family="Manrope, Arial, sans-serif" font-size="18" fill="#697A75">Generated locally · no external media API</text>
</svg>`;
}

export function svgToDataUrl(svg: string) {
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
