import { z } from "zod";

export const signUpSchema = z.object({
  name: z.string().trim().min(2, "Please enter your full name.").max(80),
  email: z.string().trim().email("Please enter a valid email address."),
  password: z
    .string()
    .min(10, "Password must be at least 10 characters.")
    .max(128, "Password must be 128 characters or fewer."),
});

export const signInSchema = z.object({
  email: z.string().trim().email("Please enter a valid email address."),
  password: z.string().min(1, "Please enter your password."),
});

export const workspaceSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Workspace name must be at least 2 characters.")
    .max(60, "Workspace name must be 60 characters or fewer."),
});

export const businessSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Business name must be at least 2 characters.")
    .max(80, "Business name must be 80 characters or fewer."),
  website: z
    .string()
    .trim()
    .url("Please enter a valid URL, including https://")
    .or(z.literal(""))
    .optional(),
  industry: z.string().trim().max(80).optional(),
  description: z.string().trim().max(2000).optional(),
  brandVoice: z.string().trim().max(1000).optional(),
  targetAudience: z.string().trim().max(1000).optional(),
  goals: z.string().trim().max(1000).optional(),
  timezone: z.string().trim().min(1).max(64).optional(),
});

export type SignUpInput = z.infer<typeof signUpSchema>;
export type SignInInput = z.infer<typeof signInSchema>;
export type WorkspaceInput = z.infer<typeof workspaceSchema>;
export type BusinessInput = z.infer<typeof businessSchema>;
