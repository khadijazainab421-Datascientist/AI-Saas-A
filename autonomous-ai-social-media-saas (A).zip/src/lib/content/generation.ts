import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { brandProfiles, contentItems, contentStrategies } from "@/db/schema";
import { getBusinessInWorkspace } from "@/lib/tenancy";
import { runAITask } from "@/lib/ai/orchestrator";

function extractJson(text: string): Record<string, unknown> | null {
  const cleaned = text.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end <= start) return null;
  try {
    return JSON.parse(cleaned.slice(start, end + 1)) as Record<string, unknown>;
  } catch {
    return null;
  }
}

function toStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is string => typeof item === "string")
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 15);
}

async function contextFor(workspaceId: string, businessId: string) {
  const business = await getBusinessInWorkspace(workspaceId, businessId);
  if (!business) throw new Error("Business not found in this workspace.");

  const brands = await db
    .select()
    .from(brandProfiles)
    .where(
      and(eq(brandProfiles.workspaceId, workspaceId), eq(brandProfiles.businessId, businessId)),
    )
    .limit(1);

  const strategies = await db
    .select()
    .from(contentStrategies)
    .where(eq(contentStrategies.workspaceId, workspaceId))
    .orderBy(desc(contentStrategies.createdAt))
    .limit(1);

  return { business, brand: brands[0], strategy: strategies[0] };
}

function contextBlock(ctx: Awaited<ReturnType<typeof contextFor>>) {
  const { business, brand, strategy } = ctx;
  return [
    `Business: ${business.name}`,
    `Industry: ${business.industry ?? "not provided"}`,
    `Website: ${business.website ?? "not provided"}`,
    `Description: ${business.description ?? "not provided"}`,
    `Brand voice: ${business.brandVoice ?? "not provided"}`,
    `Audience: ${business.targetAudience ?? "not provided"}`,
    `Goals: ${business.goals ?? "not provided"}`,
    `Brand profile tone: ${(brand?.toneAttributes ?? []).join(", ") || "not analyzed"}`,
    `Sensitive topics: ${(brand?.sensitiveTopics ?? []).join(", ") || "none identified"}`,
    `Strategy pillars: ${(strategy?.pillars ?? []).join(", ") || "no strategy yet"}`,
    `Strategy cadence: ${strategy?.cadence ?? "not defined"}`,
  ].join("\n");
}

/** Generates one real caption via the hybrid fallback orchestrator. */
export async function generateCaption(
  workspaceId: string,
  businessId: string,
  topic: string,
  platform: string,
  userId?: string,
) {
  const ctx = await contextFor(workspaceId, businessId);

  const prompt = [
    "Write one social media caption using ONLY the context below.",
    "Do not invent products, customers, metrics, certifications, or results.",
    "Keep the brand voice. Flag unverified or sensitive claims for review.",
    "",
    contextBlock(ctx),
    "",
    `Topic: ${topic}`,
    `Platform: ${platform}`,
    "",
    "Return ONLY valid JSON: { title, caption, hashtags (string array), rationale, requires_review (boolean) }.",
  ].join("\n");

  const outcome = await runAITask({
    workspaceId,
    businessId,
    kind: "caption",
    prompt,
    system:
      "You are a careful brand copywriter. Never fabricate facts. Adapt tone to the stated platform. Mark sensitive or unsupported claims for human review.",
    meta: { topic, platform, businessName: ctx.business.name },
    userId,
  });

  if (outcome.status !== "completed" || !outcome.text) {
    return { outcome, contentId: null as string | null };
  }

  const parsed = extractJson(outcome.text);
  if (!parsed) {
    return { outcome, contentId: null as string | null };
  }

  const saved = await db
    .insert(contentItems)
    .values({
      workspaceId,
      businessId,
      sourceTaskId: outcome.taskId,
      createdBy: userId ?? null,
      title:
        typeof parsed.title === "string" && parsed.title.trim()
          ? parsed.title.trim().slice(0, 200)
          : `Caption — ${topic.slice(0, 60)}`,
      type: "post",
      status: parsed.requires_review === true ? "needs_review" : "draft",
      platform,
      caption: typeof parsed.caption === "string" ? parsed.caption.slice(0, 5000) : "",
      body: typeof parsed.rationale === "string" ? parsed.rationale.slice(0, 4000) : "",
      hashtags: toStringArray(parsed.hashtags),
      requiresReview: parsed.requires_review === true,
    })
    .returning();

  return { outcome, contentId: saved[0].id };
}

/** Generates content ideas; only real AI output is persisted. */
export async function generateContentIdeas(
  workspaceId: string,
  businessId: string,
  userId?: string,
) {
  const ctx = await contextFor(workspaceId, businessId);

  const prompt = [
    "Propose 4 concrete content ideas using ONLY the context below.",
    "Do not invent audience data, performance metrics, or unverifiable claims.",
    "",
    contextBlock(ctx),
    "",
    "Return ONLY valid JSON: { ideas: [{ title, concept, format, platform, requires_review }] }.",
  ].join("\n");

  const outcome = await runAITask({
    workspaceId,
    businessId,
    kind: "content_ideas",
    prompt,
    system:
      "You are a rigorous content planner. Ground every idea in supplied evidence and flag sensitive topics for review.",
    meta: { businessName: ctx.business.name },
    userId,
  });

  if (outcome.status !== "completed" || !outcome.text) {
    return { outcome, created: 0 };
  }

  const parsed = extractJson(outcome.text);
  const ideas = Array.isArray(parsed?.ideas) ? parsed.ideas : [];

  let created = 0;
  for (const raw of ideas.slice(0, 6)) {
    if (!raw || typeof raw !== "object") continue;
    const idea = raw as Record<string, unknown>;
    const title = typeof idea.title === "string" ? idea.title.trim() : "";
    if (!title) continue;

    await db.insert(contentItems).values({
      workspaceId,
      businessId,
      sourceTaskId: outcome.taskId,
      createdBy: userId ?? null,
      title: title.slice(0, 200),
      type: typeof idea.format === "string" ? idea.format.slice(0, 60) : "idea",
      status: idea.requires_review === true ? "needs_review" : "draft",
      platform: typeof idea.platform === "string" ? idea.platform.slice(0, 40) : "multi",
      caption: typeof idea.concept === "string" ? idea.concept.slice(0, 3000) : "",
      requiresReview: idea.requires_review === true,
    });
    created += 1;
  }

  return { outcome, created };
}
