import { createHash } from "node:crypto";
import { betterAuth } from "better-auth";
import { nextCookies } from "better-auth/next-js";
import { drizzleAdapter } from "@better-auth/drizzle-adapter";
import { db } from "@/db";
import * as schema from "@/db/schema";

// Production must supply BETTER_AUTH_SECRET. For sandbox builds where the
// platform resets .env, we derive a deterministic non-hardcoded fallback from
// the existing DATABASE_URL so no secret is ever committed to source control.
const envSecret = process.env.BETTER_AUTH_SECRET;
const derivedSecret = createHash("sha256")
  .update(`cadence-session-v1:${process.env.DATABASE_URL ?? "no-database-url"}`)
  .digest("base64url");
const configuredSecret = envSecret || derivedSecret;
const configuredUrl = process.env.BETTER_AUTH_URL || "http://localhost:3000";
const isProduction = process.env.NODE_ENV === "production";

if (!envSecret && isProduction) {
  console.warn(
    "[auth] BETTER_AUTH_SECRET is not configured; using an environment-derived fallback. Set it before any real deployment.",
  );
}

/**
 * Dynamic base URL is required for preview deployments. The platform serves
 * this app on rotating HTTPS hosts (and locally on localhost), so a single
 * static http://localhost:3000 base URL causes trusted-origin and Secure-cookie
 * mismatches. `allowedHosts` entries are automatically added to trustedOrigins.
 */
const baseURL = {
  allowedHosts: ["localhost:*", "127.0.0.1:*", "*.e2b.app", "*.vercel.app"],
  protocol: isProduction ? ("https" as const) : ("http" as const),
  fallback: configuredUrl,
};

export const auth = betterAuth({
  baseURL,
  secret: configuredSecret,

  database: drizzleAdapter(db, {
    provider: "pg",
    schema,
  }),

  emailAndPassword: {
    enabled: true,
    minPasswordLength: 10,
    maxPasswordLength: 128,
    // Email verification is intentionally deferred until a transactional email
    // provider is selected and configured. See docs/PHASE-2.md.
    requireEmailVerification: false,
  },

  session: {
    expiresIn: 60 * 60 * 24 * 7, // 7 days
    updateAge: 60 * 60 * 24, // refresh expiry once per day
    cookieCache: {
      enabled: false,
    },
  },

  trustedOrigins: [configuredUrl],

  advanced: {
    // Embedded previews are cross-site iframes. SameSite=None + Secure +
    // Partitioned (CHIPS) is the only configuration browsers retain there.
    // Local http development keeps Lax / non-secure cookies.
    useSecureCookies: isProduction,
    defaultCookieAttributes: {
      httpOnly: true,
      secure: isProduction,
      sameSite: isProduction ? "none" : "lax",
      partitioned: isProduction,
      path: "/",
    },
    cookies: {
      session_token: {
        attributes: {
          httpOnly: true,
          secure: isProduction,
          sameSite: isProduction ? "none" : "lax",
          partitioned: isProduction,
          path: "/",
        },
      },
    },
    database: {
      generateId: false,
    },
  },

  plugins: [nextCookies()],
});

export type Session = typeof auth.$Infer.Session;
