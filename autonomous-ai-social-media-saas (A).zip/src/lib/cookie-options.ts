/**
 * Shared cookie attributes for app-owned cookies.
 *
 * Production previews are commonly rendered inside a cross-site iframe. In
 * that context `SameSite=Lax` cookies are dropped by the browser, so we use
 * `SameSite=None` + `Secure` + CHIPS (`Partitioned`). Local development runs
 * on plain http://localhost and must keep `Lax` / non-secure cookies.
 */
export function sessionCookieAttributes(maxAge?: number) {
  const embeddedPreview = process.env.NODE_ENV === "production";

  return {
    httpOnly: true,
    sameSite: embeddedPreview ? ("none" as const) : ("lax" as const),
    secure: embeddedPreview,
    partitioned: embeddedPreview,
    path: "/",
    ...(typeof maxAge === "number" ? { maxAge } : {}),
  };
}
