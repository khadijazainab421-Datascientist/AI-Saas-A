import {
  BarChart3,
  Building2,
  CalendarDays,
  Compass,
  Files,
  LayoutDashboard,
  PlugZap,
  Settings2,
  Sparkles,
  type LucideIcon,
} from "lucide-react";

export type DashboardNavItem = {
  label: string;
  href: string;
  icon: LucideIcon;
};

export type DashboardNavGroup = {
  label: string;
  items: DashboardNavItem[];
};

export const dashboardNav: DashboardNavGroup[] = [
  {
    label: "Workspace",
    items: [
      { label: "Overview", href: "/dashboard", icon: LayoutDashboard },
      { label: "Businesses", href: "/dashboard/businesses", icon: Building2 },
      { label: "Strategy", href: "/dashboard/strategy", icon: Compass },
    ],
  },
  {
    label: "Content",
    items: [
      { label: "Content Studio", href: "/dashboard/content", icon: Files },
      { label: "Calendar", href: "/dashboard/calendar", icon: CalendarDays },
    ],
  },
  {
    label: "Intelligence",
    items: [
      { label: "AI Agent", href: "/dashboard/agent", icon: Sparkles },
      { label: "Analytics", href: "/dashboard/analytics", icon: BarChart3 },
    ],
  },
  {
    label: "System",
    items: [
      { label: "Integrations", href: "/dashboard/integrations", icon: PlugZap },
      { label: "Settings", href: "/dashboard/settings", icon: Settings2 },
    ],
  },
];

export const flatDashboardNav = dashboardNav.flatMap((group) => group.items);

export function isDashboardPathActive(href: string, pathname: string) {
  if (href === "/dashboard") return pathname === href;
  return pathname === href || pathname.startsWith(`${href}/`);
}
