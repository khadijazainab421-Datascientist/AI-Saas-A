import { cookies } from "next/headers";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { businesses, workspaces, workspaceMembers } from "@/db/schema";
import type { Business, Workspace, WorkspaceRoleName } from "@/db/schema";
import type { SessionUser } from "@/lib/session";

export const ACTIVE_WORKSPACE_COOKIE = "cadence_active_workspace";

export type WorkspaceSummary = {
  workspace: Workspace;
  role: WorkspaceRoleName;
};

/**
 * Lists every workspace the user is a member of.
 * Membership is the single source of truth for tenant access.
 */
export async function getWorkspacesForUser(userId: string): Promise<WorkspaceSummary[]> {
  const rows = await db
    .select({ workspace: workspaces, role: workspaceMembers.role })
    .from(workspaces)
    .innerJoin(workspaceMembers, eq(workspaceMembers.workspaceId, workspaces.id))
    .where(eq(workspaceMembers.userId, userId))
    .orderBy(desc(workspaces.createdAt));

  return rows.map((row) => ({ workspace: row.workspace, role: row.role }));
}

/**
 * Resolves the active workspace for a user.
 * A stale or tampered cookie can never grant access: the value is always
 * re-validated against real membership rows before it is used.
 */
export async function getActiveWorkspace(
  user: SessionUser,
): Promise<WorkspaceSummary | null> {
  const memberships = await getWorkspacesForUser(user.id);
  if (memberships.length === 0) return null;

  const cookieStore = await cookies();
  const cookieId = cookieStore.get(ACTIVE_WORKSPACE_COOKIE)?.value;

  const selected =
    memberships.find((membership) => membership.workspace.id === cookieId) ?? memberships[0];

  return selected;
}

/**
 * Authoritative tenant boundary check. Returns the membership only when the
 * user genuinely belongs to the workspace, otherwise null.
 */
export async function getWorkspaceMembership(
  userId: string,
  workspaceId: string,
): Promise<WorkspaceSummary | null> {
  if (!workspaceId) return null;

  const rows = await db
    .select({ workspace: workspaces, role: workspaceMembers.role })
    .from(workspaces)
    .innerJoin(
      workspaceMembers,
      and(
        eq(workspaceMembers.workspaceId, workspaces.id),
        eq(workspaceMembers.userId, userId),
      ),
    )
    .where(eq(workspaces.id, workspaceId))
    .limit(1);

  return rows[0] ?? null;
}

/**
 * Verifies membership for a workspace-scoped request.
 * Callers must use this before reading or writing any tenant data.
 */
export async function requireWorkspaceMembership(
  userId: string,
  workspaceId: string,
): Promise<WorkspaceSummary> {
  const membership = await getWorkspaceMembership(userId, workspaceId);

  if (!membership) {
    throw new TenantAccessError(
      "You do not have access to this workspace. Access is limited to verified members.",
    );
  }

  return membership;
}

export class TenantAccessError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "TenantAccessError";
  }
}

/** Lists businesses inside a workspace the caller is already authorized for. */
export async function getBusinessesForWorkspace(workspaceId: string): Promise<Business[]> {
  return db
    .select()
    .from(businesses)
    .where(eq(businesses.workspaceId, workspaceId))
    .orderBy(desc(businesses.createdAt));
}

/** Fetches a single business, enforcing workspace ownership of the row. */
export async function getBusinessInWorkspace(
  workspaceId: string,
  businessId: string,
): Promise<Business | null> {
  const rows = await db
    .select()
    .from(businesses)
    .where(and(eq(businesses.id, businessId), eq(businesses.workspaceId, workspaceId)))
    .limit(1);

  return rows[0] ?? null;
}
