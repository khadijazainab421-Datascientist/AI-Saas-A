import { BarChart3, PlugZap, type LucideIcon } from "lucide-react";

export type DashboardSectionKey = "analytics" | "integrations";

export type DashboardSectionConfig = {
  key: DashboardSectionKey;
  eyebrow: string;
  title: string;
  description: string;
  phase: number;
  icon: LucideIcon;
  emptyTitle: string;
  emptyDescription: string;
  capabilities: string[];
  dependencies: string[];
  note: string;
};

export const dashboardSections: Record<DashboardSectionKey, DashboardSectionConfig> = {
  analytics: {
    key: "analytics",
    eyebrow: "Measurement",
    title: "Analytics",
    description:
      "Performance reporting based only on real platform-sourced data, separated by business and workspace.",
    phase: 7,
    icon: BarChart3,
    emptyTitle: "No analytics connected",
    emptyDescription:
      "No metrics are invented. Official platform permissions and recorded publishing outcomes are required before performance can be measured.",
    capabilities: [
      "Post and campaign performance by business",
      "Content-pattern analysis grounded in real results",
      "Client-ready reporting for agency workspaces",
    ],
    dependencies: [
      "Connected social accounts with analytics permissions",
      "Publishing and engagement records",
      "Tenant-safe aggregation and export controls",
    ],
    note: "Platform analytics permissions and limitations will be documented in Phases 5 and 7.",
  },
  integrations: {
    key: "integrations",
    eyebrow: "System",
    title: "Integration Center",
    description:
      "Manage official account connections, permissions, token health, and provider readiness from one auditable place.",
    phase: 5,
    icon: PlugZap,
    emptyTitle: "No platforms connected",
    emptyDescription:
      "Instagram, Facebook, and LinkedIn will use official OAuth only. Developer applications, permissions, app review, and credential requirements will be identified individually in Phase 5.",
    capabilities: [
      "Instagram, Facebook, and LinkedIn connection status",
      "Permission, expiration, and revocation visibility",
      "Masked credential references with no secrets in the browser",
    ],
    dependencies: [
      "Official platform developer applications and approvals",
      "OAuth redirect configuration and encrypted token storage",
      "Live authorization and publishing tests",
    ],
    note: "No passwords, tokens, or API keys are requested or stored during Phase 4.",
  },
};

export function isDashboardSectionKey(value: string): value is DashboardSectionKey {
  return Object.prototype.hasOwnProperty.call(dashboardSections, value);
}
