import { NextResponse, type NextRequest } from "next/server";
import { getSessionCookie } from "better-auth/cookies";

/**
 * Optimistic route protection for the dashboard.
 *
 * This only checks that a session cookie exists. It is NOT a security
 * boundary on its own — every dashboard page and server action independently
 * validates the session against the database and re-checks workspace
 * membership before touching tenant data.
 */
export function proxy(request: NextRequest) {
  if (!getSessionCookie(request)) {
    const signInUrl = new URL("/sign-in", request.url);
    signInUrl.searchParams.set("next", request.nextUrl.pathname);
    return NextResponse.redirect(signInUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*"],
};
