import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Cadence — Autonomous social media operations",
  description:
    "A calm, multi-tenant operating system for AI-assisted social media research, planning, content, publishing, and analytics.",
};

export const viewport: Viewport = {
  themeColor: "#F0F6F2",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="font-ui bg-soft text-ink antialiased">{children}</body>
    </html>
  );
}
