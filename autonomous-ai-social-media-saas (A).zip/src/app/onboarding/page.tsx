import { redirect } from "next/navigation";
import Link from "next/link";
import { ArrowRight, Check, CircleDashed } from "lucide-react";
import { requireSessionUser } from "@/lib/session";
import { getActiveWorkspace, getBusinessesForWorkspace } from "@/lib/tenancy";
import { BusinessOnboardingForm, WorkspaceOnboardingForm } from "@/components/onboarding/forms";
import { Badge, Eyebrow, Panel, StatusDot } from "@/components/ui/surface";

export const metadata = {
  title: "Set up your workspace — Cadence",
};

export default async function OnboardingPage() {
  const user = await requireSessionUser();
  const membership = await getActiveWorkspace(user);
  const businesses = membership ? await getBusinessesForWorkspace(membership.workspace.id) : [];

  const workspaceReady = Boolean(membership);
  const businessReady = businesses.length > 0;

  return (
    <main className="min-h-screen bg-canvas">
      <div className="mx-auto max-w-[900px] px-5 py-12 sm:px-8 lg:py-16">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-line pb-8">
          <div>
            <Eyebrow marker={false}>Phase 2 · Setup</Eyebrow>
            <h1 className="mt-3 font-editorial text-[clamp(2.2rem,4vw,3.5rem)] leading-tight tracking-[-0.025em] text-ink">
              Set up your workspace
            </h1>
            <p className="mt-2 max-w-xl text-sm leading-6 text-muted">
              Two steps: create a workspace, then add your first business profile. Both are stored in
              your own isolated tenant data.
            </p>
          </div>
          <Badge tone="outline">Signed in as {user.email}</Badge>
        </div>

        <div className="mt-8 grid gap-5 lg:grid-cols-[0.85fr_1.15fr]">
          <Panel className="p-6">
            <p className="text-[10px] font-bold uppercase tracking-[0.17em] text-brand">Progress</p>
            <ol className="mt-5 space-y-0 border-t border-line">
              <li className="flex items-start gap-3 border-b border-line py-4">
                <span
                  className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-bold ${
                    workspaceReady ? "bg-brand text-white" : "bg-canvas text-muted"
                  }`}
                >
                  {workspaceReady ? <Check size={13} aria-hidden="true" /> : "1"}
                </span>
                <div>
                  <p className="text-sm font-bold text-forest">Create a workspace</p>
                  <p className="mt-1 text-[11px] leading-4 text-muted">
                    {membership ? membership.workspace.name : "Not created yet"}
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3 border-b border-line py-4">
                <span
                  className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-bold ${
                    businessReady ? "bg-brand text-white" : "bg-canvas text-muted"
                  }`}
                >
                  {businessReady ? <Check size={13} aria-hidden="true" /> : "2"}
                </span>
                <div>
                  <p className="text-sm font-bold text-forest">Add a business profile</p>
                  <p className="mt-1 text-[11px] leading-4 text-muted">
                    {businessReady ? `${businesses.length} added` : "Not added yet"}
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3 border-b border-line py-4">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-canvas text-[11px] font-bold text-muted">
                  3
                </span>
                <div>
                  <p className="text-sm font-bold text-forest/70">Connect platforms</p>
                  <p className="mt-1 inline-flex items-center gap-1.5 text-[11px] leading-4 text-muted">
                    <StatusDot tone="pending" /> Phase 5
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3 py-4">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-canvas text-[11px] font-bold text-muted">
                  4
                </span>
                <div>
                  <p className="text-sm font-bold text-forest/70">Configure the AI agent</p>
                  <p className="mt-1 inline-flex items-center gap-1.5 text-[11px] leading-4 text-muted">
                    <CircleDashed size={12} aria-hidden="true" /> Phases 3–6
                  </p>
                </div>
              </li>
            </ol>
          </Panel>

          <div className="space-y-5">
            {!workspaceReady ? (
              <Panel className="p-6 sm:p-8">
                <h2 className="font-editorial text-2xl text-ink">Create your workspace</h2>
                <p className="mt-2 text-sm leading-6 text-muted">
                  A workspace holds your businesses, connected accounts, and content. Only you and
                  people you invite can access it.
                </p>
                <div className="mt-6 border-t border-line pt-6">
                  <WorkspaceOnboardingForm />
                </div>
              </Panel>
            ) : (
              <>
                <Panel className="p-6 sm:p-8">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h2 className="font-editorial text-2xl text-ink">Add your first business</h2>
                      <p className="mt-2 text-sm leading-6 text-muted">
                        This context will later drive research, strategy, and content generation.
                      </p>
                    </div>
                    <Badge tone="brand">Workspace ready</Badge>
                  </div>
                  <div className="mt-6 border-t border-line pt-6">
                    <BusinessOnboardingForm workspaceId={membership!.workspace.id} />
                  </div>
                </Panel>

                {businessReady && (
                  <Panel className="flex flex-wrap items-center justify-between gap-4 bg-forest p-6 text-white sm:p-8">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-[0.17em] text-mint">
                        You are set up
                      </p>
                      <h2 className="mt-2 font-editorial text-2xl">
                        {businesses.length} business{businesses.length === 1 ? "" : "es"} ready
                      </h2>
                      <p className="mt-2 max-w-md text-xs leading-5 text-mint/80">
                        Platform connections, AI providers, and autonomous publishing remain pending
                        later phases.
                      </p>
                    </div>
                    <Link
                      href="/dashboard"
                      className="inline-flex h-12 items-center gap-2 rounded-full bg-white px-6 text-sm font-bold text-forest transition-colors hover:bg-mint"
                    >
                      Go to dashboard <ArrowRight size={16} aria-hidden="true" />
                    </Link>
                  </Panel>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
