import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { aiTasks } from "@/db/schema";
import { getSessionUser } from "@/lib/session";
import { getActiveWorkspace } from "@/lib/tenancy";
import { getProviderStatus } from "@/lib/ai/queries";

export const dynamic = "force-dynamic";

/** Protected, secret-free provider readiness endpoint. */
export async function GET() {
  const user = await getSessionUser();
  if (!user) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }

  const membership = await getActiveWorkspace(user);
  if (!membership) {
    return Response.json({ error: "No workspace" }, { status: 403 });
  }

  const providers = await getProviderStatus(membership.workspace.id);

  const verified = await db
    .select({ providerKey: aiTasks.providerKey })
    .from(aiTasks)
    .where(
      and(
        eq(aiTasks.workspaceId, membership.workspace.id),
        eq(aiTasks.status, "completed"),
      ),
    );

  const liveTestedKeys = new Set(
    verified.map((row) => row.providerKey).filter((key): key is string => Boolean(key)),
  );

  return Response.json({
    workspaceId: membership.workspace.id,
    liveIntegrationTested: false,
    providers: providers.map((provider) => ({
      key: provider.key,
      label: provider.label,
      role: provider.role,
      isFree: provider.isFree,
      configured: provider.configured,
      status: provider.status,
      liveTested: liveTestedKeys.has(provider.key),
      lastError: provider.lastError,
    })),
    note: "Configured means the environment variable is present. A provider is only marked live-tested after a real successful task.",
  });
}
