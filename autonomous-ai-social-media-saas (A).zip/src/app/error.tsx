"use client";

import { TriangleAlert } from "lucide-react";
import { BrandWordmark } from "@/components/brand";
import { Button, ButtonLink } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";

export default function Error({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="grid min-h-screen place-items-center bg-canvas px-5 py-12">
      <div className="w-full max-w-2xl">
        <BrandWordmark />
        <div className="mt-8">
          <EmptyState
            icon={TriangleAlert}
            eyebrow="Unexpected error"
            title="This view could not be loaded."
            description="The interface stopped before rendering. You can retry this view or return to the dashboard overview. No data was changed."
            className="bg-white"
            action={
              <div className="flex flex-wrap gap-3">
                <Button onClick={reset}>Try again</Button>
                <ButtonLink href="/dashboard" variant="secondary">
                  Return to dashboard
                </ButtonLink>
              </div>
            }
          />
        </div>
      </div>
    </main>
  );
}
