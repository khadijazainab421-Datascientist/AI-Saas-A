"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { authClient } from "@/lib/auth-client";
import { signUpSchema } from "@/lib/validators";
import {
  AuthForm,
  FormAlert,
  FormField,
  PasswordField,
  SubmitButton,
} from "@/components/auth/form-field";
import { Eyebrow } from "@/components/ui/surface";
import { EmbeddedPreviewNotice } from "@/components/auth/embedded-preview-notice";

export default function SignUpPage() {
  const router = useRouter();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{
    name?: string;
    email?: string;
    password?: string;
  }>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError(null);

    const parsed = signUpSchema.safeParse({ name, email, password });
    if (!parsed.success) {
      const fieldErrors = parsed.error.flatten().fieldErrors;
      setErrors({
        name: fieldErrors.name?.[0],
        email: fieldErrors.email?.[0],
        password: fieldErrors.password?.[0],
      });
      return;
    }

    setErrors({});
    setPending(true);

    const { error } = await authClient.signUp.email({
      name: parsed.data.name,
      email: parsed.data.email,
      password: parsed.data.password,
    });

    setPending(false);

    if (error) {
      setFormError(
        error.status === 422 || error.status === 409
          ? "An account with that email already exists. Try signing in instead."
          : error.message || "Unable to create your account. Please try again.",
      );
      return;
    }

    router.push("/onboarding");
    router.refresh();
  }

  return (
    <div>
      <Eyebrow marker={false}>Phase 2 · Create account</Eyebrow>
      <h1 className="mt-4 font-editorial text-[clamp(2.4rem,4vw,3.5rem)] leading-tight tracking-[-0.03em] text-ink">
        Start with one workspace.
      </h1>
      <p className="mt-3 text-sm leading-6 text-muted">
        Accounts are scoped to your workspaces. No social accounts, AI providers, or payment details
        are connected at this stage.
      </p>

      <div className="mt-8">
        <EmbeddedPreviewNotice />
        <AuthForm onSubmit={handleSubmit}>
          {formError && <FormAlert tone="error">{formError}</FormAlert>}

          <FormField
            label="Full name"
            name="name"
            value={name}
            onChange={setName}
            error={errors.name}
            autoComplete="name"
            placeholder="Alex Mercer"
          />

          <FormField
            label="Email address"
            name="email"
            type="email"
            value={email}
            onChange={setEmail}
            error={errors.email}
            autoComplete="email"
            placeholder="you@company.com"
          />

          <PasswordField
            label="Password"
            name="password"
            value={password}
            onChange={setPassword}
            error={errors.password}
            hint="At least 10 characters."
            autoComplete="new-password"
          />

          <SubmitButton pending={pending}>
            {pending ? "Creating account…" : "Create account"}
          </SubmitButton>
        </AuthForm>
      </div>

      <p className="mt-7 text-sm text-muted">
        Already have an account?{" "}
        <Link href="/sign-in" className="font-bold text-brand hover:text-forest">
          Sign in
        </Link>
      </p>
    </div>
  );
}
