"use client";

import { useState, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { authClient } from "@/lib/auth-client";
import { signInSchema } from "@/lib/validators";
import {
  AuthForm,
  FormAlert,
  FormField,
  PasswordField,
  SubmitButton,
} from "@/components/auth/form-field";
import { Eyebrow } from "@/components/ui/surface";
import { LoadingState } from "@/components/ui/empty-state";
import { EmbeddedPreviewNotice } from "@/components/auth/embedded-preview-notice";

function SignInForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const nextPath = searchParams.get("next") || "/dashboard";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError(null);

    const parsed = signInSchema.safeParse({ email, password });
    if (!parsed.success) {
      const fieldErrors = parsed.error.flatten().fieldErrors;
      setErrors({
        email: fieldErrors.email?.[0],
        password: fieldErrors.password?.[0],
      });
      return;
    }

    setErrors({});
    setPending(true);

    const { error } = await authClient.signIn.email({
      email: parsed.data.email,
      password: parsed.data.password,
    });

    setPending(false);

    if (error) {
      setFormError(
        error.status === 401
          ? "Those credentials do not match an account. Please try again."
          : error.message || "Unable to sign in. Please try again.",
      );
      return;
    }

    router.push(nextPath);
    router.refresh();
  }

  return (
    <div>
      <Eyebrow marker={false}>Phase 2 · Authentication</Eyebrow>
      <h1 className="mt-4 font-editorial text-[clamp(2.4rem,4vw,3.5rem)] leading-tight tracking-[-0.03em] text-ink">
        Welcome back.
      </h1>
      <p className="mt-3 text-sm leading-6 text-muted">
        Sign in to access your workspaces and business profiles.
      </p>

      <div className="mt-8">
        <EmbeddedPreviewNotice />
        <AuthForm onSubmit={handleSubmit}>
          {formError && <FormAlert tone="error">{formError}</FormAlert>}

          <FormField
            label="Email address"
            name="email"
            type="email"
            value={email}
            onChange={setEmail}
            error={errors.email}
            autoComplete="email"
            placeholder="you@company.com"
          />

          <PasswordField
            label="Password"
            name="password"
            value={password}
            onChange={setPassword}
            error={errors.password}
            autoComplete="current-password"
          />

          <SubmitButton pending={pending}>
            {pending ? "Signing in…" : "Sign in"}
          </SubmitButton>
        </AuthForm>
      </div>

      <p className="mt-7 text-sm text-muted">
        No account yet?{" "}
        <Link href="/sign-up" className="font-bold text-brand hover:text-forest">
          Create one
        </Link>
      </p>

      <div className="mt-8 rounded-2xl border border-line bg-white/70 px-4 py-3.5">
        <p className="text-[11px] leading-5 text-muted">
          <span className="font-bold text-forest">Phase 2 preview.</span> Email and password
          authentication is live. Google, Apple, and social OAuth sign-in are not configured and will
          be introduced in later phases.
        </p>
      </div>
    </div>
  );
}

export default function SignInPage() {
  return (
    <Suspense fallback={<LoadingState label="Loading sign-in" />}>
      <SignInForm />
    </Suspense>
  );
}
