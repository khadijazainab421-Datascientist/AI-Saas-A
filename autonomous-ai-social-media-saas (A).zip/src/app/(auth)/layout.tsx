import Image from "next/image";
import type { ReactNode } from "react";
import Link from "next/link";
import { Check } from "lucide-react";
import { BrandWordmark } from "@/components/brand";
import { Badge, Eyebrow, StatusDot } from "@/components/ui/surface";

const assurances = [
  "Passwords are hashed and never stored in plain text.",
  "Sessions are server-validated on every protected page and action.",
  "Workspace access is limited to verified members.",
];

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="grid min-h-screen bg-canvas lg:grid-cols-[1.05fr_0.95fr]">
      <div className="flex flex-col px-5 py-8 sm:px-10 lg:px-14">
        <Link href="/" aria-label="Cadence home">
          <BrandWordmark />
        </Link>

        <div className="flex flex-1 items-center py-12">
          <div className="w-full max-w-[430px]">{children}</div>
        </div>

        <p className="text-xs leading-5 text-muted">
          © {new Date().getFullYear()} Cadence. Phase 2 of 8 — Database &amp; Authentication.
        </p>
      </div>

      <div className="relative hidden overflow-hidden bg-forest lg:block">
        <Image
          src="/images/editorial-glass.jpg"
          alt=""
          fill
          sizes="45vw"
          className="object-cover opacity-25"
          aria-hidden="true"
        />
        <div className="relative flex h-full flex-col justify-center px-12 py-16 xl:px-16">
          <Eyebrow className="text-mint">Secure by construction</Eyebrow>
          <h2 className="mt-6 max-w-md font-editorial text-[clamp(2.5rem,3.4vw,3.75rem)] leading-[1.03] tracking-[-0.03em] text-white">
            Your workspace stays yours.
          </h2>
          <p className="mt-6 max-w-sm text-sm leading-7 text-mint/80">
            Authentication and tenant isolation are built before any AI, social, or billing
            integration is introduced.
          </p>

          <ul className="mt-10 space-y-0 border-t border-white/15">
            {assurances.map((item) => (
              <li key={item} className="flex items-start gap-3 border-b border-white/15 py-4">
                <Check size={16} className="mt-0.5 shrink-0 text-mint" aria-hidden="true" />
                <p className="text-sm leading-6 text-mint/85">{item}</p>
              </li>
            ))}
          </ul>

          <div className="mt-10 flex flex-wrap items-center gap-3">
            <Badge className="border-white/20 bg-white/10 text-mint">
              <StatusDot tone="pending" /> No external OAuth yet
            </Badge>
            <Badge className="border-white/20 bg-white/10 text-mint">Database sessions</Badge>
          </div>
        </div>
      </div>
    </div>
  );
}
