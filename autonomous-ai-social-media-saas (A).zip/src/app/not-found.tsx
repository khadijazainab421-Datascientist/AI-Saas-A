import { Compass } from "lucide-react";
import { BrandWordmark } from "@/components/brand";
import { ButtonLink } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";

export default function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center bg-canvas px-5 py-12">
      <div className="w-full max-w-2xl">
        <BrandWordmark />
        <div className="mt-8">
          <EmptyState
            icon={Compass}
            eyebrow="404 · Not found"
            title="This page has not been built."
            description="Only the Phase 1 landing page and dashboard foundation routes exist. Later product areas are intentionally represented as planned, empty sections rather than simulated pages."
            className="bg-white"
            action={
              <div className="flex flex-wrap gap-3">
                <ButtonLink href="/dashboard">Open dashboard</ButtonLink>
                <ButtonLink href="/" variant="secondary">
                  Return home
                </ButtonLink>
              </div>
            }
          />
        </div>
      </div>
    </main>
  );
}
