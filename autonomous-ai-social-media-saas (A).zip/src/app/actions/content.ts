"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  aiUsage,
  brandAssets,
  carouselSlides,
  contentItems,
  contentSchedule,
  contentVersions,
  mediaAssets,
} from "@/db/schema";
import { requireSessionUser } from "@/lib/session";
import { requireWorkspaceMembership } from "@/lib/tenancy";
import { generateCaption, generateContentIdeas } from "@/lib/content/generation";
import { primaryMediaAdapter, mediaProviderStatus } from "@/lib/media/registry";
import { createBrandedGraphic } from "@/lib/media/graphics";
import { buildStoryboard, videoCapability } from "@/lib/media/video";
import type { VideoStoryboard } from "@/lib/media/video";

export type ContentActionResult = {
  ok: boolean;
  message: string;
  taskStatus?: "completed" | "paused";
  contentId?: string | null;
  assetId?: string;
  assetCount?: number;
  storyboard?: VideoStoryboard;
};

function fail(message: string): ContentActionResult {
  return { ok: false, message };
}

async function authorize(workspaceId: string) {
  const user = await requireSessionUser();
  await requireWorkspaceMembership(user.id, workspaceId);
  return user;
}

function refresh() {
  revalidatePath("/dashboard/content");
  revalidatePath("/dashboard/calendar");
}

export async function generateCaptionAction(
  workspaceId: string,
  businessId: string,
  topic: string,
  platform: string,
): Promise<ContentActionResult> {
  const clean = topic.trim();
  if (clean.length < 3 || clean.length > 300) {
    return fail("Topic must be between 3 and 300 characters.");
  }

  try {
    const user = await authorize(workspaceId);
    const result = await generateCaption(workspaceId, businessId, clean, platform, user.id);
    refresh();

    if (result.outcome.status === "paused") {
      return {
        ok: true,
        message: `Caption task paused and preserved: ${result.outcome.pausedReason}`,
        taskStatus: "paused",
        contentId: null,
      };
    }

    return {
      ok: true,
      message: result.contentId
        ? "Caption generated from real workspace context and saved."
        : "AI returned unstructured text; nothing was fabricated. Review the task log.",
      taskStatus: "completed",
      contentId: result.contentId,
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Caption generation failed.");
  }
}

export async function generateIdeasAction(
  workspaceId: string,
  businessId: string,
): Promise<ContentActionResult> {
  try {
    const user = await authorize(workspaceId);
    const result = await generateContentIdeas(workspaceId, businessId, user.id);
    refresh();

    if (result.outcome.status === "paused") {
      return {
        ok: true,
        message: `Idea task paused and preserved: ${result.outcome.pausedReason}`,
        taskStatus: "paused",
      };
    }

    return {
      ok: true,
      message: `${result.created} content ideas saved.`,
      taskStatus: "completed",
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Idea generation failed.");
  }
}

export async function createDraftAction(
  workspaceId: string,
  businessId: string,
  title: string,
): Promise<ContentActionResult> {
  const clean = title.trim();
  if (clean.length < 2 || clean.length > 200) return fail("Title must be 2–200 characters.");

  try {
    const user = await authorize(workspaceId);
    const saved = await db
      .insert(contentItems)
      .values({
        workspaceId,
        businessId: businessId || null,
        title: clean,
        status: "draft",
        createdBy: user.id,
      })
      .returning();

    refresh();
    return { ok: true, message: "Draft created.", contentId: saved[0].id };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Draft creation failed.");
  }
}

export async function updateContentAction(
  workspaceId: string,
  contentId: string,
  values: { title: string; caption: string; body: string; hashtags: string[]; platform: string; status: string },
): Promise<ContentActionResult> {
  try {
    const user = await authorize(workspaceId);

    const existing = await db
      .select()
      .from(contentItems)
      .where(and(eq(contentItems.id, contentId), eq(contentItems.workspaceId, workspaceId)))
      .limit(1);

    if (!existing[0]) return fail("Content not found in this workspace.");

    const versions = await db
      .select({ version: contentVersions.version })
      .from(contentVersions)
      .where(eq(contentVersions.contentId, contentId))
      .orderBy(contentVersions.version)
      .limit(1);

    const nextVersion = (versions[0]?.version ?? 0) + 1;

    await db.insert(contentVersions).values({
      workspaceId,
      contentId,
      version: nextVersion,
      title: existing[0].title,
      caption: existing[0].caption,
      body: existing[0].body,
      editedBy: user.id,
    });

    await db
      .update(contentItems)
      .set({
        title: values.title.trim().slice(0, 200),
        caption: values.caption.slice(0, 5000),
        body: values.body.slice(0, 4000),
        hashtags: values.hashtags.slice(0, 15),
        platform: values.platform.slice(0, 40),
        status: values.status.slice(0, 40),
        updatedAt: new Date(),
      })
      .where(and(eq(contentItems.id, contentId), eq(contentItems.workspaceId, workspaceId)));

    refresh();
    return { ok: true, message: `Saved. Version ${nextVersion} archived.`, contentId };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Save failed.");
  }
}

export async function deleteContentAction(
  workspaceId: string,
  contentId: string,
): Promise<ContentActionResult> {
  try {
    await authorize(workspaceId);
    const deleted = await db
      .delete(contentItems)
      .where(and(eq(contentItems.id, contentId), eq(contentItems.workspaceId, workspaceId)))
      .returning({ id: contentItems.id });

    if (!deleted.length) return fail("Content not found in this workspace.");
    refresh();
    return { ok: true, message: "Content removed." };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Delete failed.");
  }
}

/** Real media sourcing. Never fabricates assets when a provider fails. */
export async function sourceMediaAction(
  workspaceId: string,
  businessId: string,
  query: string,
): Promise<ContentActionResult> {
  const clean = query.trim();
  if (clean.length < 3 || clean.length > 200) return fail("Search query must be 3–200 characters.");

  try {
    await authorize(workspaceId);
    const adapter = primaryMediaAdapter();
    const result = await adapter.search(clean, 6);

    await db.insert(aiUsage).values({
      workspaceId,
      providerKey: `media:${adapter.definition.key}`,
      credits: 0,
      tokensIn: 0,
      tokensOut: 0,
      latencyMs: result.latencyMs,
      status: result.ok ? "success" : result.kind,
    });

    if (!result.ok) {
      refresh();
      return {
        ok: true,
        message: `Media sourcing interrupted: ${result.message} No assets were invented.`,
        assetCount: 0,
      };
    }

    let savedCount = 0;
    for (const asset of result.assets) {
      await db.insert(mediaAssets).values({
        workspaceId,
        businessId: businessId || null,
        kind: "sourced",
        providerKey: adapter.definition.key,
        title: asset.title,
        url: asset.url,
        thumbnailUrl: asset.thumbnailUrl,
        creator: asset.creator,
        license: asset.license,
        licenseUrl: asset.licenseUrl,
        attribution: asset.attribution,
        sourceUrl: asset.sourceUrl,
        width: asset.width,
        height: asset.height,
        status: "ready",
      });
      savedCount += 1;
    }

    refresh();
    return {
      ok: true,
      message: `${savedCount} real assets sourced from ${adapter.definition.label} (attribution stored).`,
      assetCount: savedCount,
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Media sourcing failed.");
  }
}

/** Local SVG branded graphic — no external API. */
export async function createGraphicAction(
  workspaceId: string,
  businessId: string,
  headline: string,
  brandName: string,
): Promise<ContentActionResult> {
  const clean = headline.trim();
  if (clean.length < 2 || clean.length > 160) return fail("Headline must be 2–160 characters.");

  try {
    await authorize(workspaceId);
    const svg = createBrandedGraphic({ brandName, headline: clean });

    const saved = await db
      .insert(mediaAssets)
      .values({
        workspaceId,
        businessId: businessId || null,
        kind: "generated",
        providerKey: "local_svg",
        title: clean,
        svgData: svg,
        creator: "Cadence local generator",
        license: "Workspace-owned",
        attribution: "Generated locally by Cadence",
        status: "ready",
        width: 1080,
        height: 1080,
      })
      .returning();

    refresh();
    return {
      ok: true,
      message: "Branded SVG graphic generated locally (no external API).",
      assetId: saved[0].id,
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Graphic generation failed.");
  }
}

export async function createCarouselAction(
  workspaceId: string,
  contentId: string,
): Promise<ContentActionResult> {
  try {
    await authorize(workspaceId);

    const item = await db
      .select()
      .from(contentItems)
      .where(and(eq(contentItems.id, contentId), eq(contentItems.workspaceId, workspaceId)))
      .limit(1);

    if (!item[0]) return fail("Content not found in this workspace.");

    const points = (item[0].hashtags ?? []).slice(0, 4);
    const slides = [
      { position: 1, headline: item[0].title, body: "" },
      ...points.map((point, index) => ({
        position: index + 2,
        headline: point,
        body: item[0].caption.slice(0, 300),
      })),
    ];

    await db.delete(carouselSlides).where(eq(carouselSlides.contentId, contentId));

    for (const slide of slides) {
      await db.insert(carouselSlides).values({
        workspaceId,
        contentId,
        position: slide.position,
        headline: slide.headline.slice(0, 200),
        body: slide.body,
      });
    }

    await db
      .update(contentItems)
      .set({ type: "carousel", updatedAt: new Date() })
      .where(eq(contentItems.id, contentId));

    refresh();
    return { ok: true, message: `${slides.length} carousel slides created from real content.` };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Carousel creation failed.");
  }
}

export async function createStoryboardAction(
  workspaceId: string,
  headline: string,
  points: string[],
): Promise<ContentActionResult> {
  try {
    await authorize(workspaceId);
    const capability = videoCapability();
    const storyboard = buildStoryboard(headline, points);

    return {
      ok: true,
      message: `Storyboard created (${storyboard.totalSeconds}s). ${capability.reason}`,
      storyboard,
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Storyboard failed.");
  }
}

/** Scheduling only. Publishing is Phase 5/6 and is never simulated. */
export async function scheduleContentAction(
  workspaceId: string,
  contentId: string,
  platform: string,
  scheduledFor: string,
  timezone: string,
): Promise<ContentActionResult> {
  try {
    await authorize(workspaceId);
    const date = new Date(scheduledFor);
    if (Number.isNaN(date.getTime())) return fail("Please provide a valid date and time.");

    const item = await db
      .select({ id: contentItems.id })
      .from(contentItems)
      .where(and(eq(contentItems.id, contentId), eq(contentItems.workspaceId, workspaceId)))
      .limit(1);

    if (!item[0]) return fail("Content not found in this workspace.");

    await db.insert(contentSchedule).values({
      workspaceId,
      contentId,
      platform,
      scheduledFor: date,
      timezone: timezone || "UTC",
      status: "planned",
    });

    refresh();
    return {
      ok: true,
      message: "Scheduled as PLANNED only. No publishing worker or social OAuth is connected yet.",
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Scheduling failed.");
  }
}

export async function unscheduleAction(
  workspaceId: string,
  scheduleId: string,
): Promise<ContentActionResult> {
  try {
    await authorize(workspaceId);
    const deleted = await db
      .delete(contentSchedule)
      .where(
        and(
          eq(contentSchedule.id, scheduleId),
          eq(contentSchedule.workspaceId, workspaceId),
        ),
      )
      .returning({ id: contentSchedule.id });

    if (!deleted.length) return fail("Schedule entry not found in this workspace.");
    refresh();
    return { ok: true, message: "Schedule entry removed." };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Unschedule failed.");
  }
}

export async function addBrandAssetAction(
  workspaceId: string,
  businessId: string,
  name: string,
  kind: string,
  value: string,
): Promise<ContentActionResult> {
  try {
    await authorize(workspaceId);
    await db.insert(brandAssets).values({
      workspaceId,
      businessId: businessId || null,
      name: name.trim().slice(0, 120),
      kind: kind.slice(0, 40),
      value: value.trim().slice(0, 500),
    });
    refresh();
    return { ok: true, message: "Brand asset saved." };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Brand asset failed.");
  }
}

export async function getMediaProviderStatusAction() {
  return mediaProviderStatus();
}
