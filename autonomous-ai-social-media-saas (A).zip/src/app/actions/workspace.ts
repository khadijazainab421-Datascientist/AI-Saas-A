"use server";

import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { db } from "@/db";
import { workspaces, workspaceMembers } from "@/db/schema";
import { requireSessionUser } from "@/lib/session";
import {
  ACTIVE_WORKSPACE_COOKIE,
  getWorkspaceMembership,
  getWorkspacesForUser,
} from "@/lib/tenancy";
import { sessionCookieAttributes } from "@/lib/cookie-options";
import { workspaceSchema } from "@/lib/validators";

export type ActionState = {
  status: "idle" | "success" | "error";
  message?: string;
  fieldErrors?: Record<string, string | undefined>;
};

function slugify(value: string) {
  return (
    value
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 48) || "workspace"
  );
}

async function createUniqueSlug(base: string) {
  const root = slugify(base);
  const existing = await db.select({ slug: workspaces.slug }).from(workspaces);

  if (!existing.some((row) => row.slug === root)) return root;

  const suffix = Math.random().toString(36).slice(2, 7);
  return `${root}-${suffix}`;
}

export async function createWorkspace(
  _prevState: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await requireSessionUser();

  const parsed = workspaceSchema.safeParse({ name: formData.get("name") });

  if (!parsed.success) {
    return {
      status: "error",
      message: "Please correct the workspace name.",
      fieldErrors: {
        name: parsed.error.flatten().fieldErrors.name?.[0] ?? "Invalid workspace name.",
      },
    };
  }

  const slug = await createUniqueSlug(parsed.data.name);

  // The owner is inserted as a member in the same transaction so a workspace
  // can never exist without an authorized owner.
  const created = await db.transaction(async (tx) => {
    const [workspace] = await tx
      .insert(workspaces)
      .values({ name: parsed.data.name, slug, ownerId: user.id })
      .returning();

    await tx
      .insert(workspaceMembers)
      .values({ workspaceId: workspace.id, userId: user.id, role: "owner" });

    return workspace;
  });

  const cookieStore = await cookies();
  cookieStore.set(
    ACTIVE_WORKSPACE_COOKIE,
    created.id,
    sessionCookieAttributes(60 * 60 * 24 * 365),
  );

  revalidatePath("/dashboard");
  revalidatePath("/onboarding");

  return { status: "success", message: `Workspace “${created.name}” created.` };
}

export async function setActiveWorkspace(workspaceId: string): Promise<ActionState> {
  const user = await requireSessionUser();

  // Re-validate membership before trusting the requested workspace id.
  const membership = await getWorkspaceMembership(user.id, workspaceId);
  if (!membership) {
    return {
      status: "error",
      message: "That workspace is not available to your account.",
    };
  }

  const cookieStore = await cookies();
  cookieStore.set(
    ACTIVE_WORKSPACE_COOKIE,
    membership.workspace.id,
    sessionCookieAttributes(60 * 60 * 24 * 365),
  );

  revalidatePath("/dashboard");

  return { status: "success", message: `Switched to ${membership.workspace.name}.` };
}

export async function getWorkspaceOptions() {
  const user = await requireSessionUser();
  return getWorkspacesForUser(user.id);
}

/** Exposed for Phase 2 authorization and tenant-isolation tests. */
export async function debugMembershipCheck(userId: string, workspaceId: string) {
  const membership = await getWorkspaceMembership(userId, workspaceId);
  return membership ? { workspaceId: membership.workspace.id, role: membership.role } : null;
}
