"use server";

import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { businesses } from "@/db/schema";
import { requireSessionUser } from "@/lib/session";
import { requireWorkspaceMembership } from "@/lib/tenancy";
import { businessSchema, type BusinessInput } from "@/lib/validators";
import type { ActionState } from "@/app/actions/workspace";

/** Zod optional strings become SQL NULLs rather than undefined. */
function toNullable(value: string | undefined) {
  return value && value.length > 0 ? value : null;
}

function businessValues(parsed: BusinessInput) {
  return {
    name: parsed.name,
    website: toNullable(parsed.website),
    industry: toNullable(parsed.industry),
    description: toNullable(parsed.description),
    brandVoice: toNullable(parsed.brandVoice),
    targetAudience: toNullable(parsed.targetAudience),
    goals: toNullable(parsed.goals),
    timezone: parsed.timezone || "UTC",
  };
}

export async function createBusiness(
  workspaceId: string,
  _prevState: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await requireSessionUser();

  // Tenant boundary: reject anything the caller is not a member of.
  await requireWorkspaceMembership(user.id, workspaceId);

  const parsed = businessSchema.safeParse({
    name: formData.get("name"),
    website: formData.get("website") || undefined,
    industry: formData.get("industry") || undefined,
    description: formData.get("description") || undefined,
    brandVoice: formData.get("brandVoice") || undefined,
    targetAudience: formData.get("targetAudience") || undefined,
    goals: formData.get("goals") || undefined,
    timezone: formData.get("timezone") || "UTC",
  });

  if (!parsed.success) {
    const fieldErrors = parsed.error.flatten().fieldErrors;
    return {
      status: "error",
      message: "Please correct the highlighted fields.",
      fieldErrors: {
        name: fieldErrors.name?.[0],
        website: fieldErrors.website?.[0],
        industry: fieldErrors.industry?.[0],
        description: fieldErrors.description?.[0],
        brandVoice: fieldErrors.brandVoice?.[0],
        targetAudience: fieldErrors.targetAudience?.[0],
        goals: fieldErrors.goals?.[0],
        timezone: fieldErrors.timezone?.[0],
      },
    };
  }

  await db.insert(businesses).values({
    workspaceId,
    ...businessValues(parsed.data),
  });

  revalidatePath("/dashboard/businesses");

  return { status: "success", message: `Business “${parsed.data.name}” added.` };
}

export async function updateBusiness(
  workspaceId: string,
  businessId: string,
  _prevState: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await requireSessionUser();
  await requireWorkspaceMembership(user.id, workspaceId);

  const parsed = businessSchema.safeParse({
    name: formData.get("name"),
    website: formData.get("website") || undefined,
    industry: formData.get("industry") || undefined,
    description: formData.get("description") || undefined,
    brandVoice: formData.get("brandVoice") || undefined,
    targetAudience: formData.get("targetAudience") || undefined,
    goals: formData.get("goals") || undefined,
    timezone: formData.get("timezone") || "UTC",
  });

  if (!parsed.success) {
    const fieldErrors = parsed.error.flatten().fieldErrors;
    return {
      status: "error",
      message: "Please correct the highlighted fields.",
      fieldErrors: { name: fieldErrors.name?.[0], website: fieldErrors.website?.[0] },
    };
  }

  // Scope the update by workspaceId so a cross-tenant id can never match.
  const updated = await db
    .update(businesses)
    .set({
      ...businessValues(parsed.data),
      updatedAt: new Date(),
    })
    .where(eq(businesses.id, businessId))
    .returning({ id: businesses.id, workspaceId: businesses.workspaceId });

  if (updated.length === 0 || updated[0].workspaceId !== workspaceId) {
    return { status: "error", message: "Business not found in this workspace." };
  }

  revalidatePath("/dashboard/businesses");

  return { status: "success", message: "Business profile updated." };
}

export async function deleteBusiness(workspaceId: string, businessId: string): Promise<ActionState> {
  const user = await requireSessionUser();
  await requireWorkspaceMembership(user.id, workspaceId);

  const deleted = await db
    .delete(businesses)
    .where(eq(businesses.id, businessId))
    .returning({ id: businesses.id, workspaceId: businesses.workspaceId });

  if (deleted.length === 0 || deleted[0].workspaceId !== workspaceId) {
    return { status: "error", message: "Business not found in this workspace." };
  }

  revalidatePath("/dashboard/businesses");

  return { status: "success", message: "Business removed." };
}
