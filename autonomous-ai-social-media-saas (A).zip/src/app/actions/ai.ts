"use server";

import { revalidatePath } from "next/cache";
import { requireSessionUser } from "@/lib/session";
import { requireWorkspaceMembership } from "@/lib/tenancy";
import { notifyWorkspace } from "@/lib/ai/notifications";
import { analyzeBusinessWebsite } from "@/lib/ai/brand";
import { runResearch } from "@/lib/ai/research";
import { generateStrategy } from "@/lib/ai/strategy";
import { resumePausedTasks } from "@/lib/ai/orchestrator";
import { setAllowPaidProviders } from "@/lib/ai/settings";

export type AiActionResult = {
  ok: boolean;
  message: string;
  taskStatus?: "completed" | "paused";
  taskId?: string;
  strategyId?: string | null;
  sourceCount?: number;
};

function fail(message: string): AiActionResult {
  return { ok: false, message };
}

async function authorize(workspaceId: string) {
  const user = await requireSessionUser();
  await requireWorkspaceMembership(user.id, workspaceId);
  return user;
}

export async function analyzeWebsiteAction(
  workspaceId: string,
  businessId: string,
): Promise<AiActionResult> {
  try {
    const user = await authorize(workspaceId);
    const result = await analyzeBusinessWebsite(workspaceId, businessId, user.id);

    revalidatePath("/dashboard/strategy");
    revalidatePath("/dashboard/agent");

    if (result.task.status === "paused") {
      return {
        ok: true,
        message: `Website extracted (${result.extraction.excerptLength} characters) and saved. AI structuring is paused: ${result.task.pausedReason}`,
        taskStatus: "paused",
        taskId: result.task.taskId,
      };
    }

    return {
      ok: true,
      message: `Website analyzed from ${result.extraction.url}. Brand profile updated.`,
      taskStatus: "completed",
      taskId: result.task.taskId,
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Website analysis failed.");
  }
}

export async function runResearchAction(
  workspaceId: string,
  businessId: string,
  query: string,
): Promise<AiActionResult> {
  const cleanQuery = query.trim();
  if (cleanQuery.length < 3 || cleanQuery.length > 300) {
    return fail("Research query must be between 3 and 300 characters.");
  }

  try {
    const user = await authorize(workspaceId);
    const run = await runResearch(workspaceId, businessId || null, cleanQuery, user.id);

    revalidatePath("/dashboard/strategy");
    revalidatePath("/dashboard/agent");

    if (run.status === "completed") {
      return {
        ok: true,
        message: `${run.sourceCount} verified sources saved.`,
        sourceCount: run.sourceCount,
      };
    }

    return {
      ok: true,
      message:
        run.status === "unconfigured"
          ? "No research provider is configured. No sources were invented; the run is recorded as pending configuration."
          : `Research interrupted: ${run.error ?? "provider unavailable"}. Nothing was discarded.`,
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Research run failed.");
  }
}

export async function generateStrategyAction(
  workspaceId: string,
  businessId: string,
): Promise<AiActionResult> {
  try {
    const user = await authorize(workspaceId);
    const result = await generateStrategy(workspaceId, businessId, user.id);

    revalidatePath("/dashboard/strategy");
    revalidatePath("/dashboard/agent");

    if (result.outcome.status === "paused") {
      return {
        ok: true,
        message: `Strategy task paused and preserved: ${result.outcome.pausedReason}`,
        taskStatus: "paused",
        taskId: result.outcome.taskId,
        strategyId: null,
      };
    }

    return {
      ok: true,
      message: "Strategy generated from real workspace context and saved.",
      taskStatus: "completed",
      taskId: result.outcome.taskId,
      strategyId: result.strategyId,
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Strategy generation failed.");
  }
}

export async function resumeTasksAction(workspaceId: string): Promise<AiActionResult> {
  try {
    const user = await authorize(workspaceId);
    const outcomes = await resumePausedTasks(workspaceId, user.id);

    const completed = outcomes.filter((item) => item.status === "completed").length;
    const stillPaused = outcomes.length - completed;

    await notifyWorkspace(
      workspaceId,
      "ai_resume_attempt",
      "Task resume attempted",
      `${completed} task(s) resumed successfully, ${stillPaused} remain paused.`,
      user.id,
    );

    revalidatePath("/dashboard/agent");
    revalidatePath("/dashboard/strategy");

    return {
      ok: true,
      message:
        outcomes.length === 0
          ? "No paused tasks to resume."
          : `${completed} resumed, ${stillPaused} still paused and preserved.`,
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Resume failed.");
  }
}

export async function setPaidProvidersAction(
  workspaceId: string,
  allowed: boolean,
): Promise<AiActionResult> {
  try {
    await authorize(workspaceId);
    await setAllowPaidProviders(workspaceId, allowed);

    revalidatePath("/dashboard/agent");

    return {
      ok: true,
      message: allowed
        ? "Paid AI providers are now permitted for this workspace."
        : "Paid AI providers are disabled. Only free-tier providers will be used.",
    };
  } catch (error) {
    return fail(error instanceof Error ? error.message : "Setting update failed.");
  }
}
