"use server";

import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { auth } from "@/lib/auth";
import { getSessionUser } from "@/lib/session";
import { ACTIVE_WORKSPACE_COOKIE } from "@/lib/tenancy";
import { sessionCookieAttributes } from "@/lib/cookie-options";
import { cookies } from "next/headers";

export async function signOutAction() {
  const user = await getSessionUser();

  // Always clear the local workspace cookie so a shared browser cannot retain
  // a stale tenant selection after sign-out. Attributes must match the set
  // cookie for the browser to actually remove it.
  const cookieStore = await cookies();
  cookieStore.set(ACTIVE_WORKSPACE_COOKIE, "", sessionCookieAttributes(0));

  if (user) {
    await auth.api.signOut({ headers: await headers() });
  }

  redirect("/sign-in");
}
