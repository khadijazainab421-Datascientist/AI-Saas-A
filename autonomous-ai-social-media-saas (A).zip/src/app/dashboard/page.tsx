import { DashboardOverview } from "@/components/dashboard/overview";
import { requireSessionUser } from "@/lib/session";
import { getActiveWorkspace, getBusinessesForWorkspace } from "@/lib/tenancy";

export default async function DashboardPage() {
  const user = await requireSessionUser();
  const activeWorkspace = await getActiveWorkspace(user);
  const businesses = activeWorkspace
    ? await getBusinessesForWorkspace(activeWorkspace.workspace.id)
    : [];

  return (
    <DashboardOverview
      user={user}
      activeWorkspace={activeWorkspace!}
      businesses={businesses}
    />
  );
}
