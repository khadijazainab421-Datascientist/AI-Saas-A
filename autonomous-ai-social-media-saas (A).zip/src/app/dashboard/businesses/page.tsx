import { requireSessionUser } from "@/lib/session";
import { getActiveWorkspace, getBusinessesForWorkspace } from "@/lib/tenancy";
import { BusinessManager } from "@/components/dashboard/business-manager";

export const metadata = {
  title: "Businesses — Cadence",
};

export default async function BusinessesPage() {
  const user = await requireSessionUser();
  const activeWorkspace = await getActiveWorkspace(user);
  const businesses = activeWorkspace
    ? await getBusinessesForWorkspace(activeWorkspace.workspace.id)
    : [];

  return (
    <BusinessManager workspaceId={activeWorkspace!.workspace.id} businesses={businesses} />
  );
}
