import { redirect } from "next/navigation";
import { Activity, Bell, CircleDashed, Cpu, PauseCircle } from "lucide-react";
import { requireSessionUser } from "@/lib/session";
import { getActiveWorkspace, getBusinessesForWorkspace } from "@/lib/tenancy";
import { getAiDashboardData, getProviderStatus } from "@/lib/ai/queries";
import { AiActions } from "@/components/dashboard/ai-actions";
import { Badge, Eyebrow, Panel, StatusDot } from "@/components/ui/surface";
import { EmptyState } from "@/components/ui/empty-state";

export const metadata = { title: "AI Agent — Cadence" };

const dateFormatter = new Intl.DateTimeFormat("en-GB", {
  dateStyle: "medium",
  timeStyle: "short",
});

export default async function AgentPage() {
  const user = await requireSessionUser();
  const activeWorkspace = await getActiveWorkspace(user);
  if (!activeWorkspace) redirect("/onboarding");

  const workspaceId = activeWorkspace.workspace.id;
  const [data, providers, businesses] = await Promise.all([
    getAiDashboardData(workspaceId),
    getProviderStatus(workspaceId),
    getBusinessesForWorkspace(workspaceId),
  ]);

  const pausedCount = data.tasks.filter((task) => task.status === "paused").length;
  const completedCount = data.tasks.filter((task) => task.status === "completed").length;
  const totalTokens = data.usage.reduce(
    (sum, row) => sum + row.tokensIn + row.tokensOut,
    0,
  );
  const totalCredits = data.usage.reduce((sum, row) => sum + row.credits, 0);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-line pb-6">
        <div>
          <Eyebrow marker={false}>Phase 3 · Engine</Eyebrow>
          <h1 className="mt-3 font-editorial text-[clamp(2rem,3.2vw,3rem)] leading-tight tracking-[-0.025em] text-ink">
            AI engine &amp; task control
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
            Provider health, fallback outcomes, usage, pause and resume. Full autonomous publishing
            remains Phase 6 and is not active.
          </p>
        </div>
        <Badge tone="pending">
          <CircleDashed size={11} aria-hidden="true" /> Autonomy pending
        </Badge>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Tasks completed", value: String(completedCount), note: "Real successful AI calls" },
          { label: "Tasks paused", value: String(pausedCount), note: "Input preserved" },
          { label: "Tokens recorded", value: totalTokens.toLocaleString(), note: "From provider usage" },
          { label: "Research credits", value: totalCredits.toLocaleString(), note: "Tavily credits used" },
        ].map((item) => (
          <Panel key={item.label} className="p-5">
            <p className="text-[10px] font-bold uppercase tracking-[0.13em] text-muted">
              {item.label}
            </p>
            <p className="mt-3 font-editorial text-3xl text-forest">{item.value}</p>
            <p className="mt-1.5 text-[11px] text-muted">{item.note}</p>
          </Panel>
        ))}
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.25fr_0.75fr]">
        <Panel className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Provider health</h2>
            <Cpu size={16} className="text-brand" aria-hidden="true" />
          </div>
          <div className="mt-4 border-t border-line">
            {providers.map((provider) => (
              <div key={provider.key} className="border-b border-line py-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-xs font-bold text-forest">
                    {provider.label}{" "}
                    <span className="ml-1 text-[10px] font-medium text-muted">
                      priority {provider.priority}
                    </span>
                  </p>
                  <span
                    className={`inline-flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-[0.11em] ${
                      provider.configured ? "text-brand" : "text-[#746444]"
                    }`}
                  >
                    <StatusDot tone={provider.configured ? "brand" : "pending"} />
                    {provider.configured ? provider.status : "unconfigured"}
                  </span>
                </div>
                <p className="mt-1.5 text-[10px] leading-4 text-muted">
                  {provider.envVar} · {provider.isFree ? "free tier" : "paid"}
                  {provider.lastError ? ` · ${provider.lastError}` : ""}
                </p>
              </div>
            ))}
          </div>
          <p className="mt-4 text-[11px] leading-5 text-muted">
            Fallback order: primary → backup → pause task + notify. No work is discarded and no
            paid provider is used without explicit workspace authorization.
          </p>
        </Panel>

        <Panel className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Controls</h2>
            <PauseCircle size={16} className="text-brand" aria-hidden="true" />
          </div>
          <p className="mt-1.5 text-xs leading-5 text-muted">
            Resume preserved tasks when quota or availability returns.
          </p>
          <div className="mt-6 border-t border-line pt-6">
            <AiActions
              workspaceId={workspaceId}
              businesses={businesses.map((item) => ({
                id: item.id,
                name: item.name,
                website: item.website,
              }))}
              mode="agent"
              allowPaidProviders={data.settings?.allowPaidProviders ?? false}
              pausedCount={pausedCount}
            />
          </div>
        </Panel>
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        <Panel className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Task log</h2>
            <Activity size={16} className="text-brand" aria-hidden="true" />
          </div>
          {data.tasks.length === 0 ? (
            <EmptyState
              compact
              icon={Activity}
              title="No AI tasks yet"
              description="Run website analysis, research, or strategy generation to create a durable task record."
              className="mt-5 bg-canvas/40"
            />
          ) : (
            <div className="mt-5 border-t border-line">
              {data.tasks.slice(0, 10).map((task) => (
                <div key={task.id} className="border-b border-line py-3.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-xs font-bold text-forest">{task.kind.replace(/_/g, " ")}</p>
                    <span className="text-[10px] font-bold uppercase tracking-[0.11em] text-muted">
                      {task.status}
                    </span>
                  </div>
                  <p className="mt-1 text-[10px] text-muted">
                    {task.providerKey ?? "no provider"} · attempts {task.attemptCount} ·{" "}
                    {dateFormatter.format(task.createdAt)}
                  </p>
                  {task.pausedReason && (
                    <p className="mt-1.5 line-clamp-2 text-[10px] leading-4 text-[#746444]">
                      {task.pausedReason}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </Panel>

        <Panel className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Notifications</h2>
            <Bell size={16} className="text-brand" aria-hidden="true" />
          </div>
          {data.notifications.length === 0 ? (
            <EmptyState
              compact
              icon={Bell}
              title="No interruptions"
              description="Provider outages, quota pauses, and resume attempts are recorded here."
              className="mt-5 bg-canvas/40"
            />
          ) : (
            <div className="mt-5 border-t border-line">
              {data.notifications.slice(0, 8).map((note) => (
                <div key={note.id} className="border-b border-line py-3.5">
                  <p className="text-xs font-bold text-forest">{note.title}</p>
                  <p className="mt-1 line-clamp-2 text-[10px] leading-4 text-muted">{note.body}</p>
                  <p className="mt-1 text-[9px] text-muted">
                    {dateFormatter.format(note.createdAt)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}
