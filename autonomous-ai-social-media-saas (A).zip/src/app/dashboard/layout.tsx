import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { DashboardChrome } from "@/components/dashboard/dashboard-chrome";
import { requireSessionUser } from "@/lib/session";
import { getActiveWorkspace, getBusinessesForWorkspace } from "@/lib/tenancy";
import { getUnreadNotifications } from "@/lib/ai/queries";
import type { WorkspaceSummary } from "@/lib/tenancy";

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const user = await requireSessionUser();
  const activeWorkspace = await getActiveWorkspace(user);

  // A signed-in user with no workspace must complete setup first.
  if (!activeWorkspace) {
    redirect("/onboarding");
  }

  const [businesses, notifications] = await Promise.all([
    getBusinessesForWorkspace(activeWorkspace.workspace.id),
    getUnreadNotifications(activeWorkspace.workspace.id),
  ]);

  return (
    <DashboardChrome
      user={user}
      activeWorkspace={activeWorkspace}
      businesses={businesses}
      notifications={notifications}
    >
      {children}
    </DashboardChrome>
  );
}

export type { WorkspaceSummary };
