import { desc, eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { brandAssets, contentItems, mediaAssets } from "@/db/schema";
import { requireSessionUser } from "@/lib/session";
import { getActiveWorkspace, getBusinessesForWorkspace } from "@/lib/tenancy";
import { mediaProviderStatus } from "@/lib/media/registry";
import { videoCapability } from "@/lib/media/video";
import { ContentStudio } from "@/components/dashboard/content-studio";
import { Badge, Eyebrow, Panel } from "@/components/ui/surface";

export const metadata = { title: "Content Studio — Cadence" };

export default async function ContentPage() {
  const user = await requireSessionUser();
  const activeWorkspace = await getActiveWorkspace(user);
  if (!activeWorkspace) redirect("/onboarding");

  const workspaceId = activeWorkspace.workspace.id;

  const [businesses, items, assets, assetsCount] = await Promise.all([
    getBusinessesForWorkspace(workspaceId),
    db
      .select()
      .from(contentItems)
      .where(eq(contentItems.workspaceId, workspaceId))
      .orderBy(desc(contentItems.createdAt))
      .limit(40),
    db
      .select()
      .from(mediaAssets)
      .where(eq(mediaAssets.workspaceId, workspaceId))
      .orderBy(desc(mediaAssets.createdAt))
      .limit(20),
    db.select({ id: brandAssets.id }).from(brandAssets).where(eq(brandAssets.workspaceId, workspaceId)),
  ]);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-line pb-6">
        <div>
          <Eyebrow marker={false}>Phase 4 · Creation</Eyebrow>
          <h1 className="mt-3 font-editorial text-[clamp(2rem,3.2vw,3rem)] leading-tight tracking-[-0.025em] text-ink">
            Content Studio
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
            Captions, ideas, carousels, branded graphics, openly licensed media, brand assets, and a
            versioned editor. Publishing is not connected yet — schedules remain planned only.
          </p>
        </div>
        <Badge tone="outline">No publishing yet</Badge>
      </div>

      <Panel className="flex flex-wrap items-center gap-3 bg-canvas/60 px-5 py-4">
        <p className="text-xs leading-5 text-muted">
          <span className="font-bold text-forest">Media credentials:</span> Openverse works keyless
          with real attribution. Unsplash and Pexels are optional and reported honestly. Local SVG
          graphics need no API. {assetsCount.length} brand assets stored.
        </p>
      </Panel>

      <ContentStudio
        workspaceId={workspaceId}
        businesses={businesses.map((item) => ({ id: item.id, name: item.name }))}
        items={items.map((item) => ({
          id: item.id,
          title: item.title,
          type: item.type,
          status: item.status,
          platform: item.platform,
          caption: item.caption,
          body: item.body,
          hashtags: item.hashtags ?? [],
          createdAt: item.createdAt.toISOString(),
        }))}
        assets={assets.map((asset) => ({
          id: asset.id,
          kind: asset.kind,
          providerKey: asset.providerKey,
          title: asset.title,
          url: asset.url,
          thumbnailUrl: asset.thumbnailUrl,
          svgData: asset.svgData,
          creator: asset.creator,
          license: asset.license,
          attribution: asset.attribution,
        }))}
        providers={mediaProviderStatus()}
        videoNote={videoCapability().reason}
      />
    </div>
  );
}
