import { redirect } from "next/navigation";
import {
  BadgeCheck,
  Building2,
  Clock3,
  KeyRound,
  LogOut,
  Mail,
  ShieldCheck,
  UserRound,
} from "lucide-react";
import { requireSessionUser } from "@/lib/session";
import { getActiveWorkspace, getWorkspacesForUser } from "@/lib/tenancy";
import { signOutAction } from "@/app/actions/auth";
import { Badge, Eyebrow, Panel, StatusDot } from "@/components/ui/surface";
import { Button } from "@/components/ui/button";

export const metadata = {
  title: "Settings — Cadence",
};

export default async function SettingsPage() {
  const user = await requireSessionUser();
  const activeWorkspace = await getActiveWorkspace(user);
  if (!activeWorkspace) redirect("/onboarding");

  const memberships = await getWorkspacesForUser(user.id);

  const rows = [
    { icon: Building2, label: "Workspace name", value: activeWorkspace.workspace.name },
    { icon: KeyRound, label: "Workspace slug", value: activeWorkspace.workspace.slug },
    { icon: ShieldCheck, label: "Your role", value: activeWorkspace.role },
    {
      icon: Clock3,
      label: "Created",
      value: new Intl.DateTimeFormat("en-GB", {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(activeWorkspace.workspace.createdAt),
    },
  ];

  const pending = [
    { label: "Team members and invitations", detail: "Roles and invites are reserved for later phases." },
    { label: "AI provider permissions", detail: "Paid-provider authorization controls arrive in Phase 3." },
    { label: "Platform credentials", detail: "OAuth app management is part of Phase 5." },
    { label: "Subscription and billing", detail: "Plan limits and payments are handled in Phase 7." },
  ];

  return (
    <div className="space-y-5">
      <div className="border-b border-line pb-6">
        <Eyebrow marker={false}>System</Eyebrow>
        <h1 className="mt-3 font-editorial text-[clamp(2rem,3.2vw,3rem)] leading-tight tracking-[-0.025em] text-ink">
          Settings
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
          Live workspace and account information. Everything below is read from your own tenant
          records — nothing here is simulated.
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Panel className="p-6 sm:p-7">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Workspace</h2>
            <Badge tone="brand">
              <StatusDot tone="brand" /> Active
            </Badge>
          </div>
          <dl className="mt-5 border-t border-line">
            {rows.map((row) => {
              const Icon = row.icon;
              return (
                <div
                  key={row.label}
                  className="flex items-center gap-4 border-b border-line py-4"
                >
                  <Icon size={16} className="shrink-0 text-brand" strokeWidth={1.8} aria-hidden="true" />
                  <dt className="text-[11px] font-bold uppercase tracking-[0.12em] text-muted">
                    {row.label}
                  </dt>
                  <dd className="ml-auto truncate text-sm font-bold text-forest">{row.value}</dd>
                </div>
              );
            })}
          </dl>

          {memberships.length > 1 && (
            <p className="mt-5 text-[11px] leading-5 text-muted">
              You are a member of {memberships.length} workspaces. Switch between them using the
              workspace selector in the sidebar.
            </p>
          )}
        </Panel>

        <Panel className="p-6 sm:p-7">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Your account</h2>
            <Badge tone="outline">Phase 2</Badge>
          </div>
          <dl className="mt-5 border-t border-line">
            <div className="flex items-center gap-4 border-b border-line py-4">
              <UserRound size={16} className="shrink-0 text-brand" strokeWidth={1.8} aria-hidden="true" />
              <dt className="text-[11px] font-bold uppercase tracking-[0.12em] text-muted">Name</dt>
              <dd className="ml-auto truncate text-sm font-bold text-forest">{user.name}</dd>
            </div>
            <div className="flex items-center gap-4 border-b border-line py-4">
              <Mail size={16} className="shrink-0 text-brand" strokeWidth={1.8} aria-hidden="true" />
              <dt className="text-[11px] font-bold uppercase tracking-[0.12em] text-muted">Email</dt>
              <dd className="ml-auto truncate text-sm font-bold text-forest">{user.email}</dd>
            </div>
            <div className="flex items-center gap-4 border-b border-line py-4">
              <BadgeCheck size={16} className="shrink-0 text-brand" strokeWidth={1.8} aria-hidden="true" />
              <dt className="text-[11px] font-bold uppercase tracking-[0.12em] text-muted">
                Sign-in method
              </dt>
              <dd className="ml-auto text-sm font-bold text-forest">Email and password</dd>
            </div>
          </dl>

          <div className="mt-6 rounded-2xl bg-canvas/70 px-4 py-3.5">
            <p className="text-[11px] leading-5 text-muted">
              <span className="font-bold text-forest">Security.</span> Sessions are stored
              server-side and validated on every protected request. Email verification is not yet
              enabled because no transactional email provider has been selected.
            </p>
          </div>

          <form action={signOutAction} className="mt-5">
            <Button variant="secondary" type="submit">
              <LogOut size={15} aria-hidden="true" /> Sign out
            </Button>
          </form>
        </Panel>
      </div>

      <Panel className="p-6 sm:p-7">
        <h2 className="text-sm font-bold text-forest">Reserved for later phases</h2>
        <p className="mt-1.5 text-xs leading-5 text-muted">
          These settings are listed for transparency. None of them are active, and no values are
          fabricated for them.
        </p>
        <div className="mt-5 grid gap-4 border-t border-line pt-5 sm:grid-cols-2">
          {pending.map((item) => (
            <div key={item.label} className="rounded-2xl border border-line bg-canvas/35 p-4">
              <p className="text-xs font-bold text-forest">{item.label}</p>
              <p className="mt-1.5 text-[11px] leading-5 text-muted">{item.detail}</p>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}
