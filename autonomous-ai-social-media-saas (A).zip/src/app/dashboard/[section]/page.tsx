import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { SectionView } from "@/components/dashboard/section-view";
import {
  dashboardSections,
  isDashboardSectionKey,
  type DashboardSectionKey,
} from "@/lib/dashboard-sections";

type SectionPageProps = {
  params: Promise<{ section: string }>;
};

export const dynamicParams = false;

export function generateStaticParams() {
  return (Object.keys(dashboardSections) as DashboardSectionKey[]).map((section) => ({ section }));
}

export async function generateMetadata({ params }: SectionPageProps): Promise<Metadata> {
  const { section } = await params;
  const config = isDashboardSectionKey(section) ? dashboardSections[section] : null;

  return {
    title: config ? `${config.title} — Cadence` : "Page not found — Cadence",
    description:
      config?.description ??
      "The requested dashboard section is not part of the Phase 1 foundation.",
  };
}

export default async function DashboardSectionPage({ params }: SectionPageProps) {
  const { section } = await params;

  if (!isDashboardSectionKey(section)) {
    notFound();
  }

  return <SectionView config={dashboardSections[section]} />;
}
