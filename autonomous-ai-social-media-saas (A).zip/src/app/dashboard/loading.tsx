import { LoadingState } from "@/components/ui/empty-state";

export default function DashboardLoading() {
  return <LoadingState label="Preparing interface preview" />;
}
