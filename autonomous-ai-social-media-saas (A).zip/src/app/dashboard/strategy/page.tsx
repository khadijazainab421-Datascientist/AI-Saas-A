import { redirect } from "next/navigation";
import { BookOpen, Globe2, Layers3, Search } from "lucide-react";
import { requireSessionUser } from "@/lib/session";
import { getActiveWorkspace, getBusinessesForWorkspace } from "@/lib/tenancy";
import { getAiDashboardData, getProviderStatus } from "@/lib/ai/queries";
import { AiActions } from "@/components/dashboard/ai-actions";
import { Badge, Eyebrow, Panel, StatusDot } from "@/components/ui/surface";
import { EmptyState } from "@/components/ui/empty-state";

export const metadata = { title: "Strategy — Cadence" };

const dateFormatter = new Intl.DateTimeFormat("en-GB", {
  dateStyle: "medium",
  timeStyle: "short",
});

export default async function StrategyPage() {
  const user = await requireSessionUser();
  const activeWorkspace = await getActiveWorkspace(user);
  if (!activeWorkspace) redirect("/onboarding");

  const workspaceId = activeWorkspace.workspace.id;

  const [businesses, data, providers] = await Promise.all([
    getBusinessesForWorkspace(workspaceId),
    getAiDashboardData(workspaceId),
    getProviderStatus(workspaceId),
  ]);

  const aiConfigured = providers.some(
    (provider) => provider.role === "ai" && provider.configured,
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-line pb-6">
        <div>
          <Eyebrow marker={false}>Phase 3 · Intelligence</Eyebrow>
          <h1 className="mt-3 font-editorial text-[clamp(2rem,3.2vw,3rem)] leading-tight tracking-[-0.025em] text-ink">
            Strategy &amp; research
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
            Brand understanding, verified research, and evidence-grounded content strategies. All
            records below are real rows from this workspace.
          </p>
        </div>
        <Badge tone={aiConfigured ? "brand" : "pending"}>
          <StatusDot tone={aiConfigured ? "brand" : "pending"} />
          {aiConfigured ? "AI configured" : "AI unconfigured"}
        </Badge>
      </div>

      <div className="grid gap-5 xl:grid-cols-[0.9fr_1.1fr]">
        <Panel className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Run the engine</h2>
            <Layers3 size={16} className="text-brand" aria-hidden="true" />
          </div>
          <p className="mt-1.5 text-xs leading-5 text-muted">
            Website analysis and research feed strategy generation. Paused tasks retain their input.
          </p>
          <div className="mt-6 border-t border-line pt-6">
            <AiActions
              workspaceId={workspaceId}
              businesses={businesses.map((item) => ({
                id: item.id,
                name: item.name,
                website: item.website,
              }))}
              mode="strategy"
              allowPaidProviders={data.settings?.allowPaidProviders ?? false}
              pausedCount={data.tasks.filter((task) => task.status === "paused").length}
            />
          </div>
        </Panel>

        <Panel className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Provider readiness</h2>
            <Badge tone="outline">No secrets shown</Badge>
          </div>
          <div className="mt-4 border-t border-line">
            {providers.map((provider) => (
              <div key={provider.key} className="flex items-center gap-3 border-b border-line py-3.5">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-canvas text-[10px] font-bold uppercase text-brand">
                  {provider.key.slice(0, 2)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-forest">{provider.label}</p>
                  <p className="text-[10px] text-muted">
                    {provider.role === "ai" ? "AI provider" : "Research provider"} ·{" "}
                    {provider.isFree ? "free tier" : "paid"} · {provider.envVar}
                  </p>
                </div>
                <span
                  className={`inline-flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-[0.11em] ${
                    provider.configured ? "text-brand" : "text-[#746444]"
                  }`}
                >
                  <StatusDot tone={provider.configured ? "brand" : "pending"} />
                  {provider.configured ? provider.status : "unconfigured"}
                </span>
              </div>
            ))}
          </div>
          <p className="mt-4 text-[11px] leading-5 text-muted">
            “Configured” means the environment variable exists. It does not mean a live call has
            succeeded. Live verification happens only after a real task completes.
          </p>
        </Panel>
      </div>

      <div className="grid gap-5 xl:grid-cols-3">
        <Panel className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Brand profiles</h2>
            <Globe2 size={16} className="text-brand" aria-hidden="true" />
          </div>
          {data.brands.length === 0 ? (
            <EmptyState
              compact
              icon={BookOpen}
              title="No website analyzed"
              description="Run website analysis to store a real, extracted brand profile."
              className="mt-5 bg-canvas/40"
            />
          ) : (
            <div className="mt-5 space-y-3 border-t border-line pt-4">
              {data.brands.map((brand) => (
                <div key={brand.id} className="rounded-2xl border border-line bg-canvas/40 p-4">
                  <p className="text-xs font-bold text-forest">
                    {businesses.find((item) => item.id === brand.businessId)?.name ?? "Business"}
                  </p>
                  <p className="mt-1 truncate text-[10px] text-muted">{brand.sourceUrl ?? "—"}</p>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {(brand.toneAttributes ?? []).slice(0, 4).map((tone) => (
                      <span key={tone} className="rounded-full bg-white px-2 py-1 text-[10px] text-forest">
                        {tone}
                      </span>
                    ))}
                    {(brand.toneAttributes ?? []).length === 0 && (
                      <span className="text-[10px] text-muted">
                        Raw extraction saved · {brand.status}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Panel>

        <Panel className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Research runs</h2>
            <Search size={16} className="text-brand" aria-hidden="true" />
          </div>
          {data.research.length === 0 ? (
            <EmptyState
              compact
              icon={Search}
              title="No research yet"
              description="Verified public sources will appear here after a successful research run."
              className="mt-5 bg-canvas/40"
            />
          ) : (
            <div className="mt-5 border-t border-line">
              {data.research.map((run) => (
                <div key={run.id} className="border-b border-line py-3.5">
                  <p className="line-clamp-2 text-xs font-bold text-forest">{run.query}</p>
                  <p className="mt-1 text-[10px] text-muted">
                    {run.status} · {run.sourceCount} sources ·{" "}
                    {dateFormatter.format(run.createdAt)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </Panel>

        <Panel className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-forest">Strategies</h2>
            <Layers3 size={16} className="text-brand" aria-hidden="true" />
          </div>
          {data.strategies.length === 0 ? (
            <EmptyState
              compact
              icon={Layers3}
              title="No strategies generated"
              description="Strategies are saved only when a real AI task completes successfully."
              className="mt-5 bg-canvas/40"
            />
          ) : (
            <div className="mt-5 border-t border-line">
              {data.strategies.map((strategy) => (
                <div key={strategy.id} className="border-b border-line py-3.5">
                  <p className="text-xs font-bold text-forest">{strategy.title}</p>
                  <p className="mt-1 text-[10px] text-muted">
                    {strategy.status} · {(strategy.pillars ?? []).length} pillars
                  </p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {(strategy.pillars ?? []).slice(0, 3).map((pillar) => (
                      <span key={pillar} className="rounded-full bg-canvas px-2 py-1 text-[10px] text-forest">
                        {pillar}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}
