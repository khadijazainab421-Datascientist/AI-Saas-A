import { asc, desc, eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { CalendarDays, Info } from "lucide-react";
import { db } from "@/db";
import { contentItems, contentSchedule } from "@/db/schema";
import { requireSessionUser } from "@/lib/session";
import { getActiveWorkspace } from "@/lib/tenancy";
import { CalendarControls, UnscheduleButton } from "@/components/dashboard/calendar-form";
import { Badge, Eyebrow, Panel } from "@/components/ui/surface";
import { EmptyState } from "@/components/ui/empty-state";

export const metadata = { title: "Content Calendar — Cadence" };

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export default async function CalendarPage() {
  const user = await requireSessionUser();
  const activeWorkspace = await getActiveWorkspace(user);
  if (!activeWorkspace) redirect("/onboarding");

  const workspaceId = activeWorkspace.workspace.id;

  const [items, scheduleRows] = await Promise.all([
    db
      .select({ id: contentItems.id, title: contentItems.title })
      .from(contentItems)
      .where(eq(contentItems.workspaceId, workspaceId))
      .orderBy(desc(contentItems.createdAt))
      .limit(50),
    db
      .select()
      .from(contentSchedule)
      .where(eq(contentSchedule.workspaceId, workspaceId))
      .orderBy(asc(contentSchedule.scheduledFor))
      .limit(100),
  ]);

  const titleById = new Map(items.map((item) => [item.id, item.title]));

  const now = new Date();
  const year = now.getUTCFullYear();
  const month = now.getUTCMonth();
  const firstDay = new Date(Date.UTC(year, month, 1));
  const daysInMonth = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  const leadingBlanks = (firstDay.getUTCDay() + 6) % 7;

  const entriesByDay = new Map<string, typeof scheduleRows>();
  for (const entry of scheduleRows) {
    const key = entry.scheduledFor.toISOString().slice(0, 10);
    const list = entriesByDay.get(key) ?? [];
    list.push(entry);
    entriesByDay.set(key, list);
  }

  const todayKey = now.toISOString().slice(0, 10);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-line pb-6">
        <div>
          <Eyebrow marker={false}>Phase 4 · Planning</Eyebrow>
          <h1 className="mt-3 font-editorial text-[clamp(2rem,3.2vw,3rem)] leading-tight tracking-[-0.025em] text-ink">
            Content Calendar
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
            Real planned entries for this workspace. Nothing is published and no success state is
            simulated — official OAuth and a publishing worker arrive in Phases 5–6.
          </p>
        </div>
        <Badge tone="pending">Planned only</Badge>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1.55fr_0.45fr]">
        <Panel className="p-5 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-4">
            <h2 className="font-editorial text-2xl text-ink">
              {MONTHS[month]} {year}
            </h2>
            <p className="text-[10px] font-bold uppercase tracking-[0.13em] text-muted">UTC</p>
          </div>

          <div className="mt-4 grid grid-cols-7 gap-1.5">
            {WEEKDAYS.map((day) => (
              <div key={day} className="pb-2 text-center text-[9px] font-bold uppercase tracking-[0.12em] text-muted">
                {day}
              </div>
            ))}

            {Array.from({ length: leadingBlanks }, (_, index) => (
              <div key={`blank-${index}`} className="min-h-[86px] rounded-xl bg-canvas/30" />
            ))}

            {Array.from({ length: daysInMonth }, (_, index) => {
              const day = index + 1;
              const key = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
              const entries = entriesByDay.get(key) ?? [];

              return (
                <div
                  key={key}
                  className={`min-h-[86px] rounded-xl border p-2 ${
                    key === todayKey ? "border-brand bg-mint/25" : "border-line bg-soft"
                  }`}
                >
                  <p className="text-[10px] font-bold text-forest">{day}</p>
                  <div className="mt-1.5 space-y-1">
                    {entries.slice(0, 2).map((entry) => (
                      <div
                        key={entry.id}
                        className="rounded-lg bg-white px-1.5 py-1 text-[9px] leading-3 text-forest"
                      >
                        <p className="line-clamp-1 font-bold">
                          {titleById.get(entry.contentId) ?? "Content"}
                        </p>
                        <p className="text-muted">{entry.platform}</p>
                      </div>
                    ))}
                    {entries.length > 2 && (
                      <p className="text-[9px] text-muted">+{entries.length - 2} more</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </Panel>

        <div className="space-y-5">
          <Panel className="p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-forest">Add entry</h2>
              <CalendarDays size={16} className="text-brand" aria-hidden="true" />
            </div>
            <div className="mt-5 border-t border-line pt-5">
              <CalendarControls
                workspaceId={workspaceId}
                items={items.map((item) => ({ id: item.id, title: item.title }))}
              />
            </div>
          </Panel>

          <Panel className="flex items-start gap-3 bg-canvas/60 p-4">
            <Info size={15} className="mt-0.5 shrink-0 text-brand" aria-hidden="true" />
            <p className="text-[11px] leading-5 text-muted">
              Entries are stored as <span className="font-bold text-forest">planned</span>. No
              platform API is called. Publishing logs, retries, and duplicate prevention are Phase 6.
            </p>
          </Panel>
        </div>
      </div>

      <Panel className="p-6">
        <h2 className="text-sm font-bold text-forest">All planned entries ({scheduleRows.length})</h2>
        {scheduleRows.length === 0 ? (
          <EmptyState
            compact
            icon={CalendarDays}
            title="Nothing scheduled"
            description="Create content in the studio, then add a planned date here. No fabricated schedule is displayed."
            className="mt-5 bg-canvas/40"
          />
        ) : (
          <div className="mt-5 border-t border-line">
            {scheduleRows.map((entry) => (
              <div key={entry.id} className="flex flex-wrap items-center gap-3 border-b border-line py-3.5">
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-forest">
                    {titleById.get(entry.contentId) ?? "Content"}
                  </p>
                  <p className="mt-1 text-[10px] text-muted">
                    {entry.platform} · {entry.status} · {entry.timezone} ·{" "}
                    {new Intl.DateTimeFormat("en-GB", {
                      dateStyle: "medium",
                      timeStyle: "short",
                    }).format(entry.scheduledFor)}
                  </p>
                </div>
                <UnscheduleButton workspaceId={workspaceId} entryId={entry.id} />
              </div>
            ))}
          </div>
        )}
      </Panel>
    </div>
  );
}
