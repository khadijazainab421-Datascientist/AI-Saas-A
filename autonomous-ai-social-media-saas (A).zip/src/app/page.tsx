import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  Building2,
  CalendarClock,
  Check,
  CircleDot,
  Compass,
  Eye,
  FileCheck2,
  LockKeyhole,
  Network,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { ProductPreview } from "@/components/landing/product-preview";
import { ButtonLink } from "@/components/ui/button";
import { Badge, Eyebrow, StatusDot } from "@/components/ui/surface";

const principles = [
  {
    icon: Building2,
    title: "Business-first structure",
    description:
      "Separate brand profiles, strategies, content, permissions, and reporting so every business keeps its own context.",
  },
  {
    icon: ShieldCheck,
    title: "Boundaries by default",
    description:
      "Tenant isolation, least-privilege credentials, and explicit review gates are design requirements—not afterthoughts.",
  },
  {
    icon: Network,
    title: "Evidence before action",
    description:
      "Research, performance, and publishing records should stay traceable so the agent can explain what informed a decision.",
  },
];

const method = [
  {
    number: "01",
    title: "Understand",
    description: "Business profile, voice, audiences, objectives, and website context.",
    phase: "Phase 3",
  },
  {
    number: "02",
    title: "Research",
    description: "Public sources, industry signals, seasonal opportunities, and topics.",
    phase: "Phase 3",
  },
  {
    number: "03",
    title: "Compose",
    description: "Strategy, platform adaptations, captions, media, and editorial review.",
    phase: "Phase 4",
  },
  {
    number: "04",
    title: "Publish",
    description: "Official OAuth publishing, logs, retries, and measured learning.",
    phase: "Phases 5–7",
  },
];

const platforms = [
  { mark: "IG", name: "Instagram", scope: "Professional accounts and supported publishing formats" },
  { mark: "f", name: "Facebook", scope: "Pages and supported Graph API publishing formats" },
  { mark: "in", name: "LinkedIn", scope: "Organization and member posts permitted by the API" },
];

const autonomyModes = [
  { id: "review-all", label: "Review every post before publishing", checked: true },
  { id: "review-categories", label: "Review selected content categories", checked: false },
  { id: "routine", label: "Autonomously publish routine content", checked: false },
  { id: "pause", label: "Pause all autonomous activity", checked: false },
];

const tiers = [
  { name: "Free", shape: "One workspace with limited AI and scheduling" },
  { name: "Starter", shape: "More content, accounts, and brand voice controls" },
  { name: "Professional", shape: "Multiple businesses and advanced autonomy" },
  { name: "Agency", shape: "Client workspaces, teams, and centralized reporting" },
];

const phases = [
  { number: "01", name: "Foundation and UI", detail: "Design system, landing page, dashboard shell", status: "Complete" },
  { number: "02", name: "Database and Authentication", detail: "Sessions, workspaces, businesses, tenant isolation", status: "Complete" },
  { number: "03", name: "AI and Research Engine", detail: "Provider abstraction, fallback, strategy, usage", status: "Complete" },
  { number: "04", name: "Content Creation Studio", detail: "Captions, media sourcing, editor, calendar", status: "In review" },
  { number: "05", name: "Social Platform Integrations", detail: "Official OAuth and live publishing tests", status: "Planned" },
  { number: "06", name: "Autonomous Agent and Automation", detail: "Workers, logs, retries, autonomy controls", status: "Planned" },
  { number: "07", name: "Analytics and Billing", detail: "Performance reporting, usage limits, payments", status: "Planned" },
  { number: "08", name: "Security, Testing and Launch", detail: "Isolation tests, hardening, production review", status: "Planned" },
];

export default function HomePage() {
  return (
    <>
      <SiteHeader />
      <main>
        <section className="relative overflow-hidden border-b border-line bg-canvas/50">
          <div aria-hidden="true" className="dot-grid absolute inset-0 opacity-30" />
          <div className="relative mx-auto grid max-w-[1320px] items-center gap-14 px-5 pb-20 pt-16 sm:px-8 lg:grid-cols-[0.92fr_1.08fr] lg:gap-10 lg:px-10 lg:pb-28 lg:pt-24">
            <div className="reveal max-w-[620px]">
              <Eyebrow>Phase 3 · AI &amp; Research Engine</Eyebrow>
              <h1 className="mt-7 font-editorial text-[clamp(3.15rem,6.2vw,6.15rem)] leading-[0.96] tracking-[-0.045em] text-ink">
                A quieter way to <span className="text-brand">run social media.</span>
              </h1>
              <div className="mt-8 h-px w-28 bg-brand/30" />
              <p className="mt-7 max-w-lg text-[16px] leading-7 text-muted sm:text-[17px]">
                Cadence is being built as a multi-tenant operating system for AI-assisted research,
                planning, creation, publishing, and learning — with human control at every step.
              </p>
              <div className="mt-9 flex flex-wrap items-center gap-3">
                <ButtonLink href="/dashboard" size="lg">
                  Review the dashboard <ArrowUpRight size={16} aria-hidden="true" />
                </ButtonLink>
                <ButtonLink href="/#method" variant="secondary" size="lg">
                  See the build method <ArrowRight size={16} aria-hidden="true" />
                </ButtonLink>
              </div>
              <div className="mt-9 flex items-start gap-3 rounded-2xl border border-line bg-white/65 px-4 py-3.5">
                <StatusDot tone="pending" />
                <p className="text-xs leading-5 text-muted">
                  <span className="font-bold text-forest">Phase 3 in review.</span> The AI/research
                  engine is built, but live provider calls await key configuration. Social
                  connections, publishing, and analytics are still inactive.
                </p>
              </div>
            </div>

            <div className="reveal lg:pl-4">
              <ProductPreview />
            </div>
          </div>

          <div className="relative border-t border-line/80 bg-soft/50">
            <div className="mx-auto grid max-w-[1320px] sm:grid-cols-2 lg:grid-cols-4">
              {[
                "Multi-tenant by design",
                "Human review by default",
                "Official OAuth only",
                "No social passwords",
              ].map((item) => (
                <div
                  key={item}
                  className="flex items-center gap-2.5 border-b border-line/70 px-5 py-4 text-[11px] font-bold uppercase tracking-[0.13em] text-forest last:border-b-0 sm:border-r sm:[&:nth-child(2n)]:border-r-0 sm:[&:nth-child(n+3)]:border-b-0 lg:[&:nth-child(2n)]:border-r lg:[&:nth-child(n+3)]:border-b-0 lg:last:border-r-0"
                >
                  <Check size={14} className="text-brand" aria-hidden="true" />
                  {item}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="platform" className="scroll-mt-20 border-b border-line bg-soft">
          <div className="mx-auto grid max-w-[1320px] gap-12 px-5 py-20 sm:px-8 lg:grid-cols-[0.78fr_1.22fr] lg:px-10 lg:py-24">
            <div>
              <Eyebrow>Platform principles</Eyebrow>
              <h2 className="mt-6 max-w-sm font-editorial text-[clamp(2.4rem,4vw,4rem)] leading-[1.04] tracking-[-0.025em] text-ink">
                Clarity before automation.
              </h2>
              <p className="mt-6 max-w-md text-sm leading-7 text-muted">
                Autonomous systems need legible boundaries. These are the architectural commitments
                guiding later phases, not claims about live integrations.
              </p>
              <Link
                href="/dashboard"
                className="mt-8 inline-flex items-center gap-2 text-sm font-bold text-brand transition-colors hover:text-forest"
              >
                Explore the interface <ArrowUpRight size={15} aria-hidden="true" />
              </Link>
            </div>

            <div className="border-t border-line">
              {principles.map((principle) => {
                const Icon = principle.icon;
                return (
                  <article
                    key={principle.title}
                    className="group grid gap-5 border-b border-line py-7 sm:grid-cols-[56px_1fr]"
                  >
                    <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-canvas text-brand transition-colors group-hover:bg-mint">
                      <Icon size={20} strokeWidth={1.7} aria-hidden="true" />
                    </span>
                    <div>
                      <h3 className="font-editorial text-2xl text-ink">{principle.title}</h3>
                      <p className="mt-2 max-w-xl text-sm leading-6 text-muted">
                        {principle.description}
                      </p>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section className="border-b border-line bg-canvas/45">
          <div className="mx-auto grid max-w-[1320px] items-center gap-14 px-5 py-20 sm:px-8 lg:grid-cols-2 lg:px-10 lg:py-24">
            <div className="relative">
              <div className="editorial-frame relative aspect-[4/3] overflow-hidden rounded-[28px] border border-white/70">
                <Image
                  src="/images/editorial-glass.jpg"
                  alt="Layered translucent mint glass and folded sage paper in soft studio light"
                  fill
                  sizes="(max-width: 1024px) 100vw, 50vw"
                  className="object-cover"
                />
              </div>
              <div className="glass-surface absolute -bottom-5 right-5 max-w-[250px] rounded-2xl px-4 py-3.5">
                <p className="text-[10px] font-bold uppercase tracking-[0.17em] text-brand">
                  Visual direction
                </p>
                <p className="mt-1.5 text-xs leading-5 text-forest">
                  Layered, soft, editorial — glass used sparingly, never as decoration for its own sake.
                </p>
              </div>
            </div>

            <div className="lg:pl-8">
              <Eyebrow>Design philosophy</Eyebrow>
              <h2 className="mt-6 font-editorial text-[clamp(2.5rem,4.4vw,4.4rem)] leading-[1.02] tracking-[-0.03em] text-ink">
                Intelligence with restraint.
              </h2>
              <p className="mt-6 max-w-lg text-sm leading-7 text-muted">
                The interface keeps the important things close: what the agent knows, what it plans,
                what needs approval, and what actually happened. Calm surfaces and strong contrast
                make dense operational work easier to read.
              </p>
              <div className="mt-9 space-y-0 border-t border-line">
                {[
                  { icon: Eye, label: "Visible reasoning", text: "Plans and provenance stay inspectable." },
                  { icon: FileCheck2, label: "Explicit approval", text: "Sensitive work is held for review." },
                  { icon: BarChart3, label: "Real measurements", text: "No invented performance data." },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.label} className="flex items-center gap-4 border-b border-line py-4">
                      <Icon size={18} className="text-brand" strokeWidth={1.7} aria-hidden="true" />
                      <p className="text-sm font-bold text-forest">{item.label}</p>
                      <p className="ml-auto hidden max-w-[220px] text-right text-xs leading-5 text-muted sm:block">
                        {item.text}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <section id="method" className="scroll-mt-20 border-b border-line bg-soft">
          <div className="mx-auto max-w-[1320px] px-5 py-20 sm:px-8 lg:px-10 lg:py-24">
            <div className="flex flex-col justify-between gap-6 border-b border-line pb-8 lg:flex-row lg:items-end">
              <div>
                <Eyebrow>Planned capability map · Phases 3–7</Eyebrow>
                <h2 className="mt-6 max-w-2xl font-editorial text-[clamp(2.4rem,4vw,4rem)] leading-[1.04] tracking-[-0.025em] text-ink">
                  One deliberate sequence.
                </h2>
              </div>
              <p className="max-w-sm text-sm leading-7 text-muted">
                Each capability builds on verified data, explicit permissions, and a reviewable
                record. No stage is presented as live until it has been tested.
              </p>
            </div>

            <div className="grid border-b border-line sm:grid-cols-2 lg:grid-cols-4">
              {method.map((step, index) => (
                <article
                  key={step.number}
                  className={`relative py-8 pr-6 sm:px-6 sm:first:pl-0 lg:border-r lg:last:border-r-0 ${
                    index < 2 ? "border-b border-line lg:border-b-0" : ""
                  } ${index === 1 ? "sm:border-r sm:border-line" : ""}`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-editorial text-3xl text-sage">{step.number}</span>
                    <CircleDot size={16} className="text-brand/40" aria-hidden="true" />
                  </div>
                  <h3 className="mt-7 text-lg font-bold text-forest">{step.title}</h3>
                  <p className="mt-2 min-h-[72px] max-w-[240px] text-sm leading-6 text-muted">
                    {step.description}
                  </p>
                  <p className="mt-5 text-[10px] font-bold uppercase tracking-[0.16em] text-brand">
                    {step.phase}
                  </p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="coverage" className="scroll-mt-20 bg-forest text-white">
          <div className="mx-auto grid max-w-[1320px] gap-12 px-5 py-20 sm:px-8 lg:grid-cols-[0.8fr_1.2fr] lg:px-10 lg:py-24">
            <div>
              <p className="flex items-center gap-2.5 text-[11px] font-bold uppercase tracking-[0.19em] text-mint">
                <span aria-hidden="true" className="text-[15px] leading-none text-sage">✳</span>
                Initial platform scope
              </p>
              <h2 className="mt-6 font-editorial text-[clamp(2.4rem,4vw,4rem)] leading-[1.04] tracking-[-0.025em]">
                Official APIs. Nothing improvised.
              </h2>
              <p className="mt-6 max-w-md text-sm leading-7 text-mint/80">
                Instagram, Facebook, and LinkedIn are the first planned integrations. Their developer
                applications, permissions, app review, and credential requirements will be disclosed
                individually in Phase 5, before any live authorization is attempted.
              </p>
              <div className="mt-8 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/6 px-3 py-2 text-[10px] font-bold uppercase tracking-[0.15em] text-mint">
                <LockKeyhole size={13} aria-hidden="true" />
                Phase 3 keys await configuration
              </div>
            </div>

            <div className="border-t border-white/18">
              {platforms.map((platform) => (
                <div
                  key={platform.name}
                  className="flex flex-col gap-4 border-b border-white/18 py-6 sm:flex-row sm:items-center"
                >
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/25 bg-white/8 font-editorial text-xl text-white">
                    {platform.mark}
                  </span>
                  <div className="flex-1">
                    <h3 className="font-editorial text-2xl">{platform.name}</h3>
                    <p className="mt-1 text-xs leading-5 text-mint/75">{platform.scope}</p>
                  </div>
                  <span className="inline-flex w-fit items-center gap-2 rounded-full border border-white/20 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-mint">
                    <StatusDot tone="pending" /> Not connected
                  </span>
                </div>
              ))}
              <p className="pt-5 text-xs leading-6 text-mint/70">
                Publishing eligibility, account types, format restrictions, and unsupported features
                will be documented from official platform documentation in Phase 5.
              </p>
            </div>
          </div>
        </section>

        <section className="border-b border-line bg-soft">
          <div className="mx-auto grid max-w-[1320px] gap-6 px-5 py-20 sm:px-8 lg:grid-cols-2 lg:px-10 lg:py-24">
            <div className="rounded-[28px] border border-line bg-canvas/55 p-7 sm:p-9">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <Eyebrow>Control model</Eyebrow>
                  <h2 className="mt-5 font-editorial text-3xl leading-tight text-ink sm:text-4xl">
                    Autonomy is a setting, not an assumption.
                  </h2>
                </div>
                <Badge tone="pending">Phase 6 preview</Badge>
              </div>
              <p className="mt-5 max-w-lg text-sm leading-7 text-muted">
                The planned agent will support review gates, category-level approval, publishing
                limits, and a complete pause. These controls are disabled in the foundation build.
              </p>

              <fieldset disabled aria-describedby="autonomy-note" className="mt-8 border-t border-line">
                <legend className="sr-only">Planned autonomy modes</legend>
                {autonomyModes.map((mode) => (
                  <label
                    key={mode.id}
                    htmlFor={mode.id}
                    className="flex cursor-not-allowed items-center gap-3 border-b border-line py-4 text-sm font-semibold text-forest/70"
                  >
                    <input
                      id={mode.id}
                      name="autonomy"
                      type="radio"
                      defaultChecked={mode.checked}
                      disabled
                      className="h-4 w-4 accent-brand"
                    />
                    {mode.label}
                    {mode.checked && (
                      <span className="ml-auto text-[10px] font-bold uppercase tracking-[0.13em] text-brand">
                        Default
                      </span>
                    )}
                  </label>
                ))}
              </fieldset>
              <p id="autonomy-note" className="mt-5 text-xs leading-5 text-muted">
                Disabled intentionally: autonomy requires authenticated workspaces, credentials, and
                a publishing worker before it can operate safely.
              </p>
            </div>

            <div className="rounded-[28px] border border-line bg-white p-7 sm:p-9">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <Eyebrow>Subscription architecture</Eyebrow>
                  <h2 className="mt-5 font-editorial text-3xl leading-tight text-ink sm:text-4xl">
                    Four shapes of work.
                  </h2>
                </div>
                <Badge tone="outline">Billing not configured</Badge>
              </div>
              <p className="mt-5 max-w-lg text-sm leading-7 text-muted">
                Plan structure is reserved in the product model. Limits remain configurable, and no
                arbitrary prices, quotas, or payment claims are introduced in this phase.
              </p>

              <div className="mt-8 border-t border-line">
                {tiers.map((tier, index) => (
                  <div
                    key={tier.name}
                    className="flex items-start gap-5 border-b border-line py-5"
                  >
                    <span className="pt-1 font-editorial text-lg text-sage">0{index + 1}</span>
                    <div>
                      <h3 className="text-base font-bold text-forest">{tier.name}</h3>
                      <p className="mt-1 text-xs leading-5 text-muted">{tier.shape}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-6 flex items-start gap-3 rounded-2xl bg-canvas px-4 py-3.5">
                <CalendarClock size={17} className="mt-0.5 shrink-0 text-brand" aria-hidden="true" />
                <p className="text-xs leading-5 text-muted">
                  Payment provider selection, costs, and billing requirements will be identified in
                  Phase 7 before any gateway integration.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="roadmap" className="scroll-mt-20 border-b border-line bg-canvas/45">
          <div className="mx-auto max-w-[1320px] px-5 py-20 sm:px-8 lg:px-10 lg:py-24">
            <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
              <div>
                <Eyebrow>Controlled delivery</Eyebrow>
                <h2 className="mt-6 font-editorial text-[clamp(2.4rem,4vw,4rem)] leading-[1.04] tracking-[-0.025em] text-ink">
                  Eight phases. One at a time.
                </h2>
              </div>
              <p className="max-w-md text-sm leading-7 text-muted">
                Work stops after each phase for review and explicit approval. Phases 1–2 are
                complete; Phase 3 awaits live key configuration and your review.
              </p>
            </div>

            <div className="mt-12 border-t border-line">
              {phases.map((phase) => {
                const current = phase.number === "01";
                return (
                  <div
                    key={phase.number}
                    className={`grid gap-3 border-b border-line py-5 sm:grid-cols-[52px_190px_1fr_auto] sm:items-center sm:gap-5 ${
                      current ? "bg-soft/60" : ""
                    }`}
                  >
                    <span className={`font-editorial text-xl ${current ? "text-brand" : "text-sage"}`}>
                      {phase.number}
                    </span>
                    <h3 className="text-sm font-bold text-forest">{phase.name}</h3>
                    <p className="text-xs leading-5 text-muted">{phase.detail}</p>
                    <span
                      className={`inline-flex w-fit items-center gap-2 text-[10px] font-bold uppercase tracking-[0.14em] ${
                        current ? "text-brand" : "text-muted"
                      }`}
                    >
                      <StatusDot tone={current ? "brand" : "inactive"} />
                      {phase.status}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="bg-soft">
          <div className="mx-auto max-w-[1320px] px-5 py-16 sm:px-8 lg:px-10 lg:py-20">
            <div className="relative overflow-hidden rounded-[32px] bg-forest px-6 py-14 sm:px-12 lg:px-16 lg:py-16">
              <svg
                aria-hidden="true"
                viewBox="0 0 500 300"
                className="pointer-events-none absolute -right-20 -top-24 h-[420px] w-[420px] opacity-20"
              >
                {[70, 115, 160, 205].map((radius) => (
                  <circle
                    key={radius}
                    cx="250"
                    cy="150"
                    r={radius}
                    fill="none"
                    stroke="#DCEBE4"
                    strokeWidth="1"
                  />
                ))}
              </svg>
              <div className="relative max-w-2xl">
                <p className="flex items-center gap-2.5 text-[11px] font-bold uppercase tracking-[0.19em] text-mint">
                  <Sparkles size={14} aria-hidden="true" /> Phase 1 review
                </p>
                <h2 className="mt-6 font-editorial text-[clamp(2.5rem,4.5vw,4.5rem)] leading-[1.02] tracking-[-0.03em] text-white">
                  See the foundation before the machinery arrives.
                </h2>
                <p className="mt-6 max-w-xl text-sm leading-7 text-mint/80">
                  The dashboard preview shows navigation, layout, empty states, loading patterns,
                  and honest integration readiness — without pretending that later phases are live.
                </p>
                <div className="mt-9 flex flex-wrap gap-3">
                  <ButtonLink href="/dashboard" size="lg" className="bg-white text-forest hover:bg-mint hover:text-forest">
                    Open dashboard preview <ArrowUpRight size={16} aria-hidden="true" />
                  </ButtonLink>
                  <Link
                    href="/#platform"
                    className="inline-flex h-12 items-center gap-2 rounded-full border border-white/25 px-6 text-sm font-semibold text-white transition-colors hover:bg-white/10"
                  >
                    <Compass size={16} aria-hidden="true" /> Revisit principles
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
