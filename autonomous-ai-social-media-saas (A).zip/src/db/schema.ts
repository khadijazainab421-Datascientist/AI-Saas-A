import {
  pgEnum,
  pgTable,
  text,
  timestamp,
  uuid,
  boolean,
  integer,
  jsonb,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Authentication (Better Auth core schema)                            */
/* ------------------------------------------------------------------ */

export const user = pgTable("user", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  emailVerified: boolean("email_verified").notNull().default(false),
  image: text("image"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const session = pgTable("session", {
  id: uuid("id").primaryKey().defaultRandom(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  token: text("token").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  userId: uuid("user_id")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
});

export const account = pgTable("account", {
  id: uuid("id").primaryKey().defaultRandom(),
  accountId: text("account_id").notNull(),
  providerId: text("provider_id").notNull(),
  userId: uuid("user_id")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  idToken: text("id_token"),
  accessTokenExpiresAt: timestamp("access_token_expires_at", { withTimezone: true }),
  refreshTokenExpiresAt: timestamp("refresh_token_expires_at", { withTimezone: true }),
  scope: text("scope"),
  password: text("password"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const verification = pgTable("verification", {
  id: uuid("id").primaryKey().defaultRandom(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Multi-tenant workspace model                                       */
/* ------------------------------------------------------------------ */

export const workspaceRole = pgEnum("workspace_role", ["owner", "admin", "member"]);

export const workspaces = pgTable("workspaces", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  ownerId: uuid("owner_id")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const workspaceMembers = pgTable(
  "workspace_members",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => user.id, { onDelete: "cascade" }),
    role: workspaceRole("role").notNull().default("member"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("workspace_members_workspace_user_idx").on(table.workspaceId, table.userId),
    index("workspace_members_user_idx").on(table.userId),
  ],
);

/* ------------------------------------------------------------------ */
/* Business profiles                                                   */
/* ------------------------------------------------------------------ */

export const businesses = pgTable(
  "businesses",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    website: text("website"),
    industry: text("industry"),
    description: text("description"),
    brandVoice: text("brand_voice"),
    targetAudience: text("target_audience"),
    goals: text("goals"),
    timezone: text("timezone").notNull().default("UTC"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("businesses_workspace_idx").on(table.workspaceId)],
);

export type User = typeof user.$inferSelect;
export type Workspace = typeof workspaces.$inferSelect;
export type WorkspaceMember = typeof workspaceMembers.$inferSelect;
export type Business = typeof businesses.$inferSelect;
export type WorkspaceRoleName = (typeof workspaceRole.enumValues)[number];

/* ------------------------------------------------------------------ */
/* Phase 3 — AI, research, strategy, usage and notifications           */
/* ------------------------------------------------------------------ */

export const aiTaskStatus = pgEnum("ai_task_status", [
  "queued",
  "running",
  "paused",
  "completed",
  "failed",
]);

export const aiTaskKind = pgEnum("ai_task_kind", [
  "website_analysis",
  "research",
  "strategy",
  "caption",
  "content_ideas",
]);

export const providerHealthStatus = pgEnum("provider_health_status", [
  "unconfigured",
  "configured",
  "healthy",
  "degraded",
  "rate_limited",
  "down",
]);

/** Per-tenant AI permissions. Paid providers are never used by default. */
export const workspaceAiSettings = pgTable("workspace_ai_settings", {
  workspaceId: uuid("workspace_id")
    .primaryKey()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  allowPaidProviders: boolean("allow_paid_providers").notNull().default(false),
  maxAiTasksPerDay: integer("max_ai_tasks_per_day").notNull().default(20),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Global provider health. Never stores secrets — env vars only. */
export const providerHealth = pgTable("provider_health", {
  providerKey: text("provider_key").primaryKey(),
  status: providerHealthStatus("status").notNull().default("unconfigured"),
  lastCheckedAt: timestamp("last_checked_at", { withTimezone: true }),
  lastError: text("last_error"),
  quotaResetAt: timestamp("quota_reset_at", { withTimezone: true }),
  consecutiveFailures: integer("consecutive_failures").notNull().default(0),
});

/** Durable task record. Paused tasks keep their input so work is never lost. */
export const aiTasks = pgTable(
  "ai_tasks",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    businessId: uuid("business_id").references(() => businesses.id, { onDelete: "set null" }),
    kind: aiTaskKind("kind").notNull(),
    status: aiTaskStatus("status").notNull().default("queued"),
    providerKey: text("provider_key"),
    attemptCount: integer("attempt_count").notNull().default(0),
    pausedReason: text("paused_reason"),
    input: jsonb("input").$type<Record<string, unknown>>().notNull().default({}),
    output: jsonb("output").$type<Record<string, unknown> | null>(),
    error: text("error"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("ai_tasks_workspace_idx").on(table.workspaceId),
    index("ai_tasks_status_idx").on(table.status),
  ],
);

export const aiUsage = pgTable(
  "ai_usage",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    taskId: uuid("task_id").references(() => aiTasks.id, { onDelete: "set null" }),
    providerKey: text("provider_key").notNull(),
    tokensIn: integer("tokens_in").notNull().default(0),
    tokensOut: integer("tokens_out").notNull().default(0),
    credits: integer("credits").notNull().default(0),
    latencyMs: integer("latency_ms").notNull().default(0),
    status: text("status").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ai_usage_workspace_idx").on(table.workspaceId)],
);

export const brandProfiles = pgTable("brand_profiles", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  businessId: uuid("business_id")
    .notNull()
    .references(() => businesses.id, { onDelete: "cascade" }),
  sourceUrl: text("source_url"),
  status: text("status").notNull().default("not_analyzed"),
  rawExcerpt: text("raw_excerpt"),
  toneAttributes: jsonb("tone_attributes").$type<string[]>().default([]),
  audienceSegments: jsonb("audience_segments").$type<string[]>().default([]),
  valuePropositions: jsonb("value_propositions").$type<string[]>().default([]),
  sensitiveTopics: jsonb("sensitive_topics").$type<string[]>().default([]),
  analyzedAt: timestamp("analyzed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const researchRuns = pgTable(
  "research_runs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    businessId: uuid("business_id").references(() => businesses.id, { onDelete: "set null" }),
    query: text("query").notNull(),
    providerKey: text("provider_key").notNull().default("tavily"),
    status: text("status").notNull().default("pending"),
    sourceCount: integer("source_count").notNull().default(0),
    results: jsonb("results").$type<ResearchSource[]>().default([]),
    error: text("error"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("research_runs_workspace_idx").on(table.workspaceId)],
);

export const contentStrategies = pgTable(
  "content_strategies",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    businessId: uuid("business_id")
      .notNull()
      .references(() => businesses.id, { onDelete: "cascade" }),
    sourceTaskId: uuid("source_task_id").references(() => aiTasks.id, { onDelete: "set null" }),
    title: text("title").notNull(),
    status: text("status").notNull().default("draft"),
    pillars: jsonb("pillars").$type<string[]>().default([]),
    formats: jsonb("formats").$type<string[]>().default([]),
    cadence: text("cadence"),
    rationale: text("rationale"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("content_strategies_workspace_idx").on(table.workspaceId)],
);

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    userId: uuid("user_id").references(() => user.id, { onDelete: "cascade" }),
    type: text("type").notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("notifications_workspace_idx").on(table.workspaceId)],
);

export type ResearchSource = { title: string; url: string; snippet: string };
export type AiTask = typeof aiTasks.$inferSelect;
export type AiUsage = typeof aiUsage.$inferSelect;
export type BrandProfile = typeof brandProfiles.$inferSelect;
export type ResearchRun = typeof researchRuns.$inferSelect;
export type ContentStrategy = typeof contentStrategies.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type WorkspaceAiSettings = typeof workspaceAiSettings.$inferSelect;
export type ProviderHealth = typeof providerHealth.$inferSelect;

/* ------------------------------------------------------------------ */
/* Phase 4 — Content Creation Studio                                    */
/* ------------------------------------------------------------------ */

export const contentItems = pgTable(
  "content_items",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    businessId: uuid("business_id").references(() => businesses.id, { onDelete: "set null" }),
    title: text("title").notNull(),
    type: text("type").notNull().default("post"),
    status: text("status").notNull().default("draft"),
    platform: text("platform").notNull().default("multi"),
    caption: text("caption").notNull().default(""),
    body: text("body").notNull().default(""),
    hashtags: jsonb("hashtags").$type<string[]>().default([]),
    mediaAssetIds: jsonb("media_asset_ids").$type<string[]>().default([]),
    sourceTaskId: uuid("source_task_id").references(() => aiTasks.id, { onDelete: "set null" }),
    requiresReview: boolean("requires_review").notNull().default(false),
    createdBy: uuid("created_by").references(() => user.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("content_items_workspace_idx").on(table.workspaceId)],
);

export const contentVersions = pgTable(
  "content_versions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    contentId: uuid("content_id")
      .notNull()
      .references(() => contentItems.id, { onDelete: "cascade" }),
    version: integer("version").notNull(),
    title: text("title").notNull(),
    caption: text("caption").notNull(),
    body: text("body").notNull(),
    editedBy: uuid("edited_by").references(() => user.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("content_versions_content_idx").on(table.contentId)],
);

export const mediaAssets = pgTable(
  "media_assets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    businessId: uuid("business_id").references(() => businesses.id, { onDelete: "set null" }),
    kind: text("kind").notNull(), // sourced | generated | uploaded
    providerKey: text("provider_key").notNull(),
    title: text("title").notNull(),
    url: text("url"),
    thumbnailUrl: text("thumbnail_url"),
    svgData: text("svg_data"),
    creator: text("creator"),
    license: text("license"),
    licenseUrl: text("license_url"),
    attribution: text("attribution"),
    sourceUrl: text("source_url"),
    width: integer("width"),
    height: integer("height"),
    status: text("status").notNull().default("ready"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("media_assets_workspace_idx").on(table.workspaceId)],
);

export const carouselSlides = pgTable(
  "carousel_slides",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    contentId: uuid("content_id")
      .notNull()
      .references(() => contentItems.id, { onDelete: "cascade" }),
    position: integer("position").notNull(),
    headline: text("headline").notNull(),
    body: text("body").notNull().default(""),
    mediaAssetId: uuid("media_asset_id").references(() => mediaAssets.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("carousel_slides_content_idx").on(table.contentId)],
);

export const contentSchedule = pgTable(
  "content_schedule",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    contentId: uuid("content_id")
      .notNull()
      .references(() => contentItems.id, { onDelete: "cascade" }),
    platform: text("platform").notNull(),
    scheduledFor: timestamp("scheduled_for", { withTimezone: true }).notNull(),
    timezone: text("timezone").notNull().default("UTC"),
    // No publishing worker exists yet. Only "planned" is reachable in Phase 4.
    status: text("status").notNull().default("planned"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("content_schedule_workspace_idx").on(table.workspaceId)],
);

export const brandAssets = pgTable(
  "brand_assets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    businessId: uuid("business_id").references(() => businesses.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    kind: text("kind").notNull(), // logo | color | font | guideline
    value: text("value").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("brand_assets_workspace_idx").on(table.workspaceId)],
);

export type ContentItem = typeof contentItems.$inferSelect;
export type ContentVersion = typeof contentVersions.$inferSelect;
export type MediaAsset = typeof mediaAssets.$inferSelect;
export type CarouselSlide = typeof carouselSlides.$inferSelect;
export type ContentSchedule = typeof contentSchedule.$inferSelect;
export type BrandAsset = typeof brandAssets.$inferSelect;
