# Cadence — Phase 2 Completion Report

**Phase:** 2 — Database and Authentication  
**Status:** Implemented and validated; awaiting explicit approval before Phase 3.  
**Scope boundary:** Authentication (Better Auth with email/password), session management, tenant isolation, workspace creation, membership roles, and multiple business profiles are fully operational on PostgreSQL via Drizzle ORM. No AI, research, social media OAuth, media generation, background workers, or payment processing has been connected.

---

## 1. Features Implemented

### Database Architecture & Schema
- PostgreSQL 15 schema defined in `src/db/schema.ts` using `drizzle-orm/pg-core`:
  - `user`: Identity records, email, verification flags, timestamps.
  - `session`: Server-side sessions, expiry, token, IP/user-agent tracking, foreign key to `user` (cascade delete).
  - `account`: Password hashes and credential provider storage.
  - `verification`: Nonces and tokens for email verification / resets.
  - `workspaces`: Multi-tenant boundary containers with unique slugs and owner foreign key.
  - `workspace_members`: Association table linking `user` and `workspaces` with role enum (`owner`, `admin`, `member`) and unique composite index on `(workspace_id, user_id)`.
  - `businesses`: Business profiles strictly scoped to `workspace_id` with website, industry, description, brand voice, target audience, goals, and timezone.
- Applied directly via `drizzle-kit push` to local PostgreSQL without migration divergence.

### Authentication & Session Management
- Integrated **Better Auth** (v1.7.18, MIT) with Drizzle adapter and `nextCookies` plugin.
- Email & password signup with minimum 10-character password policy, Argon2/scrypt password hashing via Better Auth internal crypto.
- Secure, HTTP-only, database-backed sessions with 7-day expiration.
- Custom authentication layout and accessible UI forms (`/sign-in` and `/sign-up`) with full client-side and server-side Zod validation, password visibility toggles, and clear error banners.
- Next.js 16 route proxy (`src/proxy.ts`) providing optimistic redirects to `/sign-in` with return-path preservation.
- Server-side session verification helper (`getSessionUser`, `requireSessionUser`) that strictly checks the session against the database on every protected page and server action.

### Multi-Tenant Isolation & Workspace Architecture
- Authoritative tenant boundary check in `src/lib/tenancy.ts`:
  - `requireWorkspaceMembership(userId, workspaceId)`: Verifies membership against database records before any workspace data is read or written. Cross-tenant IDs or tampered cookies are immediately rejected with `TenantAccessError`.
  - Stale or forged workspace cookies can never access another tenant's data.
- Workspace switcher supporting users with multiple memberships.
- Automatic redirect from `/dashboard` to `/onboarding` for authenticated users who have not yet established a workspace.
- Dynamic sign-out action (`signOutAction`) clearing the session token on the server and cleaning up local tenant cookies.

### Business Profiles Management
- Dedicated business profile management under `/dashboard/businesses` and during `/onboarding`.
- Modal dialog and responsive forms for creating, editing, and safely deleting business profiles.
- Automatic scoping of all business queries and mutations by `workspace_id`.
- Real-time workspace stats on the command center overview reflecting live tenant records.

---

## 2. API Discovery & Credential Status for Phase 3

### Phase 2 Credentials
- **No external API credentials were required.**
- Better Auth runs entirely self-hosted against the local PostgreSQL instance.
- A local 32-byte secret was generated for `BETTER_AUTH_SECRET` and saved to the gitignored `.env` file. A sanitized template is maintained in `.env.example`.

### Phase 3 Credential Requirements (MANDATORY DISCLOSURE)
Phase 3 introduces the **AI and Research Engine** (provider abstraction, hybrid fallback, business website analysis, research engine, and content strategy generation).

Before testing live integrations in Phase 3, the following services and credentials are required:

1. **Primary AI Provider (Free-First Choice): Google Gemini API**
   - **Service:** Google AI Studio / Gemini API
   - **Purpose:** Core LLM for website understanding, brand profiling, content strategy synthesis, and caption planning.
   - **Website / Docs:** https://ai.google.dev/ | https://ai.google.dev/gemini-api/docs
   - **How to create account:** Visit Google AI Studio with any Google account.
   - **How to generate API key:** Navigate to "Get API key" -> "Create API key in new project".
   - **Required Permissions:** Standard Gemini API read/generate access.
   - **Configuration:** Set `GEMINI_API_KEY` in `.env`.
   - **Free tier & limitations:** Free tier with no credit card required. As of the current official docs, exact RPM/TPM/RPD limits are model- and project-specific and are shown live in Google AI Studio's Rate Limit dashboard rather than as a single published number. RPD quotas reset at midnight Pacific time. Quota exhaustion returns `429 RESOURCE_EXHAUSTED`. New keys created after 28 May 2026 are authorization keys bound to a service account; unrestricted standard keys are rejected.

2. **Backup AI Provider (Fallback): Groq API**
   - **Service:** Groq Cloud
   - **Purpose:** Fast secondary provider used automatically by the hybrid fallback system when Gemini exhausts quota or experiences latency spikes.
   - **Website / Docs:** https://groq.com/ | https://console.groq.com/docs/quickstart
   - **How to create account:** Sign up at https://console.groq.com/.
   - **How to generate API key:** Go to "API Keys" -> "Create API Key".
   - **Configuration:** Set `GROQ_API_KEY` in `.env`.
   - **Free tier & limitations:** Free tier with no credit card required. Exact RPM/TPM/RPD limits are organisation-level and model-specific; current values are shown in the account's Settings → Limits page. Exhaustion returns `429 Too Many Requests` with a `Retry-After` header.

3. **Research Engine: Tavily Search API (or Brave Search API)**
   - **Service:** Tavily AI Research API
   - **Purpose:** Autonomous real-time search for industry trends, seasonal opportunities, and public competitor signals.
   - **Website / Docs:** https://tavily.com/ | https://docs.tavily.com/
   - **How to create account:** Register at https://app.tavily.com/.
   - **How to generate API key:** Copy key from the developer dashboard.
   - **Configuration:** Set `TAVILY_API_KEY` in `.env`.
   - **Free tier & limitations:** Researcher plan: 1,000 free API credits per month, no credit card, 100 requests/minute. Basic search costs 1 credit, advanced search 2 credits. Exhaustion returns `429` with `Retry-After`; pay-as-you-go ($0.008/credit) must be explicitly enabled by the account owner and will never be activated automatically by the application.

*Note:* In Phase 3, we build the complete provider abstraction and fallback machinery with mock/dry-run capabilities so development can proceed smoothly. When you provide the keys, live verification can be conducted immediately.

---

## 3. Files Created or Changed in Phase 2

- `src/db/schema.ts` — PostgreSQL schema for users, sessions, accounts, verifications, workspaces, workspace_members, and businesses.
- `src/lib/auth.ts` — Better Auth server configuration with Drizzle adapter and nextCookies.
- `src/lib/auth-client.ts` — Better Auth client instantiation for React components.
- `src/lib/session.ts` — Database session resolution (`getSessionUser`, `requireSessionUser`).
- `src/lib/tenancy.ts` — Authoritative workspace and tenant boundary checks.
- `src/lib/validators.ts` — Zod schemas for signup, signin, workspaces, and businesses.
- `src/proxy.ts` — Next.js 16 route proxy for optimistic dashboard protection.
- `src/app/api/auth/[...all]/route.ts` — Better Auth REST handler endpoint.
- `src/app/actions/auth.ts` — Server action for secure sign-out.
- `src/app/actions/workspace.ts` — Server actions for workspace creation and switching.
- `src/app/actions/business.ts` — Server actions for business CRUD with tenant validation.
- `src/app/(auth)/layout.tsx` — Split-screen editorial authentication layout.
- `src/app/(auth)/sign-in/page.tsx` — Sign-in page with validation and Suspense boundary.
- `src/app/(auth)/sign-up/page.tsx` — Sign-up page with email/password registration.
- `src/app/onboarding/page.tsx` — Tenant setup wizard (workspace + initial business).
- `src/app/dashboard/layout.tsx` — Session-aware dashboard shell injecting live workspace data.
- `src/app/dashboard/page.tsx` — Command center rendering live tenant stats.
- `src/app/dashboard/businesses/page.tsx` — Live business profile management.
- `src/app/dashboard/settings/page.tsx` — Account and workspace settings view.
- `src/components/auth/form-field.tsx` — Reusable, accessible form controls.
- `src/components/onboarding/forms.tsx` — Client forms for onboarding flow.
- `src/components/dashboard/business-manager.tsx` — Interactive business CRUD dialog and list.
- `src/components/dashboard/dashboard-chrome.tsx` — Updated header/sidebar with live workspace switching.
- `src/components/dashboard/overview.tsx` — Updated overview display.
- `.env.example` — Added documentation for `BETTER_AUTH_SECRET` and base URLs.

---

## 4. Verification and Test Results

- `npx next typegen`: Passed without errors.
- `npm exec tsc -- --noEmit`: Passed with 0 errors.
- `npm run build`: Production build succeeded; compiled 15 routes including static and dynamic SSR routes.
- `build_and_start`: Platform runtime bootstrapped database, started server, and passed `/api/health`.
- Route protection verified: unauthenticated `/dashboard` requests redirect to `/sign-in?next=%2Fdashboard`.
- Real signup verified: created test accounts `alex@northwind.test` and `bailey@atlas.test` with valid tokens and hashed credentials.
- Duplicate email prevention verified: returns HTTP 422 `USER_ALREADY_EXISTS_USE_ANOTHER_EMAIL`.
- Password verification verified: wrong password returns HTTP 401 `INVALID_EMAIL_OR_PASSWORD`.
- Session validation verified: `/api/auth/get-session` returns full user details for valid cookies, `null` for forged cookies.
- Multi-tenant isolation verified: `setActiveWorkspace` with cross-tenant or invalid IDs is strictly rejected.
