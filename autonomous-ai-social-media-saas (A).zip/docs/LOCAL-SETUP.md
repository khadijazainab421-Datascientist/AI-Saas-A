# Running Cadence locally (Option B) — setup and login troubleshooting

This guide is for running the project in VS Code on your own machine with a local `.env`.

## 0. First: make sure you are actually in the Cadence project

If you see **"Serein / SOCIAL INTELLIGENCE"**, **"Back to Serein"**, **"Open login in a new tab"**, or an **"Arena AI"** tab, you are looking at a **different project / preview**. Those strings do not exist anywhere in this codebase. Close that tab — an account created there will never work here.

The Cadence sign-in page (`/sign-in`) looks like this:

- Brand: **Cadence** (with the small `AI` label)
- Eyebrow: `Phase 2 · Authentication`
- Heading: **"Welcome back."**
- Subtext: "Sign in to access your workspaces and business profiles."
- Link: "No account yet? **Create one**"
- A note: "Phase 2 preview. Email and password authentication is live..."
- There is **no** "Open login in a new tab" link in Cadence.

Open your own local URL directly in a normal browser tab: `http://localhost:3000/sign-in`. Do not follow a link from another app's preview.

## 1. First-time setup

```bash
npm install
cp .env.example .env        # Windows: copy .env.example .env
npx drizzle-kit push        # creates all tables in YOUR local database
npm run dev
```

Your `.env` must contain at least:

```dotenv
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
BETTER_AUTH_SECRET=<openssl rand -base64 32>
BETTER_AUTH_URL=http://localhost:3000
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

Phase 3 keys (optional until live AI testing):

```dotenv
GEMINI_API_KEY=
GROQ_API_KEY=
TAVILY_API_KEY=
```

`.env` is gitignored. Never paste keys into chat, source files, or Git.

## 2. "Account / workspace bana liya, par login nahi ho raha" — most likely causes

### Cause A — two different databases (most common)
The **sandbox preview** and your **local machine** do not share a database. An account created in the preview does not exist locally, and vice versa. A workspace created in the preview also will not appear locally.

**Fix:** create the account and workspace again on the machine where you are trying to log in:
1. Open `http://localhost:3000/sign-up`
2. Create the account
3. Complete `/onboarding` (workspace + first business)
4. Sign out and sign back in to verify

### Cause B — local PostgreSQL is not running or schema was never pushed
If `DATABASE_URL` points at a database that is not running, or the tables do not exist, sign-in fails.

```bash
psql "$DATABASE_URL" -c "\dt"                     # 15+ tables should be listed
psql "$DATABASE_URL" -c 'select email from "user";'   # is your account really here?
npx drizzle-kit push                            # if tables are missing
```

### Cause C — `.env` changed but the dev server was not restarted
Next.js reads environment variables at process start.

```bash
# stop the dev server (Ctrl+C), then:
rm -rf .next
npm run dev
```

### Cause D — URL / port mismatch
`BETTER_AUTH_URL` and `NEXT_PUBLIC_APP_URL` must match the origin you actually open in the browser. If dev runs on port 3001, set both to `http://localhost:3001`.

### Cause E — session secret changed between restarts
If `BETTER_AUTH_SECRET` is missing, the app derives one from `DATABASE_URL`. If you later change `DATABASE_URL`, existing session cookies become invalid. Set a fixed `BETTER_AUTH_SECRET` and restart.

### Cause F — password policy
Passwords must be at least 10 characters. Sign-up enforces this; a shorter password will be rejected, not "silently fail".

### Cause G — "password accepted but session cookie not retained" (embedded preview)
This happens when the app is rendered inside a cross-site `<iframe>`. Browsers drop `SameSite=Lax` third-party cookies.

**Fixed in this build:**
- Better Auth now uses a **dynamic `baseURL`** with `allowedHosts` (`localhost:*`, `127.0.0.1:*`, `*.e2b.app`, `*.vercel.app`) so the preview HTTPS origin is trusted and the `Secure` flag is derived correctly.
- In production, cookies are `HttpOnly; Secure; SameSite=None; Partitioned` (CHIPS), which browsers retain in embedded previews.
- In local development (`npm run dev`), cookies stay `SameSite=Lax` and non-secure so plain `http://localhost` keeps working.
- The browser auth client no longer has a hardcoded `baseURL`; it always calls the origin it was loaded from.
- `/sign-in` and `/sign-up` show an **Embedded preview detected** panel with the app's own direct URL and a Copy button.
- The app-owned `cadence_active_workspace` cookie uses the same attributes.

**If it still fails:** copy the direct URL shown in the sign-in panel (or the preview URL itself) into a **top-level browser tab**, not the iframe. Some browsers block third-party cookies regardless of attributes. Also do a hard reload after the new build so old `Lax` cookies are replaced.

Verify the response header after sign-in:
```bash
curl -sS -D - -o /dev/null -X POST http://localhost:3000/api/auth/sign-in/email \
  -H 'Content-Type: application/json' \
  -d '{"email":"you@example.com","password":"yourpassword"}' | grep -i '^set-cookie'
```
In a production/HTTPS build you should see `SameSite=None`, `Secure`, and `Partitioned`.

## 3. Safe diagnostics (never prints secrets)

```bash
node -e "require('dotenv').config(); ['DATABASE_URL','BETTER_AUTH_SECRET','BETTER_AUTH_URL','NEXT_PUBLIC_APP_URL','GEMINI_API_KEY','GROQ_API_KEY','TAVILY_API_KEY'].forEach(k=>console.log(k, process.env[k]?'SET':'MISSING'))"
```

```bash
node scripts/verify-phase3-keys.mjs   # validates Phase 3 keys, prints only HTTP status
```

## 4. Verify the app itself

```bash
curl -sS -o /dev/null -w "%{http_code}\n" http://localhost:3000/api/health
curl -sS -o /dev/null -w "%{http_code}\n" http://localhost:3000/dashboard
```

- `/api/health` → `200` with `{"ok":true}`
- `/dashboard` unauthenticated → `307` redirect to `/sign-in?next=%2Fdashboard`
- `/dashboard/strategy` and `/dashboard/agent` should show provider rows as `unconfigured` when the three keys are absent — this is correct, not a bug.

## 5. Important distinction

A **working login** tests Phase 2 only. It does **not** test the Phase 3 AI engine. To test AI features you need the three keys and a real task (website analysis / research / strategy). Without them the app correctly records `unconfigured` / `paused` states and never fabricates results.
