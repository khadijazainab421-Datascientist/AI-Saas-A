# Cadence — Phase 3 Completion Report

**Phase:** 3 — AI and Research Engine  
**Status:** Architecture implemented and validated. **Live provider calls are NOT tested** because the three API keys are not configured in the sandbox environment. Awaiting key configuration and explicit approval before Phase 4.  
**Scope boundary:** No content studio, media generation, social OAuth, publishing worker, analytics collection, or billing was implemented.

---

## 1. API Discovery and Credential Requirements

### Credentials required for live integration (NOT yet configured in sandbox)

| Env var | Service | Purpose | Official docs | Free tier |
| --- | --- | --- | --- | --- |
| `GEMINI_API_KEY` | Google Gemini | Primary AI generation | https://ai.google.dev/gemini-api/docs/api-key | Yes, no card. Exact RPM/RPD shown in AI Studio's Rate Limit dashboard; `429 RESOURCE_EXHAUSTED` on exhaustion |
| `GROQ_API_KEY` | Groq | Backup AI provider | https://console.groq.com/docs/quickstart | Yes, no card. Exact limits at https://console.groq.com/settings/limits ; `429` + `Retry-After` |
| `TAVILY_API_KEY` | Tavily Search | Public research | https://docs.tavily.com/documentation/api-credits | Researcher plan: 1,000 credits/month, 100 RPM, no card. Basic search = 1 credit |

Optional: `GEMINI_MODEL`, `GROQ_MODEL`.

**Where to configure (sandbox / Option A):** the platform's **Environment Variables / Secrets** panel — NOT `.env`. The sandbox resets `.env` on every rebuild; this was observed when `BETTER_AUTH_SECRET` disappeared between builds. `.env.example` is the secret-free template.

**Security:** all keys are read server-side only via `process.env`. No key is stored in the database, exposed to the browser, logged, or prefixed with `NEXT_PUBLIC_`. `/api/ai/health` reports only `configured` / `unconfigured` and status — never values.

**No account creation, key generation, or developer approval was performed on the customer's behalf.**

### Other services
None selected in Phase 3. Phase 4 (media), Phase 5 (Meta/LinkedIn OAuth), Phase 6 (worker/queue), Phase 7 (payments) will disclose their own credentials at the exact phase they become necessary.

---

## 2. Features Implemented

### Provider-independent AI architecture
- `src/lib/ai/types.ts` — `AIProviderAdapter` interface, generation/research result types, health states.
- `src/lib/ai/providers/gemini.ts` — real Gemini `generateContent` adapter (`x-goog-api-key`, usage metadata, 429 handling).
- `src/lib/ai/providers/groq.ts` — real Groq OpenAI-compatible `chat/completions` adapter (Bearer, token usage, 429 handling).
- `src/lib/ai/providers/tavily.ts` — real `POST https://api.tavily.com/search` adapter (Bearer, 1 credit per basic search).
- `src/lib/ai/registry.ts` — modular registry; adding/replacing a provider requires no orchestrator change.

### Hybrid fallback system (all 8 required behaviours)
1. Primary provider attempted first by priority.
2. On quota/availability failure → next eligible backup provider.
3. Task continues on the successful provider.
4. If all eligible providers unavailable → task marked **`paused`**, never deleted.
5. `resumePausedTasks()` replays preserved `input.prompt` when capacity returns.
6. In-app notification is persisted and surfaced in the dashboard topbar.
7. Generated text and raw website extraction are saved before any parsing; `needs_review` strategies preserve unparsable output instead of discarding it.
8. `workspace_ai_settings.allowPaidProviders` defaults to `false`; paid providers are filtered out unless explicitly enabled. All currently registered providers are free tier.

Additional: provider health checks, usage tracking (`ai_usage`: tokens, credits, latency, status), quota reset timestamps from `Retry-After`, daily per-workspace task limits, and per-provider error classification.

### Business understanding, research, brand profiles, strategy
- `src/lib/ai/website.ts` — real public website extraction with SSRF guard (blocks private/local hosts, refuses redirects, size/timeout caps, HTML stripping). DNS-rebinding protection is documented as a Phase 8 hardening item.
- `src/lib/ai/brand.ts` — saves raw extraction first, then optionally structures tone / audience / value propositions / sensitive topics through the AI orchestrator.
- `src/lib/ai/research.ts` — real Tavily runs; unconfigured and failed runs are recorded honestly with no invented sources.
- `src/lib/ai/strategy.ts` — builds prompts only from real business profile, real website extraction, and real research sources; flags thin/sensitive evidence with `requires_review`.
- `src/lib/ai/orchestrator.ts` — durable task records, fallback, pause/resume, notifications.
- `src/lib/ai/queries.ts` — tenant-scoped reads for provider status, tasks, usage, brands, research, strategies, notifications.

### Database (PostgreSQL / Drizzle)
Added enums `ai_task_status`, `ai_task_kind`, `provider_health_status` and tables:
`workspace_ai_settings`, `provider_health`, `ai_tasks`, `ai_usage`, `brand_profiles`, `research_runs`, `content_strategies`, `notifications`. All tenant-owned tables carry `workspace_id` with cascade delete and indexes.

### API and UI
- `src/app/actions/ai.ts` — session + membership-checked server actions for website analysis, research, strategy, resume, and paid-provider permission.
- `src/app/api/ai/health/route.ts` — protected, secret-free provider readiness endpoint.
- `/dashboard/strategy` — real strategy/research workspace with provider readiness, brand profiles, research runs, strategies, and action controls.
- `/dashboard/agent` — provider health, task log, usage totals, notifications, resume control, and paid-provider gate.
- Dashboard topbar now lists real persisted notifications; phase indicator updated to 3 of 8.

---

## 3. Files Created or Changed

**Created:** `src/lib/ai/{types,registry,orchestrator,settings,notifications,queries,website,research,brand,strategy}.ts`, `src/lib/ai/providers/{gemini,groq,tavily}.ts`, `src/app/actions/ai.ts`, `src/app/api/ai/health/route.ts`, `src/components/dashboard/ai-actions.tsx`, `src/app/dashboard/strategy/page.tsx`, `src/app/dashboard/agent/page.tsx`, `docs/PHASE-3.md`, `docs/LOCAL-SETUP.md`, `scripts/verify-phase3-keys.mjs`.

**Changed:** `src/db/schema.ts`, `src/lib/dashboard-sections.ts`, `src/app/dashboard/layout.tsx`, `src/components/dashboard/dashboard-chrome.tsx`, `src/components/site-footer.tsx`, `src/app/page.tsx`, `.env.example`, `docs/PHASE-2.md` (corrected outdated Gemini/Groq/Tavily quota figures).

**Preserved:** all Phase 1–2 pages, auth, tenancy, business management, `/api/health`.

---

## 4. Tests Performed

See the final validation log in this turn. Automated checks cover:
- `npx next typegen`, `npm exec tsc -- --noEmit`, `npm run build`, `npm run lint`.
- `npx drizzle-kit push` applying Phase 3 tables.
- `build_and_start` + `/api/health`.
- `/api/ai/health` with and without an authenticated session.
- Unconfigured provider behaviour: tasks must pause with a real notification and no fabricated output.
- Tenant isolation: cross-workspace AI task access must be rejected.

**NOT tested / deliberately pending:** any live Gemini, Groq, or Tavily HTTP call, because the keys are not configured in the sandbox. No claim of a working live integration is made.

---

## 5. Known Issues and Limitations

- Live AI/research integrations are **unverified** until keys are configured and a real task completes.
- `.env` is reset by the sandbox on rebuild; use platform env/secrets.
- `BETTER_AUTH_SECRET` is not set in the sandbox, so the app uses a deterministic secret derived from `DATABASE_URL` and logs a production warning. A real secret is mandatory before deployment.
- Website extraction blocks private IPs but does not yet resolve DNS to prevent rebinding; needs an egress proxy in Phase 8.
- Task resume currently re-runs the full prompt from preserved input; it does not replay partial provider output (no partial output exists in the current adapters).
- No background worker yet; tasks run synchronously within the server action. This is a Phase 6 concern.
- `npm install` reported dependency audit advisories; triage is a Phase 8 task.
- No GitHub repository connection, commit, or push was detected.

---

## 6. Remaining Work / Next Phase Gate

Phase 4 — Content Creation Studio — must **not** begin until explicit approval. It will require media API credential disclosure before any live media test.

**STOP.** Configure the three keys in the platform secrets panel, report `keys configured`, and then either request live integration testing (still Phase 3) or grant approval for Phase 4.
