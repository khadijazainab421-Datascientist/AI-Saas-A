# Cadence — Phase 4 Completion Report

**Phase:** 4 — Content Creation Studio  
**Status:** Implemented and validated. Awaiting explicit approval before Phase 5.  
**Scope boundary:** No social OAuth, no publishing worker, no analytics collection, no billing.

---

## 1. Mandatory API discovery and credential disclosure

### Services selected

| Service | Purpose | Key required | Free tier / card | Official docs | Status |
| --- | --- | --- | --- | --- | --- |
| **Openverse** (WordPress) | Primary image sourcing, openly licensed with attribution | **No key** | Keyless anonymous access, low anonymous rate limits (~100/day, 5/hour reported). No card. Quota exhaustion → `429`, task recorded, no fabricated assets | https://docs.openverse.org/ · https://api.openverse.org/v1/ | **Live-tested, HTTP 200** |
| **Unsplash** | Optional higher-quality photos | `UNSPLASH_ACCESS_KEY` | Demo 50 req/hour, production approval raises it. No card. Image file loads do not count. `429` on exhaustion | https://unsplash.com/documentation · https://unsplash.com/developers | Pending (unconfigured) |
| **Pexels** | Optional legacy photos/videos | `PEXELS_API_KEY` | 200 req/hour + 20,000/month, free, no card | https://www.pexels.com/api/documentation/ · https://help.pexels.com/ | **Not recommended**: new API key issuance paused since late Sept 2026 (official help centre). Existing keys still work |
| **Local SVG generator** | Branded graphics | None | 100% local, deterministic, no quota | — | Live (no external API) |
| **FFmpeg / video worker** | MP4 rendering | None | Open source | https://ffmpeg.org/ | **Unavailable**: FFmpeg not installed in sandbox; worker is Phase 6. Only real storyboards produced |

### How to obtain the optional keys (only if you want them)

**Unsplash Access Key**
1. Create an account at https://unsplash.com/developers
2. "New Application" → accept terms → name + description
3. Copy the **Access Key** from the app page
4. Permissions: public photo search (`public` scope by default). No user data, no OAuth.
5. Configure as `UNSPLASH_ACCESS_KEY` in the platform secrets panel or local `.env` (never in code/chat).

**Pexels API Key**
1. https://www.pexels.com/api/ → request a key
2. **Currently paused** — official notice: "New API key issuance is currently paused." Existing keys remain valid at 200/hour and 20,000/month.
3. Configure as `PEXELS_API_KEY` only if you already hold a key.

**Openverse** needs no account, no key, no approval. For higher anonymous limits, Openverse documents an OAuth token registration flow at `/v1/auth_tokens/register/` — evaluation deferred.

### What happens when quota is exhausted
- Openverse `429` → media action records `rate_limited`, returns an honest message, saves **zero** assets.
- Unsplash `429/403` → same.
- Pexels `429` → same.
- No provider is silently switched to a paid tier. `workspace_ai_settings.allowPaidProviders` still defaults to `false`.

### Alternatives
- Openverse is the keyless default and requires nothing.
- Wikimedia Commons API and Openverse authenticated tokens are viable later alternatives.
- Local SVG generator covers branded graphics without any media API.

**No account creation, key generation, approval, or paid enablement was performed on the customer's behalf.**

---

## 2. Features implemented

### Content Creation Studio (`/dashboard/content`)
- Real, persisted content items with status (`draft`, `needs_review`, `approved`), type, platform, hashtags, and AI source task linkage.
- Caption generation via the Phase 3 hybrid fallback orchestrator, grounded only in real business/brand/strategy context. Sensitive or thin evidence is flagged `requires_review`.
- Content idea generation (4–6 ideas, only real AI output is saved).
- **Versioned editor**: every save archives the previous title/caption/body into `content_versions` with editor id.
- Manual draft creation, delete, edit, and status control.
- **Carousel builder** creates ordered slides from real content (title + hashtags), not sample data.
- **Local branded SVG graphics** — deterministic 1080×1080 templates using workspace brand name and headline; previewed via data URL.
- **Media sourcing** via Openverse with creator, license, license URL, attribution, and source URL stored on every asset. Unsplash/Pexels adapters are modular and report `unconfigured` honestly.
- Brand asset register (colours, fonts, guidelines, logo references).
- Provider readiness panel with free-tier limits and the Pexels pause notice.
- **Video storyboards** with scenes/durations, plus an explicit `renderingAvailable: false` note. No fake MP4.

### Content Calendar (`/dashboard/calendar`)
- Real month grid (UTC) with planned entries per day.
- Add/remove schedule entries with content, platform, date/time, and detected timezone.
- All entries are `status = planned`. **No publishing is attempted** and no success state is fabricated.

### Database
Added enum values `caption`, `content_ideas` to `ai_task_kind`, plus tables:
`content_items`, `content_versions`, `media_assets`, `carousel_slides`, `content_schedule`, `brand_assets`. Every tenant-owned table carries `workspace_id` with cascade delete and indexes.

### Security
- Every server action calls `requireSessionUser()` + `requireWorkspaceMembership(userId, workspaceId)`.
- All reads/writes are scoped by `workspace_id`; cross-tenant IDs are rejected.
- Optional media keys are read server-side only via `process.env`.
- SVG generator escapes XML to avoid injection.

---

## 3. Files created or changed

**Created:** `src/lib/media/{types,registry,graphics,video}.ts`, `src/lib/media/providers/{openverse,unsplash,pexels}.ts`, `src/lib/content/generation.ts`, `src/app/actions/content.ts`, `src/components/dashboard/content-studio.tsx`, `src/components/dashboard/calendar-form.tsx`, `src/app/dashboard/content/page.tsx`, `src/app/dashboard/calendar/page.tsx`, `docs/PHASE-4.md`, `README.md`.

**Changed:** `src/db/schema.ts`, `src/lib/ai/orchestrator.ts` (task kinds), `src/lib/dashboard-sections.ts`, `src/components/dashboard/dashboard-chrome.tsx`, `src/components/site-footer.tsx`, `src/app/page.tsx`, `.env.example`.

**Preserved:** all Phase 1–3 functionality, auth cookie fix, AI fallback, tenant isolation.

---

## 4. Tests performed

| Test | Result |
| --- | --- |
| `npx next typegen` / `tsc --noEmit` / `npm run lint` | ✅ pass |
| `npm run build` | ✅ pass |
| `npx drizzle-kit push` | ✅ applied |
| `build_and_start` + `/api/health` | ✅ pass |
| Openverse keyless API (live, from sandbox) | ✅ `HTTP 200`, real JSON with `url`, `creator`, `license`, `attribution` |
| Media sourcing action with authenticated tenant | ✅ real assets persisted with attribution |
| Local SVG graphic generation | ✅ real SVG persisted and rendered |
| Content CRUD + version history | ✅ pass |
| Calendar planned-only scheduling | ✅ no publishing call, status `planned` |
| Tenant isolation on content actions | ✅ cross-workspace rejected |
| Unconfigured Unsplash/Pexels | ✅ reported honestly, zero fabricated assets |

**NOT tested / deliberately pending:** live AI caption/idea generation (the Phase 3 keys were left untouched per the user's instruction), any social publishing, any video MP4 rendering.

---

## 5. Known issues and limitations

- Login inside the user's embedded preview remains unresolved **on their side**; the app-side cookie fix (`SameSite=None; Secure; Partitioned`, dynamic baseURL, origin-relative auth client) is verified working in this build. The screenshots shown were from a different product ("Serein"), not Cadence.
- Pexels new keys are paused — documented, not hidden.
- Openverse anonymous limits are low; caching and authenticated tokens are future work.
- Video rendering requires FFmpeg + a Phase 6 worker.
- Calendar entries are plans only; Phase 6 will add the worker, logs, retries, and duplicate prevention.
- No GitHub repository, commit, or push detected/performed. `README.md` added for when the user connects a remote.
- Dependency audit advisories remain a Phase 8 task.

---

## 6. Instructions for review

1. `/dashboard/content` → source media (keyless Openverse), create a local SVG graphic, add a manual draft, edit it and check version history, build a carousel.
2. `/dashboard/calendar` → add a planned entry, see it in the month grid, remove it.
3. Confirm no "published" or "success" state appears anywhere.
4. Review `docs/PHASE-4.md` and `README.md` before connecting GitHub.

---

## 7. Phase gate

**STOP.** Phase 4 is complete. Phase 5 (Instagram, Facebook, LinkedIn OAuth and publishing) must not begin until explicit approval. At the start of Phase 5, each developer application, permission, app-review requirement, account eligibility, and publishing restriction will be disclosed individually before any live authorization is attempted.
