/**
 * Phase 3 credential pre-flight check (NOT an integration test).
 *
 * Run locally, from the project root:
 *   node scripts/verify-phase3-keys.mjs
 *
 * It reads .env via dotenv, makes ONE minimal request per configured provider,
 * and prints only the HTTP status. It NEVER prints a key, a response body, or
 * any secret. Missing keys are skipped — no network call is made for them.
 *
 * Notes:
 *  - Groq /models is free and consumes no tokens.
 *  - The Gemini call is a tiny free-tier generation request.
 *  - The Tavily basic search consumes 1 of the 1,000 monthly free credits.
 *  - 2xx = OK · 401/403 = invalid key · 429 = quota/rate limit · 5xx = provider issue.
 */
import "dotenv/config";

const checks = [
  {
    name: "Gemini",
    env: "GEMINI_API_KEY",
    call: (key) =>
      fetch("https://generativelanguage.googleapis.com/v1beta/interactions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": key,
          "Api-Revision": "2026-05-20",
        },
        body: JSON.stringify({
          model: "gemini-3.8-flash",
          input: "Reply with the single word OK.",
        }),
        signal: AbortSignal.timeout(15_000),
      }),
  },
  {
    name: "Groq",
    env: "GROQ_API_KEY",
    call: (key) =>
      fetch("https://api.groq.com/openai/v1/models", {
        headers: { Authorization: `Bearer ${key}` },
        signal: AbortSignal.timeout(15_000),
      }),
  },
  {
    name: "Tavily",
    env: "TAVILY_API_KEY",
    call: (key) =>
      fetch("https://api.tavily.com/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          query: "cadence connectivity check",
          search_depth: "basic",
          max_results: 1,
        }),
        signal: AbortSignal.timeout(15_000),
      }),
  },
];

function verdict(status) {
  if (status >= 200 && status < 300) return "OK";
  if (status === 401 || status === 403) return "INVALID KEY";
  if (status === 429) return "QUOTA / RATE LIMIT";
  if (status >= 500) return "PROVIDER ERROR";
  return "CHECK DOCS";
}

console.log("Cadence — Phase 3 credential pre-flight (values never printed)\n");

for (const check of checks) {
  const key = process.env[check.env];

  if (!key) {
    console.log(`${check.name.padEnd(8)} ${check.env.padEnd(18)} MISSING`);
    continue;
  }

  try {
    const response = await check.call(key);
    console.log(
      `${check.name.padEnd(8)} ${check.env.padEnd(18)} HTTP ${response.status} — ${verdict(response.status)}`,
    );
  } catch {
    console.log(`${check.name.padEnd(8)} ${check.env.padEnd(18)} NETWORK ERROR`);
  }
}

console.log(
  "\nThis only validates credentials. The AI/research engine itself is Phase 3 work and is not built yet.",
);
